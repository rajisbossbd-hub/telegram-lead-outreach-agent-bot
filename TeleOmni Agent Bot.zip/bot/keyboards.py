import config
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from bot.strings import tr, get_user_lang

def main_menu_keyboard(user_id: int) -> InlineKeyboardMarkup:
    lang = get_user_lang(user_id)
    lang_btn_text = "🌐 Language"

    from core.subscription import is_admin, get_user_badge_info
    badge = get_user_badge_info(user_id)
    if badge["role"] == "vip":
        status_btn_text = "💎 VIP স্ট্যাটাস" if lang == "bn" else "💎 VIP Status"
    elif badge["role"] == "super_admin":
        status_btn_text = "👑 Owner স্ট্যাটাস" if lang == "bn" else "👑 Owner Status"
    elif badge["role"] == "admin":
        status_btn_text = "🛡️ Admin স্ট্যাটাস" if lang == "bn" else "🛡️ Admin Status"
    else:
        status_btn_text = "👤 প্রোফাইল ও স্ট্যাটাস" if lang == "bn" else "👤 Profile & Status"

    if lang == "bn":
        rows = [
            # ─── Section 1 Header ───
            [InlineKeyboardButton("━━━ 🎙️ লাইভ স্ট্রিম কন্ট্রোল ━━━", callback_data="noop")],
            # 🎙️ 1. Live Stream Controls
            [
                InlineKeyboardButton("🚀 লাইভ জয়েন করুন", callback_data="btn_join_prompt"),
                InlineKeyboardButton("🛑 লাইভ ত্যাগ করুন", callback_data="btn_leave")
            ],
            [
                InlineKeyboardButton("🔴 ২৪/৭ অটো লাইভ জয়েন", callback_data="btn_auto_live_menu")
            ],
            [
                InlineKeyboardButton("🎲 র‍্যান্ডম কমেন্ট", callback_data="btn_random_comment"),
                InlineKeyboardButton("🤖 এআই স্মার্ট কমেন্ট", callback_data="btn_ai_comment")
            ],
            [
                InlineKeyboardButton("🎙️ লাইভ ভয়েস / মাইক", callback_data="btn_live_voice"),
                InlineKeyboardButton("📎 মিডিয়া কমেন্ট", callback_data="btn_attachment_comment")
            ],
            # ─── Section 2 Header ───
            [InlineKeyboardButton("━━━ 🚀 পোস্ট ও এনগেজমেন্ট বুস্ট ━━━", callback_data="noop")],
            # 🚀 2. Post & Engagement Boost
            [
                InlineKeyboardButton("🔥 পোস্ট ভিউ ও রিঅ্যাকশন", callback_data="btn_post_engage_prompt"),
                InlineKeyboardButton("🗳️ পোল ভোটার", callback_data="btn_poll_vote_prompt")
            ],
            [
                InlineKeyboardButton("📡 অটো পোস্ট বুস্টার", callback_data="btn_auto_mon_menu"),
                InlineKeyboardButton("✉️ ডিরেক্ট মেসেজ পাঠান", callback_data="btn_send_to_me")
            ],
            # ─── Section 3 Header ───
            [InlineKeyboardButton("━━━ ⚙️ অ্যাকাউন্ট ও সেটিংস ━━━", callback_data="noop")],
            # ⚙️ 3. Accounts & Settings
            [
                InlineKeyboardButton("👥 অ্যাকাউন্ট ম্যানেজ", callback_data="btn_accounts"),
                InlineKeyboardButton("➕ নতুন অ্যাকাউন্ট যোগ", callback_data="btn_add")
            ],
            [
                InlineKeyboardButton(status_btn_text, callback_data="btn_status"),
                InlineKeyboardButton(lang_btn_text, callback_data="btn_toggle_lang")
            ]
        ]
    else:
        rows = [
            # ─── Section 1 Header ───
            [InlineKeyboardButton("━━━ 🎙️ Live Stream Controls ━━━", callback_data="noop")],
            # 🎙️ 1. Live Stream Controls
            [
                InlineKeyboardButton("🚀 Join Live Stream", callback_data="btn_join_prompt"),
                InlineKeyboardButton("🛑 Leave Live Stream", callback_data="btn_leave")
            ],
            [
                InlineKeyboardButton("🔴 24/7 Auto Live Join", callback_data="btn_auto_live_menu")
            ],
            [
                InlineKeyboardButton("🎲 Random Comments", callback_data="btn_random_comment"),
                InlineKeyboardButton("🤖 AI Smart Comments", callback_data="btn_ai_comment")
            ],
            [
                InlineKeyboardButton("🎙️ Live Voice / Mic", callback_data="btn_live_voice"),
                InlineKeyboardButton("📎 Media Comment", callback_data="btn_attachment_comment")
            ],
            # ─── Section 2 Header ───
            [InlineKeyboardButton("━━━ 🚀 Post & Engagement Boost ━━━", callback_data="noop")],
            # 🚀 2. Post & Engagement Boost
            [
                InlineKeyboardButton("🔥 Post Views & Reacts", callback_data="btn_post_engage_prompt"),
                InlineKeyboardButton("🗳️ Telegram Poll Voter", callback_data="btn_poll_vote_prompt")
            ],
            [
                InlineKeyboardButton("📡 Auto Post Booster", callback_data="btn_auto_mon_menu"),
                InlineKeyboardButton("✉️ Send Direct Message", callback_data="btn_send_to_me")
            ],
            # ─── Section 3 Header ───
            [InlineKeyboardButton("━━━ ⚙️ Accounts & Settings ━━━", callback_data="noop")],
            # ⚙️ 3. Accounts & Settings
            [
                InlineKeyboardButton("👥 Manage Accounts", callback_data="btn_accounts"),
                InlineKeyboardButton("➕ Add New Account", callback_data="btn_add")
            ],
            [
                InlineKeyboardButton(status_btn_text, callback_data="btn_status"),
                InlineKeyboardButton(lang_btn_text, callback_data="btn_toggle_lang")
            ]
        ]

    # Show Admin Panel button ONLY if user is an ADMIN (Super Admin or Added Admin)
    # Pure VIP users will NOT see the Admin Panel!
    if is_admin(user_id):
        rows.append([InlineKeyboardButton("━━━ 👑 Admin Zone ━━━", callback_data="noop")])
        admin_btn_text = "👑 অ্যাডমিন প্যানেল" if lang == "bn" else "👑 Admin Panel"
        insp_btn_text = "🔍 লাইভ মেম্বার চেক (/inspectlive)" if lang == "bn" else "🔍 Inspect Live (/inspectlive)"
        rows.append([
            InlineKeyboardButton(admin_btn_text, callback_data="btn_admin_panel"),
            InlineKeyboardButton(insp_btn_text, callback_data="admin_inspect_live_prompt")
        ])

    return InlineKeyboardMarkup(rows)

def admin_panel_keyboard(user_id: int) -> InlineKeyboardMarkup:
    lang = get_user_lang(user_id)
    if lang == "bn":
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton("📊 সার্বিক পরিসংখ্যান", callback_data="admin_stats_view"),
                InlineKeyboardButton("📱 সকল হোস্ট অ্যাকাউন্ট", callback_data="admin_all_accounts")
            ],
            [
                InlineKeyboardButton("💎 VIP মেম্বার তালিকা", callback_data="admin_vip_list"),
                InlineKeyboardButton("🛡️ অ্যাডমিন তালিকা", callback_data="admin_admins_list")
            ],
            [
                InlineKeyboardButton("➕ VIP যোগ করুন", callback_data="admin_add_vip_prompt"),
                InlineKeyboardButton("➖ VIP বাতিল করুন", callback_data="admin_del_vip_prompt")
            ],
            [
                InlineKeyboardButton("➕ নতুন Admin যোগ", callback_data="admin_add_admin_prompt"),
                InlineKeyboardButton("➖ Admin বাতিল (Owner Only)", callback_data="admin_del_admin_prompt")
            ],
            [
                InlineKeyboardButton("🔍 লাইভ মেম্বার ইন্সপেক্টর", callback_data="admin_inspect_live_prompt"),
                InlineKeyboardButton("📡 ক্যাটাগরি লাইভ স্ক্যানার", callback_data="admin_live_discovery_prompt")
            ],
            [
                InlineKeyboardButton("🔥 ক্যাটাগরি অ্যাক্টিভ গ্রুপ স্ক্যানার", callback_data="admin_group_discovery_prompt")
            ],
            [
                InlineKeyboardButton("🔙 মূল মেন্যু", callback_data="btn_cancel_action")
            ]
        ])
    else:
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton("📊 Global Statistics", callback_data="admin_stats_view"),
                InlineKeyboardButton("📱 All Hosted Accounts", callback_data="admin_all_accounts")
            ],
            [
                InlineKeyboardButton("💎 VIP Members List", callback_data="admin_vip_list"),
                InlineKeyboardButton("🛡️ Admins List", callback_data="admin_admins_list")
            ],
            [
                InlineKeyboardButton("➕ Add VIP User", callback_data="admin_add_vip_prompt"),
                InlineKeyboardButton("➖ Remove VIP User", callback_data="admin_del_vip_prompt")
            ],
            [
                InlineKeyboardButton("➕ Add Admin", callback_data="admin_add_admin_prompt"),
                InlineKeyboardButton("➖ Remove Admin (Owner)", callback_data="admin_del_admin_prompt")
            ],
            [
                InlineKeyboardButton("🔍 Live Members Inspector", callback_data="admin_inspect_live_prompt"),
                InlineKeyboardButton("📡 Live Stream Discovery", callback_data="admin_live_discovery_prompt")
            ],
            [
                InlineKeyboardButton("🔥 Category Active Groups Scanner", callback_data="admin_group_discovery_prompt")
            ],
            [
                InlineKeyboardButton("🔙 Main Menu", callback_data="btn_cancel_action")
            ]
        ])

def count_selection_keyboard(total_accounts: int, user_id: int) -> InlineKeyboardMarkup:
    from core.subscription import is_vip, FREE_LIVE_ACCOUNT_LIMIT
    lang = get_user_lang(user_id)
    user_is_vip = is_vip(user_id)

    buttons = []
    if user_is_vip:
        presets = [1, 2, 3, 5, 8, 10, 15, 20, 50, 100]
        max_allowed = total_accounts
    else:
        presets = [1, 2, 3, 4, 5]
        max_allowed = min(total_accounts, FREE_LIVE_ACCOUNT_LIMIT)

    # Preset count buttons
    row = []
    for c in presets:
        if c < max_allowed:
            label = f"{c} টি" if lang == "bn" else f"{c} Accs"
            row.append(InlineKeyboardButton(label, callback_data=f"btn_count_{c}"))
            if len(row) == 3:
                buttons.append(row)
                row = []
    if row:
        buttons.append(row)

    # All accounts button
    if user_is_vip:
        all_label = f"⚡ সবগুলো ({total_accounts} টি)" if lang == "bn" else f"⚡ All ({total_accounts} accounts)"
        buttons.append([InlineKeyboardButton(all_label, callback_data=f"btn_count_{total_accounts}")])
    else:
        all_label = f"⚡ সর্বোচ্চ {max_allowed}টি (ফ্রি লিমিট)" if lang == "bn" else f"⚡ Max {max_allowed} (Free Limit)"
        buttons.append([InlineKeyboardButton(all_label, callback_data=f"btn_count_{max_allowed}")])

    # Manual custom count button (Prompts user to type exact number)
    cust_label = "✍️ ম্যানুয়াল সংখ্যা লিখুন" if lang == "bn" else "✍️ Type Custom Count"
    buttons.append([InlineKeyboardButton(cust_label, callback_data="btn_custom_count_prompt")])

    buttons.append([InlineKeyboardButton(tr(user_id, "btn_cancel"), callback_data="btn_cancel_action")])
    return InlineKeyboardMarkup(buttons)

def accounts_list_keyboard(accounts: list, user_id: int) -> InlineKeyboardMarkup:
    """Generates keyboard for user's accounts list with manual phone-typing remove option."""
    lang = get_user_lang(user_id)
    buttons = []

    # If user has accounts, provide the single account removal button (prompts for phone number verification)
    if accounts:
        rem_label = "🗑️ অ্যাকাউন্ট রিমুভ করুন" if lang == "bn" else "🗑️ Remove an Account"
        buttons.append([InlineKeyboardButton(rem_label, callback_data="btn_prompt_manual_remove")])

    # Navigation buttons: Add account and Main Menu
    add_label = "➕ নতুন অ্যাকাউন্ট যোগ" if lang == "bn" else "➕ Add New Account"
    back_label = "🔙 মূল মেন্যু" if lang == "bn" else "🔙 Main Menu"
    buttons.append([
        InlineKeyboardButton(add_label, callback_data="btn_add"),
        InlineKeyboardButton(back_label, callback_data="btn_cancel_action")
    ])
    return InlineKeyboardMarkup(buttons)

def account_delete_confirm_keyboard(session_name: str, user_id: int) -> InlineKeyboardMarkup:
    """Backward compatibility helper for account delete confirmation."""
    return cancel_keyboard(user_id)

def cancel_keyboard(user_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(tr(user_id, "btn_cancel"), callback_data="btn_cancel_action")
        ]
    ])

def subscription_keyboard(admin_id: int = 0, user_id: int = 0, admin_username: str = "", contact_url: str = "") -> InlineKeyboardMarkup:
    if not contact_url:
        import urllib.parse
        clean_username = admin_username.lstrip("@") if admin_username else "rajisboss"
        uid_note = f"\nMy Telegram User ID: {user_id}" if user_id else ""
        prefill = f"Hey Admin! I want to be a VIP member in the Telegram Multi-Live Bot.{uid_note}"
        contact_url = f"https://t.me/{clean_username}?text={urllib.parse.quote(prefill)}"

    btn_text = "💬 Contact Admin for Subscription" if get_user_lang(user_id) == "en" else "💬 সাবস্ক্রিপশন নিতে অ্যাডমিনের সাথে যোগাযোগ"
    back_text = "🔙 Main Menu" if get_user_lang(user_id) == "en" else "🔙 মূল মেন্যু"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(btn_text, url=contact_url)],
        [InlineKeyboardButton(back_text, callback_data="btn_cancel_action")]
    ])

def status_keyboard(user_id: int, contact_url: str = "") -> InlineKeyboardMarkup:
    """Keyboard for Status view. Shows VIP upgrade button for free users, and Main Menu button."""
    from core.subscription import is_vip
    lang = get_user_lang(user_id)
    rows = []
    
    if not is_vip(user_id):
        if not contact_url:
            import urllib.parse
            prefill = f"Hey Admin! I want to be a VIP member in the Telegram Multi-Live Bot.\nMy Telegram User ID: {user_id}"
            contact_url = f"https://t.me/rajisboss?text={urllib.parse.quote(prefill)}"
        vip_btn_text = "💎 Upgrade to VIP (ভিআইপি হন)" if lang == "bn" else "💎 Upgrade to VIP Membership"
        rows.append([InlineKeyboardButton(vip_btn_text, url=contact_url)])
        
    back_text = "🔙 Main Menu (মূল মেন্যু)" if lang == "bn" else "🔙 Main Menu"
    rows.append([InlineKeyboardButton(back_text, callback_data="btn_cancel_action")])
    return InlineKeyboardMarkup(rows)

def account_selector_keyboard(accounts_in_call: list, user_id: int) -> InlineKeyboardMarkup:
    """Generates inline buttons for user to pick a specific account (or all) to send comment."""
    buttons = []
    total = len(accounts_in_call)

    # 1. Always list each account without exposing phone numbers
    for acc in accounts_in_call:
        name = acc.get("first_name", "Account")
        uname = acc.get("username")
        label = f"👤 {name} (@{uname})" if uname else f"👤 {name}"
        buttons.append([InlineKeyboardButton(label, callback_data=f"btn_sendatt_{acc['session_name']}")])

    # 2. Always show "All Accounts (সবগুলো)" with exact count!
    all_label = f"⚡ All Accounts (সবগুলো - {total} টি)" if get_user_lang(user_id) == "bn" else f"⚡ All Accounts ({total})"
    buttons.append([InlineKeyboardButton(all_label, callback_data="btn_sendatt_ALL")])
    buttons.append([InlineKeyboardButton(tr(user_id, "btn_cancel"), callback_data="btn_cancel_action")])
    return InlineKeyboardMarkup(buttons)

def inbox_account_selector_keyboard(accounts: list, user_id: int) -> InlineKeyboardMarkup:
    """Generates inline buttons for user to pick an account (or all) to send a message to their own inbox."""
    buttons = []
    total = len(accounts)

    for acc in accounts:
        name = acc.get("first_name", "Account")
        uname = acc.get("username")
        label = f"👤 {name} (@{uname})" if uname else f"👤 {name}"
        buttons.append([InlineKeyboardButton(label, callback_data=f"btn_inbox_acc_{acc['session_name']}")])

    all_label = f"⚡ All Accounts (সবগুলো - {total} টি)" if get_user_lang(user_id) == "bn" else f"⚡ All Accounts ({total})"
    buttons.append([InlineKeyboardButton(all_label, callback_data="btn_inbox_acc_ALL")])
    buttons.append([InlineKeyboardButton(tr(user_id, "btn_cancel"), callback_data="btn_cancel_action")])
    return InlineKeyboardMarkup(buttons)

def inbox_target_keyboard(user_id: int) -> InlineKeyboardMarkup:
    """Keyboard for inbox target input, offering a quick button for sending to own inbox or cancel."""
    lang = get_user_lang(user_id)
    self_lbl = "👤 আমার নিজের ইনবক্স (My Inbox)" if lang == "bn" else "👤 My Own Inbox"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(self_lbl, callback_data="btn_inbox_target_self")],
        [InlineKeyboardButton(tr(user_id, "btn_cancel"), callback_data="btn_cancel_action")]
    ])

def inbox_send_now_keyboard(user_id: int, count: int = 0, current_delay: str = "1-5") -> InlineKeyboardMarkup:
    """Keyboard allowing user to choose messaging time delay and send collected bulk inbox items."""
    lang = get_user_lang(user_id)
    send_lbl = f"🚀 এখনই পাঠান ({count} টি আইটেম)" if (lang == "bn" and count > 0) else (f"🚀 Send Now ({count} items)" if count > 0 else "🚀 Send Now")
    cancel_lbl = "❌ বাতিল (Cancel)" if lang == "bn" else "❌ Cancel"

    d1 = f"✅ 🎲 ১-৫ সে." if current_delay == "1-5" else "🎲 ১-৫ সে."
    d2 = f"✅ ⚡ ১-৩ সে." if current_delay == "1-3" else "⚡ ১-৩ সে."
    d3 = f"✅ ⏱️ ৩-৭ সে." if current_delay == "3-7" else "⏱️ ৩-৭ সে."
    d4 = f"✅ 🐢 ৫-১০ সে." if current_delay == "5-10" else "🐢 ৫-১০ সে."

    is_custom = current_delay not in ("1-5", "1-3", "3-7", "5-10")
    if is_custom:
        custom_clean = str(current_delay).replace("custom:", "")
        d_custom = f"✅ ✍️ ম্যানুয়াল: {custom_clean} সে." if lang == "bn" else f"✅ ✍️ Custom: {custom_clean}s"
    else:
        d_custom = "✍️ ম্যানুয়াল বিরতি সেট (Custom Delay)" if lang == "bn" else "✍️ Set Custom Delay"

    if lang != "bn":
        d1 = f"✅ 🎲 1-5s" if current_delay == "1-5" else "🎲 1-5s"
        d2 = f"✅ ⚡ 1-3s" if current_delay == "1-3" else "⚡ 1-3s"
        d3 = f"✅ ⏱️ 3-7s" if current_delay == "3-7" else "⏱️ 3-7s"
        d4 = f"✅ 🐢 5-10s" if current_delay == "5-10" else "🐢 5-10s"

    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton(d1, callback_data="btn_delay_1-5"),
            InlineKeyboardButton(d2, callback_data="btn_delay_1-3")
        ],
        [
            InlineKeyboardButton(d3, callback_data="btn_delay_3-7"),
            InlineKeyboardButton(d4, callback_data="btn_delay_5-10")
        ],
        [
            InlineKeyboardButton(d_custom, callback_data="btn_delay_custom_prompt")
        ],
        [InlineKeyboardButton(send_lbl, callback_data="btn_inbox_send_now")],
        [InlineKeyboardButton(cancel_lbl, callback_data="btn_cancel_action")]
    ])

def live_voice_control_keyboard(user_id: int) -> InlineKeyboardMarkup:
    """Keyboard for controlling voice broadcasting and microphone in active live stream."""
    lang = get_user_lang(user_id)
    if lang == "bn":
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton("🎙️ ভয়েস অডিও পাঠান", callback_data="btn_voice_send_prompt"),
                InlineKeyboardButton("✋ হাত তুলুন", callback_data="btn_voice_raise_hand")
            ],
            [
                InlineKeyboardButton("🔊 আনমিউট", callback_data="btn_voice_unmute"),
                InlineKeyboardButton("🔇 মিউট", callback_data="btn_voice_mute")
            ],
            [
                InlineKeyboardButton("⏹️ ভয়েস বন্ধ করুন", callback_data="btn_voice_stop")
            ],
            [
                InlineKeyboardButton("🔙 মূল মেন্যু", callback_data="btn_cancel_action")
            ]
        ])
    else:
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton("🎙️ Send Voice Audio", callback_data="btn_voice_send_prompt"),
                InlineKeyboardButton("✋ Raise Hand", callback_data="btn_voice_raise_hand")
            ],
            [
                InlineKeyboardButton("🔊 Unmute", callback_data="btn_voice_unmute"),
                InlineKeyboardButton("🔇 Mute", callback_data="btn_voice_mute")
            ],
            [
                InlineKeyboardButton("⏹️ Stop Voice", callback_data="btn_voice_stop")
            ],
            [
                InlineKeyboardButton("🔙 Main Menu", callback_data="btn_cancel_action")
            ]
        ])

def voice_account_selector_keyboard(accounts_in_call: list, user_id: int) -> InlineKeyboardMarkup:
    """Keyboard to select which live account(s) will broadcast the voice message."""
    buttons = []
    total = len(accounts_in_call)

    all_label = f"⚡ All Accounts (সবগুলো - {total} টি)" if get_user_lang(user_id) == "bn" else f"⚡ All Accounts ({total})"
    buttons.append([InlineKeyboardButton(all_label, callback_data="btn_vset_ALL")])

    # Presets for bulk accounts (e.g. 2, 3, 5)
    presets = [2, 3, 5, 10]
    count_row = []
    for c in presets:
        if c < total:
            lbl = f"👥 প্রথম {c} টি" if get_user_lang(user_id) == "bn" else f"👥 First {c}"
            count_row.append(InlineKeyboardButton(lbl, callback_data=f"btn_vset_COUNT_{c}"))
            if len(count_row) == 2:
                buttons.append(count_row)
                count_row = []
    if count_row:
        buttons.append(count_row)

    for acc in accounts_in_call:
        name = acc.get("first_name", "Account")
        uname = acc.get("username")
        label = f"👤 {name} (@{uname})" if uname else f"👤 {name}"
        buttons.append([InlineKeyboardButton(label, callback_data=f"btn_vset_{acc['session_name']}")])

    buttons.append([InlineKeyboardButton(tr(user_id, "btn_cancel"), callback_data="btn_cancel_action")])
    return InlineKeyboardMarkup(buttons)

def raise_hand_account_selector_keyboard(accounts_in_call: list, user_id: int) -> InlineKeyboardMarkup:
    """Keyboard to select which live account(s) will raise hand."""
    buttons = []
    total = len(accounts_in_call)

    for acc in accounts_in_call:
        name = acc.get("first_name", "Account")
        uname = acc.get("username")
        label = f"✋ {name} (@{uname})" if uname else f"✋ {name}"
        buttons.append([InlineKeyboardButton(label, callback_data=f"btn_rh_{acc['session_name']}")])

    all_label = f"⚡ All Accounts (সবগুলো - {total} টি)" if get_user_lang(user_id) == "bn" else f"⚡ All Accounts ({total})"
    buttons.append([InlineKeyboardButton(all_label, callback_data="btn_rh_ALL")])
    buttons.append([InlineKeyboardButton(tr(user_id, "btn_cancel"), callback_data="btn_cancel_action")])
    return InlineKeyboardMarkup(buttons)
def voice_upload_progress_keyboard(user_id: int) -> InlineKeyboardMarkup:
    """Keyboard shown during voice audio upload allowing user to finish or cancel."""
    lang = get_user_lang(user_id)
    done_lbl = "✅ সম্পন্ন (Done)" if lang == "bn" else "✅ Done"
    cancel_lbl = "❌ বাতিল (Cancel)" if lang == "bn" else "❌ Cancel"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(done_lbl, callback_data="btn_voice_done")],
        [InlineKeyboardButton(cancel_lbl, callback_data="btn_cancel_action")]
    ])

def post_engage_mode_keyboard(user_id: int) -> InlineKeyboardMarkup:
    """Keyboard allowing user to choose engagement mode: views, reactions, or both."""
    lang = get_user_lang(user_id)
    if lang == "bn":
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("👁️ শুধুমাত্র ভিউ বাড়ান (Views Only)", callback_data="btn_engage_mode_views")],
            [InlineKeyboardButton("❤️ শুধুমাত্র রিঅ্যাকশন দিন (Reactions Only)", callback_data="btn_engage_mode_react")],
            [InlineKeyboardButton("🚀 ভিউ + রিঅ্যাকশন দুটোই (Both)", callback_data="btn_engage_mode_both")],
            [InlineKeyboardButton("🔙 বাতিল (Cancel)", callback_data="btn_cancel_action")]
        ])
    else:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("👁️ Views Only", callback_data="btn_engage_mode_views")],
            [InlineKeyboardButton("❤️ Reactions Only", callback_data="btn_engage_mode_react")],
            [InlineKeyboardButton("🚀 Views + Reactions (Both)", callback_data="btn_engage_mode_both")],
            [InlineKeyboardButton("🔙 Cancel", callback_data="btn_cancel_action")]
        ])

def reaction_selection_keyboard(user_id: int) -> InlineKeyboardMarkup:
    """Keyboard for selecting reaction emoji."""
    lang = get_user_lang(user_id)
    rand_lbl = "🎲 র‍্যান্ডম রিঅ্যাকশন (Random)" if lang == "bn" else "🎲 Random Reaction"
    cancel_lbl = "🔙 বাতিল (Cancel)" if lang == "bn" else "🔙 Cancel"
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("👍", callback_data="btn_react_emoji_👍"),
            InlineKeyboardButton("❤️", callback_data="btn_react_emoji_❤️"),
            InlineKeyboardButton("🔥", callback_data="btn_react_emoji_🔥"),
            InlineKeyboardButton("👏", callback_data="btn_react_emoji_👏")
        ],
        [
            InlineKeyboardButton("🎉", callback_data="btn_react_emoji_🎉"),
            InlineKeyboardButton("🤩", callback_data="btn_react_emoji_🤩"),
            InlineKeyboardButton("⚡", callback_data="btn_react_emoji_⚡"),
            InlineKeyboardButton("😍", callback_data="btn_react_emoji_😍")
        ],
        [
            InlineKeyboardButton(rand_lbl, callback_data="btn_react_emoji_RANDOM")
        ],
        [
            InlineKeyboardButton(cancel_lbl, callback_data="btn_cancel_action")
        ]
    ])

def poll_options_keyboard(options: list, user_id: int) -> InlineKeyboardMarkup:
    """Keyboard showing available poll options to vote for."""
    lang = get_user_lang(user_id)
    buttons = []
    for idx, opt in enumerate(options):
        label = f"{idx + 1}. {opt[:30]}"
        buttons.append([InlineKeyboardButton(label, callback_data=f"btn_poll_opt_{idx}")])

    cancel_lbl = "🔙 বাতিল (Cancel)" if lang == "bn" else "🔙 Cancel"
    buttons.append([InlineKeyboardButton(cancel_lbl, callback_data="btn_cancel_action")])
    return InlineKeyboardMarkup(buttons)

def generic_account_selector_keyboard(accounts: list, user_id: int, prefix: str) -> InlineKeyboardMarkup:
    """Generates inline buttons to select ALL accounts, count presets, or specific account for an action."""
    buttons = []
    total = len(accounts)
    lang = get_user_lang(user_id)

    all_label = f"⚡ All Accounts (সবগুলো - {total} টি)" if lang == "bn" else f"⚡ All Accounts ({total})"
    buttons.append([InlineKeyboardButton(all_label, callback_data=f"{prefix}_ALL")])

    presets = [2, 3, 5, 10, 20, 50]
    count_row = []
    for c in presets:
        if c < total:
            lbl = f"{c} টি" if lang == "bn" else f"{c} accs"
            count_row.append(InlineKeyboardButton(lbl, callback_data=f"{prefix}_{c}"))
            if len(count_row) == 3:
                buttons.append(count_row)
                count_row = []
    if count_row:
        buttons.append(count_row)

    for acc in accounts:
        name = acc.get("first_name", "Account")
        uname = acc.get("username")
        label = f"👤 {name} (@{uname})" if uname else f"👤 {name}"
        buttons.append([InlineKeyboardButton(label, callback_data=f"{prefix}_{acc['session_name']}")])

    cancel_lbl = "🔙 বাতিল (Cancel)" if lang == "bn" else "🔙 Cancel"
    buttons.append([InlineKeyboardButton(cancel_lbl, callback_data="btn_cancel_action")])
    return InlineKeyboardMarkup(buttons)

def auto_monitor_menu_keyboard(user_id: int, monitors: list) -> InlineKeyboardMarkup:
    lang = get_user_lang(user_id)
    buttons = []
    for m in monitors:
        status_icon = "🟢" if m.get("is_active", True) else "⏸️"
        title = m.get("channel_title") or m.get("channel_username") or str(m.get("channel_id"))
        views = m.get("views_count", 5)
        react = m.get("reaction_mode", "")
        if react == "RANDOM_POSITIVE":
            r_icon = "🎲 Mix"
        elif react == "SPECIFIC":
            r_icon = m.get("specific_emoji", "❤️")
        else:
            r_icon = "👁️ Only"
        btn_text = f"{status_icon} {title[:18]} (👁️{views} | {r_icon})"
        buttons.append([InlineKeyboardButton(btn_text, callback_data=f"btn_amon_view_{m['id']}")])

    if len(monitors) > 1:
        if lang == "bn":
            buttons.append([
                InlineKeyboardButton("⏸️ সব পজ করুন", callback_data="btn_amon_pause_all"),
                InlineKeyboardButton("▶️ সব চালু করুন", callback_data="btn_amon_resume_all")
            ])
            buttons.append([InlineKeyboardButton("🗑️ সবগুলো মুছুন (Clear All)", callback_data="btn_amon_clear_all")])
        else:
            buttons.append([
                InlineKeyboardButton("⏸️ Pause All", callback_data="btn_amon_pause_all"),
                InlineKeyboardButton("▶️ Resume All", callback_data="btn_amon_resume_all")
            ])
            buttons.append([InlineKeyboardButton("🗑️ Clear All Monitors", callback_data="btn_amon_clear_all")])

    add_btn_text = "➕ নতুন চ্যানেল যুক্ত করুন" if lang == "bn" else "➕ Add Channel Monitor"
    buttons.append([InlineKeyboardButton(add_btn_text, callback_data="btn_amon_add")])

    back_btn_text = "🔙 প্রধান মেনু (Main Menu)" if lang == "bn" else "🔙 Main Menu"
    buttons.append([InlineKeyboardButton(back_btn_text, callback_data="btn_main_menu")])
    return InlineKeyboardMarkup(buttons)

def auto_monitor_detail_keyboard(user_id: int, monitor_id: str, is_active: bool) -> InlineKeyboardMarkup:
    lang = get_user_lang(user_id)
    buttons = []
    if is_active:
        toggle_text = "⏸️ সাময়িক বন্ধ করুন (Pause)" if lang == "bn" else "⏸️ Pause Monitor"
    else:
        toggle_text = "▶️ পুনরায় চালু করুন (Resume)" if lang == "bn" else "▶️ Resume Monitor"

    buttons.append([InlineKeyboardButton(toggle_text, callback_data=f"btn_amon_toggle_{monitor_id}")])
    chg_react_text = "❤️ রিঅ্যাকশন পরিবর্তন (Change Reaction)" if lang == "bn" else "❤️ Change Reaction"
    buttons.append([InlineKeyboardButton(chg_react_text, callback_data=f"btn_amon_chg_react_{monitor_id}")])
    del_text = "🗑️ মনিটর ডিলিট করুন (Delete)" if lang == "bn" else "🗑️ Delete Monitor"
    buttons.append([InlineKeyboardButton(del_text, callback_data=f"btn_amon_del_{monitor_id}")])
    back_text = "🔙 মনিটর তালিকা (Monitors List)" if lang == "bn" else "🔙 Monitors List"
    buttons.append([InlineKeyboardButton(back_text, callback_data="btn_auto_mon_menu")])
    return InlineKeyboardMarkup(buttons)

def auto_reaction_choice_keyboard(user_id: int) -> InlineKeyboardMarkup:
    lang = get_user_lang(user_id)
    mix_text = "🎲 সকল পজিটিভ রিঅ্যাকশন (Positive Mix)" if lang == "bn" else "🎲 All Positive Reactions Mix"
    pool_text = "🎯 ২-৫টি ইমোজি পুল (প্রতি পোস্টে ১টি র‍্যান্ডম)" if lang == "bn" else "🎯 2-5 Emoji Pool (1 Random per Post)"
    custom_input = "✍️ ম্যানুয়াল কাস্টম ইমোজি লিখুন (Custom Input)" if lang == "bn" else "✍️ Custom Emoji (Manual Input)"
    views_only = "👁️ শুধুমাত্র ভিউ (কোনো রিঅ্যাকশন নয়)" if lang == "bn" else "👁️ Views Only (No Reaction)"
    cancel_text = "🔙 বাতিল (Cancel)" if lang == "bn" else "🔙 Cancel"

    return InlineKeyboardMarkup([
        [InlineKeyboardButton(mix_text, callback_data="btn_amon_react_RANDOM_POSITIVE")],
        [InlineKeyboardButton(pool_text, callback_data="btn_amon_react_POOL_PER_POST")],
        [InlineKeyboardButton(custom_input, callback_data="btn_amon_react_CUSTOM_INPUT")],
        [
            InlineKeyboardButton("🔥 Fire", callback_data="btn_amon_react_SPECIFIC_🔥"),
            InlineKeyboardButton("❤️ Love", callback_data="btn_amon_react_SPECIFIC_❤️"),
            InlineKeyboardButton("💖 Sparkle", callback_data="btn_amon_react_SPECIFIC_💖")
        ],
        [
            InlineKeyboardButton("👍 Thumbs Up", callback_data="btn_amon_react_SPECIFIC_👍"),
            InlineKeyboardButton("👏 Clap", callback_data="btn_amon_react_SPECIFIC_👏"),
            InlineKeyboardButton("🎉 Party", callback_data="btn_amon_react_SPECIFIC_🎉")
        ],
        [
            InlineKeyboardButton("🤩 Star Struck", callback_data="btn_amon_react_SPECIFIC_🤩"),
            InlineKeyboardButton("⚡ Lightning", callback_data="btn_amon_react_SPECIFIC_⚡"),
            InlineKeyboardButton("😍 Heart Eyes", callback_data="btn_amon_react_SPECIFIC_😍")
        ],
        [
            InlineKeyboardButton("💯 100", callback_data="btn_amon_react_SPECIFIC_💯"),
            InlineKeyboardButton("🚀 Rocket", callback_data="btn_amon_react_SPECIFIC_🚀"),
            InlineKeyboardButton("🥰 In Love", callback_data="btn_amon_react_SPECIFIC_🥰")
        ],
        [InlineKeyboardButton(views_only, callback_data="btn_amon_react_NONE")],
        [InlineKeyboardButton(cancel_text, callback_data="btn_cancel_action")]
    ])

def live_inspection_action_keyboard(user_id: int) -> InlineKeyboardMarkup:
    lang = get_user_lang(user_id)
    msg_btn = "✉️ লাইভ মেম্বারদের মেসেজ পাঠান" if lang == "bn" else "✉️ Message Live Attendees"
    back_btn = "🔙 অ্যাডমিন প্যানেল" if lang == "bn" else "🔙 Admin Panel"
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(msg_btn, callback_data="admin_live_send_dm_prompt")],
        [InlineKeyboardButton(back_btn, callback_data="btn_admin_panel")]
    ])

def live_dm_count_keyboard(user_id: int, total_targets: int) -> InlineKeyboardMarkup:
    lang = get_user_lang(user_id)
    rows = []
    r1 = []
    if total_targets >= 5:
        r1.append(InlineKeyboardButton("⚡ ৫ জনকে", callback_data="btn_ldm_cnt_5"))
    if total_targets >= 10:
        r1.append(InlineKeyboardButton("⚡ ১০ জনকে", callback_data="btn_ldm_cnt_10"))
    if total_targets >= 20:
        r1.append(InlineKeyboardButton("⚡ ২০ জনকে", callback_data="btn_ldm_cnt_20"))
    if r1:
        rows.append(r1)

    all_cnt = total_targets
    all_label = f"🚀 সকল মেম্বারকে ({all_cnt} জন - মাল্টি-অ্যাকাউন্ট রোটেশন)" if lang == "bn" else f"🚀 All Attendees ({all_cnt} - Multi-Account Auto Rotate)"
    rows.append([InlineKeyboardButton(all_label, callback_data=f"btn_ldm_cnt_{all_cnt}")])
    rows.append([InlineKeyboardButton("❌ বাতিল করুন" if lang == "bn" else "❌ Cancel", callback_data="btn_cancel_action")])
    return InlineKeyboardMarkup(rows)

def live_target_filter_keyboard(user_id: int, total_humans: int, active_cnt: int, inactive_cnt: int, username_cnt: int) -> InlineKeyboardMarkup:
    lang = get_user_lang(user_id)
    if lang == "bn":
        return InlineKeyboardMarkup([
            [InlineKeyboardButton(f"👥 সকল রিয়েল হিউম্যান ({total_humans} জন)", callback_data="btn_lflt_all")],
            [InlineKeyboardButton(f"🟢 অনলাইন ও রিসেন্ট সক্রিয় ({active_cnt} জন)", callback_data="btn_lflt_active")],
            [InlineKeyboardButton(f"⚪ ইনঅ্যাক্টিভ মেম্বার ({inactive_cnt} জন)", callback_data="btn_lflt_inactive")],
            [InlineKeyboardButton(f"🔤 শুধু @username যুক্ত ({username_cnt} জন)", callback_data="btn_lflt_username")],
            [InlineKeyboardButton("🔙 বাতিল করুন", callback_data="btn_cancel_action")]
        ])
    else:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton(f"👥 All Real Humans ({total_humans})", callback_data="btn_lflt_all")],
            [InlineKeyboardButton(f"🟢 Online & Recent Active ({active_cnt})", callback_data="btn_lflt_active")],
            [InlineKeyboardButton(f"⚪ Inactive Members ({inactive_cnt})", callback_data="btn_lflt_inactive")],
            [InlineKeyboardButton(f"🔤 With @username Only ({username_cnt})", callback_data="btn_lflt_username")],
            [InlineKeyboardButton("🔙 Cancel", callback_data="btn_cancel_action")]
        ])

def get_country_badge(country_code: str, lang: str = "bn") -> str:
    codes = {
        "BD": "🇧🇩 বাংলাদেশ" if lang == "bn" else "🇧🇩 Bangladesh",
        "IN": "🇮🇳 ভারত" if lang == "bn" else "🇮🇳 India",
        "PK": "🇵🇰 পাকিস্তান" if lang == "bn" else "🇵🇰 Pakistan",
        "US": "🇺🇸 USA" if lang == "bn" else "🇺🇸 USA",
        "GLOBAL": "🌐 অফ / গ্লোবাল (সব দেশ)" if lang == "bn" else "🌐 Off / All Countries",
    }
    return codes.get((country_code or "GLOBAL").upper(), "🌐 অফ / গ্লোবাল" if lang == "bn" else "🌐 Off / Global")

def country_selector_keyboard(user_id: int, current_country: str = "GLOBAL", return_to: str = "live") -> InlineKeyboardMarkup:
    lang = get_user_lang(user_id)
    cur = (current_country or "GLOBAL").upper()

    def mark(c):
        return " ✅" if cur == c else ""

    if lang == "bn":
        buttons = [
            [
                InlineKeyboardButton(f"🌐 ফিল্টার বন্ধ (সকল দেশ / গ্লোবাল){mark('GLOBAL')}", callback_data=f"admin_set_country_GLOBAL_{return_to}")
            ],
            [
                InlineKeyboardButton(f"🇧🇩 বাংলাদেশ{mark('BD')}", callback_data=f"admin_set_country_BD_{return_to}"),
                InlineKeyboardButton(f"🇮🇳 ভারত{mark('IN')}", callback_data=f"admin_set_country_IN_{return_to}")
            ],
            [
                InlineKeyboardButton(f"🇵🇰 পাকিস্তান{mark('PK')}", callback_data=f"admin_set_country_PK_{return_to}"),
                InlineKeyboardButton(f"🇺🇸 USA{mark('US')}", callback_data=f"admin_set_country_US_{return_to}")
            ],
            [
                InlineKeyboardButton("🔙 ফিরে যান", callback_data="admin_live_discovery_prompt" if return_to == "live" else "admin_group_discovery_prompt")
            ]
        ]
    else:
        buttons = [
            [
                InlineKeyboardButton(f"🌐 Filter Off (All Countries / Global){mark('GLOBAL')}", callback_data=f"admin_set_country_GLOBAL_{return_to}")
            ],
            [
                InlineKeyboardButton(f"🇧🇩 Bangladesh{mark('BD')}", callback_data=f"admin_set_country_BD_{return_to}"),
                InlineKeyboardButton(f"🇮🇳 India{mark('IN')}", callback_data=f"admin_set_country_IN_{return_to}")
            ],
            [
                InlineKeyboardButton(f"🇵🇰 Pakistan{mark('PK')}", callback_data=f"admin_set_country_PK_{return_to}"),
                InlineKeyboardButton(f"🇺🇸 USA{mark('US')}", callback_data=f"admin_set_country_US_{return_to}")
            ],
            [
                InlineKeyboardButton("🔙 Back", callback_data="admin_live_discovery_prompt" if return_to == "live" else "admin_group_discovery_prompt")
            ]
        ]
    return InlineKeyboardMarkup(buttons)

def live_discovery_categories_keyboard(user_id: int, current_country: str = "GLOBAL") -> InlineKeyboardMarkup:
    lang = get_user_lang(user_id)
    cur = (current_country or "GLOBAL").upper()
    c_badge = get_country_badge(cur, lang)

    if cur == "GLOBAL":
        top_btn_text = "🌍 কান্ট্রি ফিল্টার: 🌐 অফ (সেট করতে ক্লিক)" if lang == "bn" else "🌍 Country Filter: 🌐 Off (Click to Set)"
    else:
        top_btn_text = f"🌍 ফিল্টার সক্রিয়: {c_badge} (পরিবর্তন/অফ)" if lang == "bn" else f"🌍 Filter Active: {c_badge} (Change/Off)"

    if lang == "bn":
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton(top_btn_text, callback_data="admin_change_country_live")
            ],
            [
                InlineKeyboardButton("👥 আমার গ্রুপগুলোর লাইভ স্ক্যান (Joined Chats)", callback_data="admin_cat_live_joined_dialogs")
            ],
            [
                InlineKeyboardButton("📈 ট্রেডিং ও ফরেক্স", callback_data="admin_cat_live_trading"),
                InlineKeyboardButton("💰 ক্রিপ্টো ও সিগন্যাল", callback_data="admin_cat_live_crypto")
            ],
            [
                InlineKeyboardButton("🎮 গেমিং ও লাইভ", callback_data="admin_cat_live_gaming"),
                InlineKeyboardButton("💬 কমিউনিটি ও আড্ডা", callback_data="admin_cat_live_community")
            ],
            [
                InlineKeyboardButton("🔍 কাস্টম কীওয়ার্ড সার্চ", callback_data="admin_cat_live_custom")
            ],
            [
                InlineKeyboardButton("🔙 অ্যাডমিন প্যানেল", callback_data="btn_admin_panel")
            ]
        ])
    else:
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton(top_btn_text, callback_data="admin_change_country_live")
            ],
            [
                InlineKeyboardButton("👥 Scan Joined Groups Live", callback_data="admin_cat_live_joined_dialogs")
            ],
            [
                InlineKeyboardButton("📈 Trading & Forex", callback_data="admin_cat_live_trading"),
                InlineKeyboardButton("💰 Crypto & Signals", callback_data="admin_cat_live_crypto")
            ],
            [
                InlineKeyboardButton("🎮 Gaming & Fun", callback_data="admin_cat_live_gaming"),
                InlineKeyboardButton("💬 Community & Chat", callback_data="admin_cat_live_community")
            ],
            [
                InlineKeyboardButton("🔍 Custom Keyword Search", callback_data="admin_cat_live_custom")
            ],
            [
                InlineKeyboardButton("🔙 Admin Panel", callback_data="btn_admin_panel")
            ]
        ])

def group_discovery_categories_keyboard(user_id: int, current_country: str = "GLOBAL") -> InlineKeyboardMarkup:
    lang = get_user_lang(user_id)
    cur = (current_country or "GLOBAL").upper()
    c_badge = get_country_badge(cur, lang)

    if cur == "GLOBAL":
        top_btn_text = "🌍 কান্ট্রি ফিল্টার: 🌐 অফ (সেট করতে ক্লিক)" if lang == "bn" else "🌍 Country Filter: 🌐 Off (Click to Set)"
    else:
        top_btn_text = f"🌍 ফিল্টার সক্রিয়: {c_badge} (পরিবর্তন/অফ)" if lang == "bn" else f"🌍 Filter Active: {c_badge} (Change/Off)"

    if lang == "bn":
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton(top_btn_text, callback_data="admin_change_country_grp")
            ],
            [
                InlineKeyboardButton("📈 ট্রেডিং ও ফরেক্স গ্রুপ", callback_data="admin_cat_grp_trading"),
                InlineKeyboardButton("💰 ক্রিপ্টো ও সিগন্যাল গ্রুপ", callback_data="admin_cat_grp_crypto")
            ],
            [
                InlineKeyboardButton("🎮 গেমিং ও লাইভ গ্রুপ", callback_data="admin_cat_grp_gaming"),
                InlineKeyboardButton("💬 কমিউনিটি ও চ্যাট গ্রুপ", callback_data="admin_cat_grp_community")
            ],
            [
                InlineKeyboardButton("🔍 কাস্টম কীওয়ার্ড দিয়ে গ্রুপ খুঁজুন", callback_data="admin_cat_grp_custom")
            ],
            [
                InlineKeyboardButton("🔙 অ্যাডমিন প্যানেল", callback_data="btn_admin_panel")
            ]
        ])
    else:
        return InlineKeyboardMarkup([
            [
                InlineKeyboardButton(top_btn_text, callback_data="admin_change_country_grp")
            ],
            [
                InlineKeyboardButton("📈 Trading & Forex Groups", callback_data="admin_cat_grp_trading"),
                InlineKeyboardButton("💰 Crypto & Signals Groups", callback_data="admin_cat_grp_crypto")
            ],
            [
                InlineKeyboardButton("🎮 Gaming Groups", callback_data="admin_cat_grp_gaming"),
                InlineKeyboardButton("💬 Community & Chat Groups", callback_data="admin_cat_grp_community")
            ],
            [
                InlineKeyboardButton("🔍 Custom Group Keyword Search", callback_data="admin_cat_grp_custom")
            ],
            [
                InlineKeyboardButton("🔙 Admin Panel", callback_data="btn_admin_panel")
            ]
        ])

def auto_live_menu_keyboard(user_id: int, targets_count: int = 0) -> InlineKeyboardMarkup:
    lang = get_user_lang(user_id)
    if lang == "bn":
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ নতুন টার্গেট চ্যানেল/গ্রুপ যোগ করুন", callback_data="auto_live_add")],
            [InlineKeyboardButton(f"📋 আমার টার্গেট লিস্ট ({targets_count} টি)", callback_data="auto_live_list")],
            [InlineKeyboardButton("🔙 প্রধান মেনু", callback_data="btn_main_menu")]
        ])
    else:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ Add Target Channel/Group", callback_data="auto_live_add")],
            [InlineKeyboardButton(f"📋 My Live Targets ({targets_count})", callback_data="auto_live_list")],
            [InlineKeyboardButton("🔙 Main Menu", callback_data="btn_main_menu")]
        ])

def auto_live_list_keyboard(targets: list, user_id: int) -> InlineKeyboardMarkup:
    lang = get_user_lang(user_id)
    rows = []
    for t in targets:
        tid = t["id"]
        title = t.get("chat_title") or t.get("target_input", "Target")
        if len(title) > 20:
            title = title[:18] + ".."
        
        if t.get("is_currently_live"):
            badge = "🔴 লাইভ" if lang == "bn" else "🔴 LIVE"
        elif t.get("is_active", True):
            badge = "🟢 সক্রিয়" if lang == "bn" else "🟢 Active"
        else:
            badge = "⚪ বন্ধ" if lang == "bn" else "⚪ Off"

        acc_cnt = t.get("accounts_count", 0)
        acc_text = f"{acc_cnt} টি" if acc_cnt > 0 else "All"
        label = f"{badge} | {title} ({acc_text})"
        rows.append([InlineKeyboardButton(label, callback_data=f"auto_live_view_{tid}")])

    add_text = "➕ নতুন টার্গেট যোগ করুন" if lang == "bn" else "➕ Add New Target"
    back_text = "🔙 অটো লাইভ মেনু" if lang == "bn" else "🔙 Auto Live Menu"
    rows.append([InlineKeyboardButton(add_text, callback_data="auto_live_add")])
    rows.append([InlineKeyboardButton(back_text, callback_data="btn_auto_live_menu")])
    return InlineKeyboardMarkup(rows)

def auto_live_target_detail_keyboard(target: dict, user_id: int) -> InlineKeyboardMarkup:
    lang = get_user_lang(user_id)
    tid = target["id"]
    is_act = target.get("is_active", True)
    
    toggle_text = "⏸️ সাময়িক বন্ধ করুন" if is_act else "▶️ পুনরায় চালু করুন"
    if lang != "bn":
        toggle_text = "⏸️ Pause Target" if is_act else "▶️ Resume Target"

    acc_cnt = target.get("accounts_count", 0)
    acc_label = f"👥 অ্যাকাউন্ট: {acc_cnt} টি" if acc_cnt > 0 else "👥 অ্যাকাউন্ট: সবগুলো (All)"
    if lang != "bn":
        acc_label = f"👥 Accounts: {acc_cnt}" if acc_cnt > 0 else "👥 Accounts: All"

    test_text = "🚀 এখনই জয়েন টেস্ট করুন" if lang == "bn" else "🚀 Test Join Now"
    del_text = "🗑️ টার্গেট মুছুন" if lang == "bn" else "🗑️ Delete Target"
    back_text = "🔙 টার্গেট লিস্ট" if lang == "bn" else "🔙 Targets List"

    return InlineKeyboardMarkup([
        [InlineKeyboardButton(toggle_text, callback_data=f"auto_live_toggle_{tid}")],
        [InlineKeyboardButton(acc_label, callback_data=f"auto_live_cntmenu_{tid}")],
        [InlineKeyboardButton(test_text, callback_data=f"auto_live_test_{tid}")],
        [InlineKeyboardButton(del_text, callback_data=f"auto_live_del_{tid}")],
        [InlineKeyboardButton(back_text, callback_data="auto_live_list")]
    ])

def auto_live_count_selection_keyboard(target_id: str, total_accounts: int, user_id: int) -> InlineKeyboardMarkup:
    from core.subscription import is_vip, FREE_LIVE_ACCOUNT_LIMIT
    lang = get_user_lang(user_id)
    user_is_vip = is_vip(user_id)
    rows = []

    if user_is_vip:
        all_label = f"🌟 সবগুলো অ্যাকাউন্ট ({total_accounts} টি)" if lang == "bn" else f"🌟 All Accounts ({total_accounts})"
        rows.append([InlineKeyboardButton(all_label, callback_data=f"auto_live_setcnt_{target_id}_0")])
        presets = [1, 2, 3, 5, 8, 10, 15, 20, 50]
        max_allowed = total_accounts
    else:
        max_allowed = min(total_accounts, FREE_LIVE_ACCOUNT_LIMIT)
        all_label = f"🌟 সর্বোচ্চ {max_allowed}টি (ফ্রি লিমিট)" if lang == "bn" else f"🌟 Max {max_allowed} (Free Limit)"
        rows.append([InlineKeyboardButton(all_label, callback_data=f"auto_live_setcnt_{target_id}_{max_allowed}")])
        presets = [1, 2, 3, 4, 5]

    cnt_row = []
    for c in presets:
        if c <= max_allowed:
            cnt_row.append(InlineKeyboardButton(f"{c} টি" if lang == "bn" else f"{c} Accs", callback_data=f"auto_live_setcnt_{target_id}_{c}"))
            if len(cnt_row) == 3:
                rows.append(cnt_row)
                cnt_row = []
    if cnt_row:
        rows.append(cnt_row)

    # Custom count button available for all users
    custom_text = "✍️ ম্যানুয়াল সংখ্যা লিখুন" if lang == "bn" else "✍️ Type Custom Count"
    rows.append([InlineKeyboardButton(custom_text, callback_data=f"auto_live_custcnt_{target_id}")])

    back_text = "🔙 বাতিল" if lang == "bn" else "🔙 Back"
    rows.append([InlineKeyboardButton(back_text, callback_data=f"auto_live_view_{target_id}")])
    return InlineKeyboardMarkup(rows)


