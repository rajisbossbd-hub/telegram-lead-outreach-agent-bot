import json
from pathlib import Path
import config

LANG_FILE = config.SESSIONS_DIR / "user_langs.json"

def load_user_langs() -> dict:
    if not LANG_FILE.exists():
        return {}
    try:
        with open(LANG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_user_langs(data: dict):
    with open(LANG_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def get_user_lang(user_id: int) -> str:
    langs = load_user_langs()
    return langs.get(str(user_id), "en") # Default to English

def set_user_lang(user_id: int, lang: str):
    langs = load_user_langs()
    langs[str(user_id)] = lang
    save_user_langs(langs)

RANDOM_COMMENTS = [
    "Great stream bro! 🔥",
    "Sound is crystal clear 👍",
    "Nice topic, listening carefully!",
    "Keep it up! ❤️",
    "Watching from live! 🙌",
    "Very informative discussion 👏",
    "Hello everyone! 👋",
    "Awesome presentation!",
    "Valo lagche live ta 🔥",
    "Super quality stream!",
    "Supporting from here ❤️",
    "Good job brother 👍",
    "Interesting points! 💯",
    "Sound quality khub bhalo 👏",
    "Carry on bro! 🔥",
    "Awesome session today 🚀",
    "Khub sundor live hocche",
    "Everything is clear 👍"
]

STRINGS = {
    "bn": {
        "start_title": "🤖 **Telegram Multi-Account Live Joiner Panel**",
        "welcome": "স্বাগতম **{name}**!",
        "desc": "এখানে আপনি আপনার টেলিগ্রাম অ্যাকাউন্টগুলো যুক্ত করে যেকোনো লাইভ বা ভয়েস চ্যাটে একসাথে জয়েন করাতে পারবেন।",
        "acc_count": "📊 আপনার যুক্ত করা অ্যাকাউন্ট: **{count} টি**",
        "commands": "📌 **Commands:**\n🔹 `/join <link>` - লাইভে জয়েন করান\n🔹 `/leave` - লাইভ থেকে বের করুন\n🔹 `/comment <text>` - লাইভে কমেন্ট পাঠান\n🔹 `/accounts` - অ্যাকাউন্টের তালিকা\n🔹 `/add` - নতুন অ্যাকাউন্ট যোগ করুন\n🔹 `/status` - লাইভ স্ট্যাটাস",
        "choose_btn": "নিচের বাটনগুলো ব্যবহার করে খুব সহজে পরিচালনা করুন:",
        "btn_accounts": "👥 অ্যাকাউন্ট ম্যানেজ",
        "btn_add": "➕ নতুন অ্যাকাউন্ট যোগ",
        "btn_join": "🚀 লাইভ জয়েন করুন",
        "btn_leave": "🛑 লাইভ ত্যাগ করুন",
        "btn_random_comment": "🎲 র‍্যান্ডম কমেন্ট",
        "btn_custom_comment": "✍️ কাস্টম কমেন্ট",
        "btn_ai_comment": "🤖 এআই স্মার্ট কমেন্ট",
        "btn_attachment_comment": "📎 মিডিয়া কমেন্ট",
        "btn_send_to_me": "✉️ ডিরেক্ট মেসেজ পাঠান",
        "btn_live_voice": "🎙️ লাইভ ভয়েস / মাইক",
        "btn_status": "💎 প্রোফাইল ও স্ট্যাটাস",
        "btn_lang": "🌐 Language",
        "btn_cancel": "❌ বাতিল",
        "live_voice_panel_title": "🎙️ **লাইভ ভয়েস ও মাইক কন্ট্রোল (Live Voice Control)**\n\n🎯 বর্তমান লাইভ: **{title}**\n👥 লাইভে যুক্ত অ্যাকাউন্ট: **{count} টি**\n\n💡 **এই ফিচারটি কীভাবে কাজ করে?**\n১. **ভয়েস অডিও সেট করুন:** নিচের '🎙️ ভয়েস অডিও পাঠান' বাটনে চাপ দিয়ে একটি ভয়েস মেসেজ বা অডিও ফাইল সেন্ড করুন।\n২. **হোস্ট মাইক অন করলেই লাইভে বাজবে:** লাইভ হোস্ট যখনই আপনার অ্যাকাউন্টের মাইক চালু (Unmute) করবেন, তখনই স্বয়ংক্রিয়ভাবে আপনার ভয়েস মেসেজটি লাইভ স্ট্রিমে শোনা যাবে!\n৩. **হাত তুলুন (Raise Hand):** হোস্টের কাছে মাইক অন করার রিকোয়েস্ট পাঠাতে '✋ হাত তুলুন' বাটনে চাপুন।",
        "live_voice_select_acc": "🎙️ **লাইভে ভয়েস পাঠাতে অ্যাকাউন্ট সিলেক্ট করুন:**\n\nকোন অ্যাকাউন্টের মাইক দিয়ে লাইভে কথা বা ভয়েস শোনাতে চান? নিচের তালিকা থেকে সিলেক্ট করুন:",
        "live_voice_send_prompt": "🎙️ **লাইভে শোনানোর জন্য অডিও পাঠান:**\n\n🔹 **একটি অডিও:** একটি ভয়েস বা MP3 পাঠালে সিলেক্ট করা সব অ্যাকাউন্টে সেট হবে।\n🔹 **একের পর এক বা একসাথে একাধিক অডিও:** একাধিক অডিও পাঠালে প্রতিটি অ্যাকাউন্টে ১টি করে অডিও আলাদাভাবে সেট হয়ে যাবে!\n🔹 **বাল্ক জিপ (.zip):** একাধিক অডিও সম্বলিত একটি `.zip` ফাইল পাঠালেও স্বয়ংক্রিয়ভাবে অ্যাকাউন্টগুলোতে অডিও ভাগ হয়ে যাবে।\n\n📌 **নিয়ম:** হোস্ট মাইক অন করলেই অডিওটি **একবার বাজবে** এবং শেষ হলে মাইক অটো মিউট হয়ে যাবে।\n\nআপলোড সম্পন্ন হলে নিচে **[✅ সম্পন্ন (Done)]** চাপুন বা বাতিল করতে `/cancel` লিখুন।",
        "live_voice_playing": "🎙️ **ভয়েস অডিও সফলভাবে প্রস্তুত করা হয়েছে!**\n\n⏳ **স্ট্যাটাস:** ভয়েস লোড ও আর্ম করা হয়েছে।\nলাইভ হোস্ট আপনার অ্যাকাউন্টের মাইক চালু (Unmute) করার সাথে সাথেই ০:০০ সেকেন্ড থেকে পুরো ভয়েসটি লাইভে বাজতে শুরু করবে!\n\n**Details:**\n{details}",
        "live_voice_raise_hand_done": "✋ **লাইভে হাত তোলা (Raise Hand) সম্পন্ন হয়েছে!**\n\nহোস্টের স্ক্রিনে কথা বলার অনুমতির রিকোয়েস্ট পৌঁছেছে। হোস্ট মাইক অন করলেই অডিও শোনা যাবে!\n\n**Details:**\n{details}",
        "live_voice_unmuted_done": "🔊 **মাইক সফলভাবে আনমিউট করা হয়েছে।**\n\n**Details:**\n{details}",
        "live_voice_muted_done": "🔇 **মাইক সফলভাবে মিউট করা হয়েছে।**\n\n**Details:**\n{details}",
        "live_voice_stopped_done": "⏹️ **লাইভ ভয়েস বাজানো বন্ধ করা হয়েছে।**\n\n**Details:**\n{details}",
        "inbox_select_account": "📤 **ইনবক্সে মেসেজ পাঠান:**\n\nকোন অ্যাকাউন্টটি ব্যবহার করে মেসেজ বা ফাইল পাঠাতে চান? নিচের তালিকা থেকে সিলেক্ট করুন (পরবর্তী ধাপে আপনি যাকে পাঠাতে চান তার User ID বা Username দিতে পারবেন):",
        "inbox_target_prompt": "🎯 **টার্গেট User ID বা Username দিন:**\n\nযে ইউজারের ইনবক্সে মেসেজ পাঠাতে চান তার Telegram **User ID** (যেমন: `123456789`) অথবা **Username** (যেমন: `@username`) লিখে পাঠান।\n\n💡 *নিজের অ্যাকাউন্টে পাঠাতে চাইলে নিচের বাটনে চাপুন:*",
        "inbox_prompt": "✍️ **কী পাঠাতে চান?**\n\n🎯 প্রাপক (Target): `{target}`\n\n🔹 **সাধারণ মেসেজ বা ছবি:** যেকোনো লেখা বা ছবি পাঠান।\n🔹 **Enter দিয়ে বাল্ক মেসেজ (সব অ্যাকাউন্টের জন্য):**\nপ্রতিটি লাইনে Enter দিয়ে আলাদা আলাদা মেসেজ লিখে পাঠালে সবগুলো অ্যাকাউন্ট থেকে ভিন্ন ভিন্ন লাইন সেন্ড হবে! যেমন:\n`hi`\n`hello`\n`how are you`\n`where are you`\n🔹 **একাধিক ছবি ও ক্যাপশন:** একাধিক ছবি বা ফাইল পাঠান।\n\nবাতিল করতে `/cancel` লিখুন।",
        "inbox_sending": "⏳ ইনবক্সে মেসেজ পাঠানো হচ্ছে...",
        "inbox_completed": "🏁 **ইনবক্সে পাঠানো সম্পন্ন!**\n\n🎯 প্রাপক: `{target}`\n✅ সফল: **{success}/{total}**\n\n**Details:**\n{details}",
        "join_prompt": "🚀 **লাইভে জয়েন করুন:**\n\nঅনুগ্রহ করে যে গ্রুপ বা চ্যানেলের লাইভে জয়েন করাতে চান তার **লিংক বা ইউজারনেম** পাঠান:\n\nউদাহরণ:\n🔹 `https://t.me/FreedomBase`\n🔹 `@FreedomBase`\n🔹 `https://t.me/+InviteHash`\n\nবাতিল করতে `/cancel` চাপুন।",
        "join_starting": "🚀 **লাইভ জয়েনিং শুরু হচ্ছে...**\n\n🎯 Target: `{target}`\n👥 অ্যাকাউন্ট সংখ্যা: **{total} টি**\n⏳ অনুগ্রহ করে অপেক্ষা করুন...",
        "join_progress": "🚀 **লাইভ জয়েনিং চলছে...**\n\n🎯 Target: `{target}`\nProgress: **{current}/{total}**\n✅ Joined: **{success}** | ❌ Failed: **{failed}**",
        "join_completed": "🏁 **লাইভ জয়েনিং সম্পন্ন!**\n\n🎯 Target: `{target}`\n👥 আপনার মোট অ্যাকাউন্ট: **{total}**\n✅ সফলভাবে যুক্ত: **{success}**\n❌ ব্যর্থ: **{failed}**\n\n**Details:**\n{details}",
        "no_accounts": "⚠️ আপনার কোনো অ্যাকাউন্ট যুক্ত নেই! আগে '➕ Add Account' বাটন দিয়ে অ্যাকাউন্ট যোগ করুন।",
        "no_accounts_in_call": "⚠️ আপনার কোনো অ্যাকাউন্ট বর্তমানে লাইভে নেই! আগে '🚀 Join Live' দিয়ে লাইভে জয়েন করান।",
        "leave_progress": "⏳ আপনার অ্যাকাউন্টগুলো লাইভ থেকে বের করা হচ্ছে...",
        "leave_completed": "🛑 **লাইভ ত্যাগ সম্পন্ন!**\n\n👥 আপনার মোট অ্যাকাউন্ট: **{total}**\n✅ Disconnected: **{success}**",
        "status_title": "📊 **আপনার অ্যাকাউন্টের স্ট্যাটাস:**\n\n🔹 মোট অ্যাকাউন্ট: **{total}**\n🔹 লাইভে যুক্ত আছে: **{in_call}**\n🔹 ফ্রি/আইডল: **{idle}**",
        "add_phone": "📱 **নতুন অ্যাকাউন্ট যুক্ত করুন:**\n\nঅনুগ্রহ করে আপনার টেলিগ্রাম অ্যাকাউন্টের **ফোন নম্বরটি কান্ট্রি কোডসহ** লিখে পাঠান।\nউদাহরণ: `+88017XXXXXXXX` অথবা `+1234567890`\n\nবাতিল করতে `/cancel` লিখুন।",
        "code_sent": "📩 **লগইন ওটিপি কোড পাঠানো হয়েছে!**\n\nঅনুগ্রহ করে আপনার টেলিগ্রাম অ্যাপে আসা কোডটি লিখে পাঠান (যেমন: `12345` বা `1 2 3 4 5`):",
        "code_sent_dynamic": "📩 **লগইন ওটিপি পাঠানো হয়েছে!**\n\nকোড পাঠানো হয়েছে: **{dest}**\n\nঅনুগ্রহ করে কোডটি লিখে পাঠান (যেমন: `12345` বা `1 2 3 4 5`):\n\nবাতিল করতে `/cancel` লিখুন।",
        "phone_not_registered": "⚠️ **এই নম্বরে কোনো টেলিগ্রাম অ্যাকাউন্ট খোলা নেই!**\n\n📌 **করণীয়:**\n১. আপনার মোবাইলের অফিশিয়াল টেলিগ্রাম অ্যাপে (Play Store / App Store) এই নম্বর দিয়ে একটি অ্যাকাউন্ট খুলে (Sign Up) নিন।\n২. অ্যাকাউন্ট খোলা সম্পন্ন হলে পুনরায় এখানে এসে '➕ Add Account' বাটন চাপুন।",
        "two_factor": "🔐 **Two-Step Verification (2FA) সক্রিয় আছে!**\n\nঅনুগ্রহ করে আপনার ২-স্টেপ পাসওয়ার্ডটি লিখে পাঠান:",
        "login_success": "🎉 **আপনার অ্যাকাউন্ট সফলভাবে যুক্ত হয়েছে!**\n\n👤 Name: **{name}**\n🆔 ID: `{id}`\n👥 আপনার মোট অ্যাকাউন্ট: **{total} টি**",
        "choose_count": "🔢 **কতটি অ্যাকাউন্ট দিয়ে লাইভে জয়েন করাতে চান?**\n\n🎯 Target: `{target}`\n👥 আপনার মোট অ্যাকাউন্ট: **{total} টি**\n\nনিচের বাটন চাপুন অথবা সংখ্যা লিখে পাঠান (যেমন: `5`):",
        "custom_comment_prompt": "✍️ **স্পেশাল কমেন্ট পাঠান:**\n\nলাইভে কী কমেন্ট পাঠাতে চান তা লিখে মেসেজ দিন (একাধিক কমেন্ট হলে প্রতি লাইনে একটি করে লিখতে পারেন):\n\nবাতিল করতে `/cancel` লিখুন।",
        "ai_comment_prompt": "✍️ **Special AI Humanize Comment:**\n\nলাইভে কী বিষয় নিয়ে আলোচনা হচ্ছে এবং আপনার অ্যাকাউন্টগুলো কী ধরণের মন্তব্য করবে তা বিস্তারিত লিখে পাঠান।\n\n💡 **টিপ্স:** যত বেশি নিখুঁত ডিটেইলিং দিয়ে আপনি আপনার বিষয়গুলো বলবেন, আমাদের AI দ্বারা তৈরি কমেন্টগুলো তত বেশি বাস্তবসম্মত, প্রাকৃতিক ও হিউম্যানাইজড (Humanized) হবে!\n\n📝 **একটি চমৎকার বিস্তারিত উদাহরণ:**\n*\"আমরা একটি অনলাইন ক্রিপ্টো ও ফরেক্স ট্রেডিং লাইভ স্ট্রিমে আছি। হোস্ট নতুনদের জন্য রিস্ক ম্যানেজমেন্ট নিয়ে কথা বলছেন। আমাদের অ্যাকাউন্টগুলো যেন হোস্টের চমৎকার উপস্থাপনার প্রশংসা করে, লাইভ স্ট্রীমের পয়েন্টগুলোকে সমর্থন জানায় এবং কিছু স্বাভাবিক ও বুদ্ধিমান প্রশ্ন করে (যেমন: 'স্টপ লস কত পার্সেন্ট রাখা নিরাপদ ভাই?', 'আজকের মার্কেট এনালাইসিস অসাধারণ ছিল') এবং স্বাভাবিক ইমোজি ব্যবহার করে।\"*\n\nআমাদের AI আপনার বিস্তারিত বিবরণ বিশ্লেষণ করে লাইভ চ্যাটে হুবহু রিয়েল মানুষের মতো কমেন্ট তৈরি করে পোস্ট করবে।\n\n📊 **আজকের ফ্রি AI ব্যালেন্স:** {balance}\n\nবাতিল করতে `/cancel` লিখুন।",
        "ai_generating": "🤖 **আমাদের AI রিয়েলিস্টিক কমেন্ট তৈরি করছে...**\n⏳ অনুগ্রহ করে কিছুক্ষণ অপেক্ষা করুন...",
        "ai_comments_preview": "✨ **আমাদের AI দ্বারা তৈরি কমেন্টসমূহ:**\n{preview}\n\n💬 লাইভে কমেন্ট পাঠানো হচ্ছে...",
        "ai_limit_reached": "🚫 **দৈনিক ফ্রি লিমিট শেষ!**\n\nআপনি আজকের জন্য নির্ধারিত **১০টি ফ্রি স্পেশাল AI কমেন্ট/মেসেজ** ব্যবহার করে ফেলেছেন।\n\n💎 **আনলিমিটেড স্পেশাল AI কমেন্ট করতে সাবস্ক্রিপশন প্রয়োজন!**\nসাবস্ক্রিপশন নিতে বা প্রিমিয়াম অ্যাক্সেস আনলক করতে অ্যাডমিনের সাথে যোগাযোগ করুন:\n\n👑 **Admin Support:** {admin_contact}",
        "manual_limit_reached": "🚫 **দৈনিক ম্যানুয়াল কমেন্ট লিমিট শেষ!**\n\nআপনি আজকের জন্য নির্ধারিত **৫টি ফ্রি ম্যানুয়াল কমেন্ট/মেসেজ** ব্যবহার করে ফেলেছেন।\n\n💎 **আনলিমিটেড ম্যানুয়াল কমেন্ট করতে সাবস্ক্রিপশন প্রয়োজন!**\nসাবস্ক্রিপশন নিতে বা প্রিমিয়াম অ্যাক্সেস আনলক করতে অ্যাডমিনের সাথে যোগাযোগ করুন:\n\n👑 **Admin Support:** {admin_contact}",
        "attachment_comment_prompt": "📎 **ম্যানুয়াল কমেন্ট (ছবি/ভিডিও/ফাইল/ভয়েস/টেক্সট সহ):**\n\nআপনি আপনার অ্যাকাউন্টগুলো দিয়ে লাইভে যা পোস্ট করাতে চান তা এখানে লিখে বা ফাইল সংযুক্ত করে পাঠান:\n\n🔹 **ছবি (Photo)** - ক্যাপশনসহ বা ছাড়া ছবি পাঠাতে পারেন।\n🔹 **ভিডিও (Video)** - ক্যাপশনসহ ভিডিও পাঠাতে পারেন।\n🔹 **ডকুমেন্ট / ফাইল (File/Doc)** - যেকোনো ফাইল বা পিডিএফ পাঠাতে পারেন।\n🔹 **ভয়েস / অডিও (Voice/Audio)** - ভয়েস বা অডিও পাঠাতে পারেন।\n🔹 অথবা সাধারণ **টেক্সট কমেন্ট** লিখে পাঠাতে পারেন।\n\nপরবর্তী ধাপে আপনি বেছে নিতে পারবেন কোন অ্যাকাউন্ট থেকে এটি পোস্ট হবে।\n\n📊 **আজকের ফ্রি ম্যানুয়াল ব্যালেন্স:** {balance}\n\nবাতিল করতে `/cancel` লিখুন।",
        "choose_account_for_comment": "🎯 **কোন অ্যাকাউন্ট থেকে লাইভে পোস্ট করতে চান?**\n\nনিচের তালিকা থেকে আপনার কাঙ্ক্ষিত অ্যাকাউন্টটি নির্বাচন করুন:",
        "attachment_starting": "📎 **লাইভে মিডিয়া/কমেন্ট পাঠানো শুরু হচ্ছে...**\n⏳ অনুগ্রহ করে অপেক্ষা করুন...",
        "attachment_completed": "🏁 **ম্যানুয়াল কমেন্ট পাঠানো সম্পন্ন!**\n\n✅ সফল: **{success}/{total}**\n\n**Details:**\n{details}",
        "comment_starting": "💬 **লাইভে কমেন্ট পাঠানো শুরু হচ্ছে...**\n⏳ অনুগ্রহ করে অপেক্ষা করুন...",
        "comment_completed": "🏁 **কমেন্ট পাঠানো সম্পন্ন!**\n\n✅ সফল কমেন্ট: **{success}/{total}**\n\n**Details:**\n{details}",
        "login_canceled": "❌ প্রক্রিয়াটি বাতিল করা হয়েছে।",
        "lang_switched": "🌐 ভাষা পরিবর্তন করে **বাংলা** করা হয়েছে।"
    },
    "en": {
        "start_title": "🤖 **Telegram Multi-Account Live Joiner Panel**",
        "welcome": "Welcome **{name}**!",
        "desc": "Manage multiple Telegram accounts and join any Telegram Live Stream or Voice Chat simultaneously.",
        "acc_count": "📊 Your connected accounts: **{count}**",
        "commands": "📌 **Commands:**\n🔹 `/join <link>` - Join Live Stream\n🔹 `/leave` - Leave Live Stream\n🔹 `/comment <text>` - Send Live Comment\n🔹 `/accounts` - View accounts list\n🔹 `/add` - Connect new account\n🔹 `/status` - View live status",
        "choose_btn": "Use the buttons below to control the bot:",
        "btn_accounts": "👥 Manage Accounts",
        "btn_add": "➕ Add New Account",
        "btn_join": "🚀 Join Live Stream",
        "btn_leave": "🛑 Leave Live Stream",
        "btn_random_comment": "🎲 Random Comments",
        "btn_custom_comment": "✍️ Custom Comment",
        "btn_ai_comment": "🤖 AI Smart Comments",
        "btn_attachment_comment": "📎 Media Comment",
        "btn_send_to_me": "✉️ Send Direct Message",
        "btn_live_voice": "🎙️ Live Voice / Mic",
        "btn_status": "💎 Profile & Status",
        "btn_lang": "🌐 Language",
        "btn_cancel": "❌ Cancel",
        "live_voice_panel_title": "🎙️ **Live Voice & Mic Control**\n\n🎯 Current Live: **{title}**\n👥 Accounts in Live: **{count}**\n\n💡 **How it works:**\n1. **Set Voice Audio:** Click '🎙️ Send Voice Audio' below and send a voice note or audio file.\n2. **Plays when Host Unmutes:** As soon as the live stream host turns on (unmutes) your account's mic, your voice note will automatically play into the live stream!\n3. **Raise Hand:** Click '✋ Raise Hand' to request speak permission from the host.",
        "live_voice_select_acc": "🎙️ **Select Account for Live Voice:**\n\nWhich account would you like to broadcast voice from? Choose below:",
        "live_voice_send_prompt": "🎙️ **Send Audio to Broadcast in Live:**\n\n🔹 **Single Audio:** Send 1 voice note or MP3 (assigned to all selected accounts).\n🔹 **Multiple Audios (One-by-one or batch):** Send multiple audios and each account gets 1 audio automatically!\n🔹 **Bulk Zip (.zip):** Send a `.zip` archive containing multiple audio files to distribute across accounts.\n\n📌 **Rule:** When the live host unmutes an account, its audio plays **once** and the mic auto-mutes upon ending.\n\nWhen done, click **[✅ Done]** below or send `/cancel` to abort.",
        "live_voice_playing": "🎙️ **Voice audio is ready & armed!**\n\n⏳ **Status:** Staged and waiting.\nAs soon as the live host unmutes your mic, your voice will immediately start playing into the live stream from the very beginning (0:00)!\n\n**Details:**\n{details}",
        "live_voice_raise_hand_done": "✋ **Raise Hand request sent to live host!**\n\nThe host now sees your request to speak. Once they turn on your mic, your audio will be heard!\n\n**Details:**\n{details}",
        "live_voice_unmuted_done": "🔊 **Mic successfully unmuted!**\n\n**Details:**\n{details}",
        "live_voice_muted_done": "🔇 **Mic successfully muted.**\n\n**Details:**\n{details}",
        "live_voice_stopped_done": "⏹️ **Voice playback stopped.**\n\n**Details:**\n{details}",
        "inbox_select_account": "📤 **Send Message to Inbox:**\n\nSelect which account you want to use to send a message or media to an inbox (in next step you can specify any User ID or Username):",
        "inbox_target_prompt": "🎯 **Enter Target User ID or Username:**\n\nPlease enter the Telegram **User ID** (e.g. `123456789`) or **Username** (e.g. `@username`) of the recipient.\n\n💡 *To send to your own inbox, click the button below:*",
        "inbox_prompt": "✍️ **What would you like to send?**\n\n🎯 Target: `{target}`\n\n🔹 **Single Message or Photo:** Send any text or photo.\n🔹 **Bulk Messages with Enter (for All Accounts):**\nType multiple messages separated by Enter (new line), e.g.:\n`hi`\n`hello`\n`how are you`\n`where are you`\nEach connected account will send a different line from your text to the recipient!\n🔹 **Multiple Photos with Captions:** Send multiple photos one-by-one or in an album.\n\nSend `/cancel` to abort.",
        "inbox_sending": "⏳ Sending to inbox...",
        "inbox_completed": "🏁 **Delivered to Inbox!**\n\n🎯 Target: `{target}`\n✅ Successful: **{success}/{total}**\n\n**Details:**\n{details}",
        "join_prompt": "🚀 **Join Live Stream:**\n\nPlease send the **group or channel link / username** where you want to join:\n\nExamples:\n🔹 `https://t.me/FreedomBase`\n🔹 `@FreedomBase`\n🔹 `https://t.me/+InviteHash`\n\nSend `/cancel` to cancel.",
        "join_starting": "🚀 **Joining Live Stream...**\n\n🎯 Target: `{target}`\n👥 Accounts: **{total}**\n⏳ Please wait...",
        "join_progress": "🚀 **Joining in progress...**\n\n🎯 Target: `{target}`\nProgress: **{current}/{total}**\n✅ Joined: **{success}** | ❌ Failed: **{failed}**",
        "join_completed": "🏁 **Live Joining Finished!**\n\n🎯 Target: `{target}`\n👥 Total Accounts: **{total}**\n✅ Joined: **{success}**\n❌ Failed: **{failed}**\n\n**Details:**\n{details}",
        "no_accounts": "⚠️ No accounts connected yet! Click '➕ Add Account' to link your Telegram account.",
        "no_accounts_in_call": "⚠️ None of your accounts are currently in a live stream! Join a live stream first.",
        "leave_progress": "⏳ Disconnecting accounts from live stream...",
        "leave_completed": "🛑 **Left Live Stream!**\n\n👥 Accounts: **{total}**\n✅ Disconnected: **{success}**",
        "status_title": "📊 **Your Account Status:**\n\n🔹 Total Accounts: **{total}**\n🔹 In Active Live: **{in_call}**\n🔹 Free/Idle: **{idle}**",
        "add_phone": "📱 **Connect New Account:**\n\nPlease send your Telegram account **phone number with country code**.\nExample: `+88017XXXXXXXX` or `+1234567890`\n\nSend `/cancel` to cancel.",
        "code_sent": "📩 **Telegram Login Code Sent!**\n\nPlease enter the OTP code you received in your Telegram app (e.g. `12345` or `1 2 3 4 5`):",
        "code_sent_dynamic": "📩 **Login OTP Code Sent!**\n\nCode delivered to: **{dest}**\n\nPlease enter the OTP code you received (e.g. `12345` or `1 2 3 4 5`):\n\nSend `/cancel` to cancel.",
        "phone_not_registered": "⚠️ **No Telegram account found with this phone number!**\n\n📌 **What to do:**\n1. Download the official Telegram app on your mobile (Play Store / App Store).\n2. Sign up and create a Telegram account with this number.\n3. Once created, come back here and click '➕ Add Account' again.",
        "two_factor": "🔐 **Two-Step Verification (2FA) is enabled!**\n\nPlease enter your 2-Step Password:",
        "login_success": "🎉 **Account Connected Successfully!**\n\n👤 Name: **{name}**\n🆔 ID: `{id}`\n👥 Total Accounts: **{total}**",
        "choose_count": "🔢 **How many accounts do you want to join?**\n\n🎯 Target: `{target}`\n👥 Your total accounts: **{total}**\n\nSelect a button below or type a number (e.g. `5`):",
        "custom_comment_prompt": "✍️ **Send Special Comment:**\n\nEnter the comment message you want your accounts to post in live stream (or multiple comments line-by-line):\n\nSend `/cancel` to cancel.",
        "ai_comment_prompt": "✍️ **Special AI Humanize Comment:**\n\nPlease describe the live stream topic and the style of comments you want in detail.\n\n💡 **Tip:** The more detailed and specific you are, the more natural and humanized the comments will be!\n\n📝 **A Detailed Example:**\n*\"We are watching a crypto trading live stream. The host is talking about beginner risk management. Have our accounts praise the host's clear delivery, agree with the key points, and ask smart natural questions (e.g. 'What is a safe stop loss percentage bro?', 'Today's market breakdown was incredible') using realistic emojis.\"*\n\nOur AI will analyze your prompt and generate authentic human-like live comments.\n\n📊 **Daily Free AI Balance:** {balance}\n\nSend `/cancel` to cancel.",
        "ai_generating": "🤖 **Our AI is generating realistic comments...**\n⏳ Please wait a moment...",
        "ai_comments_preview": "✨ **Comments Generated by Our AI:**\n{preview}\n\n💬 Posting to live stream chat...",
        "ai_limit_reached": "🚫 **Daily Free Limit Reached!**\n\nYou have used your **10 free Special AI Comment/Messages** for today.\n\n💎 **A subscription is required for unlimited Special AI Comments!**\nTo subscribe or upgrade your account, please contact the Admin:\n\n👑 **Admin Support:** {admin_contact}",
        "manual_limit_reached": "🚫 **Daily Manual Limit Reached!**\n\nYou have used your **5 free manual comments/messages** for today.\n\n💎 **A subscription is required for unlimited Manual Comments!**\nTo subscribe or upgrade your account, please contact the Admin:\n\n👑 **Admin Support:** {admin_contact}",
        "attachment_comment_prompt": "📎 **Manual Comment (with Photo/Video/File/Voice/Text):**\n\nPlease send the content you want your accounts to post in the live stream:\n\n🔹 **Photo** - Send a photo with or without caption.\n🔹 **Video** - Send a video with caption.\n🔹 **Document / File** - Send files or PDFs.\n🔹 **Voice / Audio** - Send voice notes or audio.\n🔹 Or simply send plain **Text**.\n\nIn the next step, you will be able to choose which account to send it from.\n\n📊 **Daily Free Manual Balance:** {balance}\n\nSend `/cancel` to cancel.",
        "choose_account_for_comment": "🎯 **Which account do you want to post from?**\n\nPlease select an account from the list below:",
        "attachment_starting": "📎 **Sending media/comment to live stream...**\n⏳ Please wait...",
        "attachment_completed": "🏁 **Manual Comment Sent!**\n\n✅ Successful: **{success}/{total}**\n\n**Details:**\n{details}",
        "comment_starting": "💬 **Sending comments to live stream...**\n⏳ Please wait...",
        "comment_completed": "🏁 **Comments Sent!**\n\n✅ Successful: **{success}/{total}**\n\n**Details:**\n{details}",
        "login_canceled": "❌ Process has been canceled.",
        "lang_switched": "🌐 Language switched to **English**."
    }
}

def tr(user_id: int, key: str, **kwargs) -> str:
    lang = get_user_lang(user_id)
    text = STRINGS.get(lang, STRINGS["en"]).get(key, STRINGS["en"].get(key, ""))
    if kwargs:
        text = text.format(**kwargs)
    return text
