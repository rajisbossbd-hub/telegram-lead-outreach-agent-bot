import os
import re
import random
import asyncio
import logging
import time
import urllib.parse
import zipfile
from datetime import datetime
from pathlib import Path
from typing import Optional, Tuple, List, Dict, Union
from pyrogram import Client, filters
from pyrogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from pyrogram.errors import (
    SessionPasswordNeeded,
    PhoneCodeInvalid,
    PhoneCodeExpired,
    PasswordHashInvalid,
    FloodWait,
    MessageNotModified
)
import config
from core.account_manager import AccountManager
from core.ai_generator import generate_ai_comments
from core.subscription import (
    can_use_ai,
    record_ai_usage,
    get_remaining_ai_balance,
    can_use_manual,
    record_manual_usage,
    get_remaining_manual_balance,
    is_super_admin,
    is_admin,
    get_super_admin_id,
    get_admins_list,
    add_admin_user,
    remove_admin_user,
    is_vip,
    add_vip_user,
    remove_vip_user,
    get_vip_list,
    get_user_badge_info,
    can_join_live,
    set_live_cooldown,
    NORMAL_USER_LIVE_LIMIT_SECONDS,
    NORMAL_USER_LIVE_COOLDOWN_SECONDS,
    can_use_live_voice,
    record_live_voice_usage,
    get_remaining_live_voice_balance,
    can_use_poll_vote,
    record_poll_usage,
    get_remaining_poll_balance,
    can_use_post_engage,
    record_engage_usage,
    get_remaining_engage_balance,
    FREE_DAILY_LIVE_VOICE_LIMIT,
    FREE_DAILY_POLL_ACCOUNT_LIMIT,
    FREE_DAILY_ENGAGE_ACCOUNT_LIMIT
)
from bot.keyboards import (
    main_menu_keyboard,
    cancel_keyboard,
    accounts_list_keyboard,
    account_delete_confirm_keyboard,
    count_selection_keyboard,
    subscription_keyboard,
    status_keyboard,
    account_selector_keyboard,
    inbox_account_selector_keyboard,
    inbox_target_keyboard,
    inbox_send_now_keyboard,
    live_voice_control_keyboard,
    voice_account_selector_keyboard,
    raise_hand_account_selector_keyboard,
    voice_upload_progress_keyboard,
    admin_panel_keyboard,
    post_engage_mode_keyboard,
    reaction_selection_keyboard,
    poll_options_keyboard,
    generic_account_selector_keyboard,
    auto_monitor_menu_keyboard,
    auto_monitor_detail_keyboard,
    auto_reaction_choice_keyboard,
    live_inspection_action_keyboard,
    live_dm_count_keyboard,
    live_discovery_categories_keyboard,
    live_target_filter_keyboard,
    group_discovery_categories_keyboard,
    country_selector_keyboard,
    get_country_badge,
    auto_live_menu_keyboard,
    auto_live_list_keyboard,
    auto_live_target_detail_keyboard,
    auto_live_count_selection_keyboard
)
from core.auto_monitor import (
    get_user_monitors,
    get_monitor_by_id,
    add_channel_monitor,
    toggle_monitor_status,
    delete_monitor,
    update_monitor_reaction,
    get_all_active_monitors,
    delete_all_user_monitors,
    toggle_all_user_monitors
)
from core.auto_live_joiner import (
    get_user_live_targets,
    get_live_target_by_id,
    add_live_target,
    toggle_live_target,
    update_live_target_count,
    delete_live_target
)
from bot.strings import tr, get_user_lang, set_user_lang, RANDOM_COMMENTS

logger = logging.getLogger(__name__)

# State dicts for interactive flows
user_login_states = {}   # {user_id: {"step": "PHONE|CODE|2FA", ...}}
user_action_states = {}  # {user_id: {"action": "AWAITING_JOIN_LINK|AWAITING_COUNT|AWAITING_CUSTOM_COMMENT", ...}}
user_live_tasks = {}     # {user_id: asyncio.Task for 30-min auto disconnect}
user_live_start_times = {} # {user_id: float timestamp}
admin_country_preferences = {} # {admin_id: "BD"|"IN"|"PK"|"US"|"GLOBAL"}

def parse_telegram_post_link(link: str) -> Optional[Tuple[Union[str, int], int]]:
    """Parses a telegram message/post link into (chat_id, message_id)."""
    clean = link.strip().replace("http://", "").replace("https://", "")
    m_priv = re.match(r"^t\.me/c/(\d+)/(\d+)", clean)
    if m_priv:
        cid = int(f"-100{m_priv.group(1)}")
        mid = int(m_priv.group(2))
        return cid, mid

    m_pub = re.match(r"^t\.me/([a-zA-Z0-9_]+)/(\d+)", clean)
    if m_pub:
        cid = m_pub.group(1)
        mid = int(m_pub.group(2))
        return cid, mid

    return None

def register_handlers(bot: Client, manager: AccountManager):

    def get_cooldown_message(user_id: int, remaining_seconds: int, contact_url: str) -> Tuple[str, InlineKeyboardMarkup]:
        lang = get_user_lang(user_id)
        mins = remaining_seconds // 60
        secs = remaining_seconds % 60
        time_str = f"**{mins} মিনিট {secs} সেকেন্ড**" if lang == "bn" else f"**{mins}m {secs}s**"

        if lang == "bn":
            text = (
                "⏳ **১০ মিনিটের বিরতি (Cooldown) কার্যকর আছে!**\n\n"
                "সাধারণ (Normal) অ্যাকাউন্টের জন্য একটানা ৩০ মিনিট লাইভে থাকার পর **১০ মিনিটের বিরতি** প্রযোজ্য।\n\n"
                f"⏱️ আপনি পুনরায় {time_str} পর লাইভে জয়েন করতে পারবেন (পরবর্তী একটানা ৩০ মিনিটের জন্য)।\n\n"
                "💎 **বিরতিহীনভাবে একটানা ২৪/৭ আনলিমিটেড লাইভে থাকতে চান?**\n"
                "কোনো সময়সীমা বা কুলডাউন ছাড়া লাইভে থাকতে VIP মেম্বারশিপ নিন!"
            )
        else:
            text = (
                "⏳ **10-Minute Cooldown Break Active!**\n\n"
                "For Normal Users, after 30 minutes of continuous live streaming, a **10-minute cooldown** applies.\n\n"
                f"⏱️ You can rejoin in {time_str} (for another 30-minute session).\n\n"
                "💎 **Want 24/7 continuous unlimited live streaming without breaks?**\n"
                "Upgrade to VIP membership to bypass all session limits and cooldowns!"
            )
        kb = status_keyboard(user_id, contact_url=contact_url)
        return text, kb

    async def monitor_user_live_limit(user_id: int):
        import time
        user_live_start_times[user_id] = time.time()
        try:
            await asyncio.sleep(NORMAL_USER_LIVE_LIMIT_SECONDS)
            # Check if user is still in live call
            engines = manager.get_user_engines(user_id)
            in_call_count = sum(1 for e in engines.values() if e.in_call)
            if in_call_count > 0:
                await manager.leave_for_user(user_id)
                set_live_cooldown(user_id, NORMAL_USER_LIVE_COOLDOWN_SECONDS)
                _, contact_url = await get_admin_contact(user_id=user_id)
                kb = status_keyboard(user_id, contact_url=contact_url)
                lang = get_user_lang(user_id)
                if lang == "bn":
                    msg = (
                        "🛑 **৩০ মিনিটের লাইভ সেশন সমাপ্ত!**\n\n"
                        "সাধারণ (Normal) অ্যাকাউন্টের জন্য একটানা লাইভে থাকার সর্বোচ্চ সময়সীমা **৩০ মিনিট** পূর্ণ হওয়ায় আপনার অ্যাকাউন্টগুলো লাইভ থেকে স্বয়ংক্রিয়ভাবে ডিসকানেক্ট করা হয়েছে।\n\n"
                        "⏳ নিয়ম অনুযায়ী পরবর্তী **১০ মিনিট বিরতি (Cooldown)** কার্যকর থাকবে। ১০ মিনিট পর আপনি পুনরায় একটানা ৩০ মিনিটের জন্য লাইভে জয়েন করতে পারবেন।\n\n"
                        "💎 **একটানা ২৪/৭ আনলিমিটেড লাইভে থাকতে চান?**\n"
                        "VIP মেম্বারশিপে আপগ্রেড করুন এবং কোনো সময়সীমা বা বিরতি ছাড়াই লাইভ উপভোগ করুন!"
                    )
                else:
                    msg = (
                        "🛑 **30-Minute Live Session Limit Reached!**\n\n"
                        "Your continuous live stream limit of **30 minutes** for Normal Users has expired. Your accounts have been automatically disconnected.\n\n"
                        "⏳ A **10-minute cooldown break** is now in effect. You can rejoin for another 30 minutes once the 10 minutes pass.\n\n"
                        "💎 **Want 24/7 unlimited continuous live streaming without breaks?**\n"
                        "Upgrade to VIP membership to enjoy unlimited live streaming with zero cooldown!"
                    )
                try:
                    await bot.send_message(chat_id=user_id, text=msg, reply_markup=kb)
                except Exception as e:
                    logger.error(f"Failed to send session limit notification to user {user_id}: {e}")
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error(f"Error in monitor_user_live_limit for user {user_id}: {e}")
        finally:
            user_live_tasks.pop(user_id, None)
            user_live_start_times.pop(user_id, None)

    def get_main_menu_content(user_id: int, first_name: str) -> str:
        accounts = manager.get_user_accounts_list(user_id)
        badge = get_user_badge_info(user_id)
        lang = get_user_lang(user_id)

        if lang == "bn":
            tier_badge = badge["badge_bn"]
            if badge["is_vip"]:
                tier_line = f"🏷️ আপনার মেম্বারশিপ: {tier_badge} ✨\n*(আপনার অ্যাকাউন্টে আনলিমিটেড লাইভ কমেন্ট সক্রিয় আছে 🚀)*"
            else:
                can_ai, used_ai, lim_ai = can_use_ai(user_id)
                can_m, used_m, lim_m = can_use_manual(user_id)
                ai_rem = max(0, lim_ai - used_ai)
                m_rem = max(0, lim_m - used_m)
                tier_line = f"🏷️ আপনার মেম্বারশিপ: {tier_badge}\n📊 আজকের ব্যালেন্স: AI ({ai_rem}/{lim_ai}) | ম্যানুয়াল ({m_rem}/{lim_m})"
        else:
            tier_badge = badge["badge_en"]
            if badge["is_vip"]:
                tier_line = f"🏷️ Your Membership: {tier_badge} ✨\n*(Unlimited Live Comments Active 🚀)*"
            else:
                can_ai, used_ai, lim_ai = can_use_ai(user_id)
                can_m, used_m, lim_m = can_use_manual(user_id)
                ai_rem = max(0, lim_ai - used_ai)
                m_rem = max(0, lim_m - used_m)
                tier_line = f"🏷️ Your Membership: {tier_badge}\n📊 Today's Quota: AI ({ai_rem}/{lim_ai}) | Manual ({m_rem}/{lim_m})"

        text = (
            f"{tr(user_id, 'start_title')}\n\n"
            f"{tr(user_id, 'welcome', name=first_name)} {badge['symbol']}\n"
            f"{tier_line}\n\n"
            f"{tr(user_id, 'desc')}\n\n"
            f"{tr(user_id, 'acc_count', count=len(accounts))}\n\n"
            f"{tr(user_id, 'commands')}\n\n"
            f"{tr(user_id, 'choose_btn')}"
        )
        return text

    @bot.on_message(filters.command(["start", "help"]) & filters.private)
    async def cmd_start(_, message: Message):
        user_id = message.from_user.id
        first_name = message.from_user.first_name or "User"
        logger.info(f"[/start] Received command from {first_name} ({user_id})")
        text = get_main_menu_content(user_id, first_name)
        await message.reply_text(text, reply_markup=main_menu_keyboard(user_id))

    @bot.on_message(filters.command("status") & filters.private)
    async def cmd_status(_, message: Message):
        user_id = message.from_user.id
        text, kb = await render_status_view(user_id)
        await message.reply_text(text, reply_markup=kb)

    @bot.on_message(filters.command(["vip", "subscription"]) & filters.private)
    async def cmd_vip_info(_, message: Message):
        user_id = message.from_user.id
        badge = get_user_badge_info(user_id)
        lang = get_user_lang(user_id)
        admin_contact, contact_url = await get_admin_contact(user_id=user_id)
        kb = subscription_keyboard(contact_url=contact_url, user_id=user_id)
        if badge["is_vip"]:
            msg = (
                f"💎 **আপনার অ্যাকাউন্টে VIP মেম্বারশিপ সক্রিয় আছে!**\n\n"
                f"🏷️ মেম্বারশিপ: {badge['badge_bn' if lang=='bn' else 'badge_en']}\n"
                f"🚀 আপনি আনলিমিটেড Special AI এবং ম্যানুয়াল লাইভ কমেন্ট করতে পারেন।"
            ) if lang == "bn" else (
                f"💎 **You have active VIP Membership!**\n\n"
                f"🏷️ Membership: {badge['badge_en']}\n"
                f"🚀 You can send unlimited Special AI and manual live comments."
            )
            await message.reply_text(msg, reply_markup=main_menu_keyboard(user_id))
        else:
            msg = (
                "💎 **VIP মেম্বারশিপ সাবস্ক্রিপশন সুবিধা:**\n\n"
                "🔹 আনলিমিটেড Special Humanized AI লাইভ কমেন্ট\n"
                "🔹 আনলিমিটেড মিডিয়া ও কাস্টম ম্যানুয়াল কমেন্ট\n"
                "🔹 কোনো দৈনিক কোটা বা লিমিট নেই\n"
                "🔹 আপনার প্রোফাইলে থাকবে বিশেষ 💎 [VIP ELITE] স্ট্যাটাস\n\n"
                f"👑 **Admin Support:** {admin_contact}\n"
                "নিচের বাটনে ক্লিক করে সরাসরি মেসেজ দিয়ে সাবস্ক্রিপশন আনলক করুন:"
            ) if lang == "bn" else (
                "💎 **VIP Membership Benefits:**\n\n"
                "🔹 Unlimited Special Humanized AI Live Comments\n"
                "🔹 Unlimited Media and Custom Manual Comments\n"
                "🔹 No daily usage limits\n"
                "🔹 Proud 💎 [VIP ELITE] status on your profile\n\n"
                f"👑 **Admin Support:** {admin_contact}\n"
                "Click the button below to message the admin and upgrade now:"
            )
            await message.reply_text(msg, reply_markup=kb)

    @bot.on_message(filters.command("admin_stats") & filters.private)
    async def cmd_admin_stats(_, message: Message):
        user_id = message.from_user.id
        if not is_admin(user_id):
            return

        stats = manager.get_global_stats()
        vips = get_vip_list()
        text = (
            "👑 **Global System Statistics (Host View):**\n\n"
            f"👥 Total Registered Users: **{stats['unique_users']}**\n"
            f"📱 Total Accounts Hosted: **{stats['total_accounts']}**\n"
            f"🎙️ Accounts Currently in Live Calls: **{stats['in_call']}**\n"
            f"💎 VIP Subscribed Users: **{len(vips)}**\n\n"
            "📌 **VIP Commands:**\n"
            "🔹 `/set_vip <user_id>` - Grant unlimited AI\n"
            "🔹 `/del_vip <user_id>` - Revoke VIP\n"
            "🔹 `/vip_list` - View VIP users"
        )
        await message.reply_text(text)

    def format_ai_balance(user_id: int) -> str:
        lang = get_user_lang(user_id)
        if is_vip(user_id):
            return "💎 VIP Unlimited (আনলিমিটেড)" if lang == "bn" else "💎 VIP Unlimited"
        can_use, used, limit = can_use_ai(user_id)
        remaining = max(0, limit - used)
        return f"**{remaining}/{limit}** টি মেসেজ/কমেন্ট বাকি আছে" if lang == "bn" else f"**{remaining}/{limit}** comments/messages remaining"

    def format_manual_balance(user_id: int) -> str:
        lang = get_user_lang(user_id)
        if is_vip(user_id):
            return "💎 VIP Unlimited (আনলিমিটেড)" if lang == "bn" else "💎 VIP Unlimited"
        can_use, used, limit = can_use_manual(user_id)
        remaining = max(0, limit - used)
        return f"**{remaining}/{limit}** টি মেসেজ/কমেন্ট বাকি আছে" if lang == "bn" else f"**{remaining}/{limit}** comments/messages remaining"

    async def get_admin_contact(user_id: int = 0) -> Tuple[str, str]:
        """Returns (admin_display_text, contact_url). Resolves valid username or profile link with auto-prefilled message."""
        import urllib.parse
        super_admin_id = get_super_admin_id()
        admin_ids = [super_admin_id] + [aid for aid in config.ADMIN_IDS if aid != super_admin_id]

        uid_text = f"\nMy Telegram User ID: {user_id}" if user_id else ""
        prefill = f"Hey Admin! I want to be a VIP member in the Telegram Multi-Live Bot.{uid_text}"
        encoded_prefill = urllib.parse.quote(prefill)

        admin_username = "rajisboss"
        admin_display = "@rajisboss"

        for aid in admin_ids:
            try:
                u = await bot.get_users(aid)
                if u and u.username:
                    admin_username = u.username
                    admin_display = f"@{u.username}"
                    break
                elif u and u.first_name:
                    admin_display = f"[{u.first_name}](tg://user?id={aid})"
            except Exception:
                continue

        contact_url = f"https://t.me/{admin_username.lstrip('@')}?text={encoded_prefill}"
        return admin_display, contact_url

    async def render_status_view(user_id: int) -> Tuple[str, InlineKeyboardMarkup]:
        lang = get_user_lang(user_id)
        badge = get_user_badge_info(user_id)
        accounts = manager.get_user_accounts_list(user_id)
        total = len(accounts)
        in_call = sum(1 for a in accounts if a.get('is_in_call'))
        idle = total - in_call

        _, contact_url = await get_admin_contact(user_id=user_id)

        if lang == "bn":
            tier_str = badge["badge_bn"]
            if badge["is_vip"]:
                ai_bal = "💎 Unlimited (আনলিমিটেড)"
                man_bal = "💎 Unlimited (আনলিমিটেড)"
                voice_bal = "💎 Unlimited (আনলিমিটেড)"
                poll_bal = "💎 Unlimited (আনলিমিটেড)"
                eng_bal = "💎 Unlimited (আনলিমিটেড)"
                footer = "✨ *আপনার অ্যাকাউন্টে ভিআইপি সুবিধা সক্রিয় আছে! আনলিমিটেড উপভোগ করুন।*"
            else:
                can_ai, used_ai, lim_ai = can_use_ai(user_id)
                rem_ai = max(0, lim_ai - used_ai)
                ai_bal = f"**{rem_ai}/{lim_ai}** টি বাকি"
                can_m, used_m, lim_m = can_use_manual(user_id)
                rem_m = max(0, lim_m - used_m)
                man_bal = f"**{rem_m}/{lim_m}** টি বাকি"
                rem_voice = get_remaining_live_voice_balance(user_id)
                voice_bal = f"**{rem_voice}/{FREE_DAILY_LIVE_VOICE_LIMIT}** টি বাকি"
                rem_poll = get_remaining_poll_balance(user_id)
                poll_bal = f"**{rem_poll}/{FREE_DAILY_POLL_ACCOUNT_LIMIT}** টি অ্যাকাউন্ট বাকি"
                rem_eng = get_remaining_engage_balance(user_id)
                eng_bal = f"**{rem_eng}/{FREE_DAILY_ENGAGE_ACCOUNT_LIMIT}** টি অ্যাকাউন্ট বাকি"
                footer = "💡 *সব ফিচারে আনলিমিটেড অ্যাক্সেস পেতে VIP মেম্বারশিপে আপগ্রেড করুন!*"

            can_live, rem_cool = can_join_live(user_id)
            if badge["is_vip"]:
                live_limit_str = "💎 Unlimited (২৪/৭ একটানা, কোনো বিরতি নেই)"
            elif not can_live:
                live_limit_str = f"একটানা ৩০ মিনিট (⚠️ বিরতি চলছে: **{rem_cool // 60} মি. {rem_cool % 60} সে.** বাকি)"
            else:
                live_limit_str = "একটানা সর্বোচ্চ ৩০ মিনিট (১০ মিনিট বিরতি)"

            text = (
                "👤 **আপনার প্রোফাইল ও অ্যাকাউন্টের স্ট্যাটাস:**\n"
                "━━━━━━━━━━━━━━━━━━━━━\n"
                f"🆔 ইউজার আইডি: `{user_id}`\n"
                f"🏷️ মেম্বারশিপ: {tier_str}\n"
                f"⚡ Special AI কমেন্ট: {ai_bal}\n"
                f"📎 ম্যানুয়াল কমেন্ট: {man_bal}\n"
                f"🎙️ লাইভ ভয়েস (মাইক): {voice_bal}\n"
                f"🗳️ পোল ভোট কোটা: {poll_bal}\n"
                f"👁️ ভিউ ও রিঅ্যাকশন কোটা: {eng_bal}\n"
                f"👥 লাইভ জয়েন লিমিট: {'💎 Unlimited' if badge['is_vip'] else 'সর্বোচ্চ ৫টি অ্যাকাউন্ট (প্রতি লাইভে)'}\n"
                f"⏱️ লাইভ সেশন লিমিট: {live_limit_str}\n"
                "━━━━━━━━━━━━━━━━━━━━━\n"
                f"📱 মোট যুক্ত অ্যাকাউন্ট: **{total} টি**\n"
                f"🎙️ লাইভে যুক্ত অ্যাকাউন্ট: **{in_call} টি**\n"
                f"💤 আইডল/ফ্রি অ্যাকাউন্ট: **{idle} টি**\n"
                "━━━━━━━━━━━━━━━━━━━━━\n"
                f"{footer}"
            )
        else:
            tier_str = badge["badge_en"]
            can_live, rem_cool = can_join_live(user_id)
            if badge["is_vip"]:
                ai_bal = "💎 Unlimited"
                man_bal = "💎 Unlimited"
                voice_bal = "💎 Unlimited"
                poll_bal = "💎 Unlimited"
                eng_bal = "💎 Unlimited"
                live_limit_str = "💎 Unlimited (24/7 continuous, no cooldown)"
                footer = "✨ *VIP perks active! Enjoy unlimited features.*"
            else:
                can_ai, used_ai, lim_ai = can_use_ai(user_id)
                rem_ai = max(0, lim_ai - used_ai)
                ai_bal = f"**{rem_ai}/{lim_ai}** remaining"
                can_m, used_m, lim_m = can_use_manual(user_id)
                rem_m = max(0, lim_m - used_m)
                man_bal = f"**{rem_m}/{lim_m}** remaining"
                rem_voice = get_remaining_live_voice_balance(user_id)
                voice_bal = f"**{rem_voice}/{FREE_DAILY_LIVE_VOICE_LIMIT}** remaining"
                rem_poll = get_remaining_poll_balance(user_id)
                poll_bal = f"**{rem_poll}/{FREE_DAILY_POLL_ACCOUNT_LIMIT}** accounts left"
                rem_eng = get_remaining_engage_balance(user_id)
                eng_bal = f"**{rem_eng}/{FREE_DAILY_ENGAGE_ACCOUNT_LIMIT}** accounts left"
                if not can_live:
                    live_limit_str = f"30m continuous (⚠️ Cooldown active: **{rem_cool // 60}m {rem_cool % 60}s** remaining)"
                else:
                    live_limit_str = "30m continuous (10m cooldown break)"
                footer = "💡 *Upgrade to VIP for unlimited access across all features!*"

            text = (
                "👤 **Your Profile & System Status:**\n"
                "━━━━━━━━━━━━━━━━━━━━━\n"
                f"🆔 User ID: `{user_id}`\n"
                f"🏷️ Membership Status: {tier_str}\n"
                f"⚡ Special AI Comments: {ai_bal}\n"
                f"📎 Manual Comments: {man_bal}\n"
                f"🎙️ Live Voice (Mic): {voice_bal}\n"
                f"🗳️ Poll Vote Quota: {poll_bal}\n"
                f"👁️ Views & Reacts: {eng_bal}\n"
                f"👥 Live Join Limit: {'💎 Unlimited' if badge['is_vip'] else 'Max 5 accounts per live'}\n"
                f"⏱️ Live Session Limit: {live_limit_str}\n"
                "━━━━━━━━━━━━━━━━━━━━━\n"
                f"📱 Total Connected Accounts: **{total}**\n"
                f"🎙️ In Live Voice/Stream: **{in_call}**\n"
                f"💤 Idle / Free: **{idle}**\n"
                "━━━━━━━━━━━━━━━━━━━━━\n"
                f"{footer}"
            )
        kb = status_keyboard(user_id, contact_url=contact_url)
        return text, kb

    async def notify_limit_reached(target, user_id: int, is_manual: bool = False):
        admin_contact, contact_url = await get_admin_contact(user_id=user_id)
        key = "manual_limit_reached" if is_manual else "ai_limit_reached"
        text = tr(user_id, key, admin_contact=admin_contact)
        kb = subscription_keyboard(contact_url=contact_url, user_id=user_id)
        if isinstance(target, CallbackQuery):
            alert_text = "দৈনিক লিমিট শেষ!" if get_user_lang(user_id) == "bn" else "Daily limit reached!"
            await target.answer(alert_text, show_alert=True)
            await target.message.reply_text(text, reply_markup=kb)
        else:
            await target.reply_text(text, reply_markup=kb)

    async def resolve_target_user(target_str: str) -> Tuple[Optional[int], str]:
        clean = target_str.strip()
        if not clean:
            return None, ""
        
        # Pure digits
        if clean.isdigit():
            uid = int(clean)
            try:
                u = await bot.get_users(uid)
                label = f"@{u.username}" if u.username else f"User `{uid}`"
                return uid, label
            except Exception:
                return uid, f"User `{uid}`"

        # Username with or without @
        username = clean.lstrip("@")
        try:
            u = await bot.get_users(username)
            return u.id, f"@{u.username or username}"
        except Exception:
            pass

        # Try to match stored sessions username
        try:
            from core.session_store import load_accounts_registry
            reg = load_accounts_registry()
            for meta in reg.values():
                if meta.get("username", "").lower() == username.lower():
                    return meta.get("owner_id"), f"@{username}"
        except Exception:
            pass

        return None, f"@{username}"

    @bot.on_message(filters.command("set_vip") & filters.private)
    async def cmd_set_vip(_, message: Message):
        user_id = message.from_user.id
        if not is_admin(user_id):
            return
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            await message.reply_text("⚠️ Usage: `/set_vip <user_id or @username>`\nExample: `/set_vip @Rajisboss3`")
            return
        target_id, label = await resolve_target_user(parts[1])
        if not target_id:
            await message.reply_text(f"❌ ইউজার `{parts[1]}` খুঁজে পাওয়া যায়নি! সঠিক ইউজার আইডি বা ইউজারনেম দিন।")
            return
        add_vip_user(target_id)
        await message.reply_text(f"💎 **{label} (`{target_id}`) সফলভাবে VIP মেম্বার তালিকায় যুক্ত হয়েছে!**\nতারা আনলিমিটেড লাইভ কমেন্ট করতে পারবে (কোনো অ্যাডমিন এক্সেস ছাড়াই)।")

    @bot.on_message(filters.command("del_vip") & filters.private)
    async def cmd_del_vip(_, message: Message):
        user_id = message.from_user.id
        if not is_admin(user_id):
            return
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            await message.reply_text("⚠️ Usage: `/del_vip <user_id or @username>`\nExample: `/del_vip @Rajisboss3`")
            return
        target_id, label = await resolve_target_user(parts[1])
        if not target_id:
            await message.reply_text(f"❌ ইউজার `{parts[1]}` খুঁজে পাওয়া যায়নি! সঠিক ইউজার আইডি বা ইউজারনেম দিন।")
            return
        remove_vip_user(target_id)
        await message.reply_text(f"✅ **{label} (`{target_id}`) এর VIP মেম্বারশিপ বাতিল করা হয়েছে।**")

    @bot.on_message(filters.command("set_admin") & filters.private)
    async def cmd_set_admin(_, message: Message):
        user_id = message.from_user.id
        if not is_admin(user_id):
            return
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            await message.reply_text("⚠️ Usage: `/set_admin <user_id or @username>`\nExample: `/set_admin @username`")
            return
        target_id, label = await resolve_target_user(parts[1])
        if not target_id:
            await message.reply_text(f"❌ ইউজার `{parts[1]}` খুঁজে পাওয়া যায়নি! সঠিক ইউজার আইডি বা ইউজারনেম দিন।")
            return
        add_admin_user(target_id)
        await message.reply_text(f"🛡️ **{label} (`{target_id}`) সফলভাবে অ্যাডমিন হিসেবে যুক্ত হয়েছে!**\nতারা এখন থেকে অ্যাডমিন প্যানেল দেখতে ও পরিচালনা করতে পারবে।")

    @bot.on_message(filters.command("del_admin") & filters.private)
    async def cmd_del_admin(_, message: Message):
        user_id = message.from_user.id
        if not is_admin(user_id):
            return
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            await message.reply_text("⚠️ Usage: `/del_admin <user_id or @username>`\nExample: `/del_admin @username`")
            return
        target_id, label = await resolve_target_user(parts[1])
        if not target_id:
            await message.reply_text(f"❌ ইউজার `{parts[1]}` খুঁজে পাওয়া যায়নি! সঠিক ইউজার আইডি বা ইউজারনেম দিন।")
            return
        success, reason = remove_admin_user(target_id, requester_id=user_id)
        if not success:
            if reason == "ONLY_SUPER_ADMIN":
                await message.reply_text("🚫 **অননুমোদিত অ্যাকশন!**\nযুক্ত হওয়া কোনো অ্যাডমিন অন্য অ্যাডমিনকে বাদ দিতে পারবে না। শুধুমাত্র **Super Admin (মালিক)** অ্যাডমিন বাতিল করতে পারবেন।")
            elif reason == "CANNOT_REMOVE_SUPER_ADMIN":
                await message.reply_text("🚫 **Super Admin (Owner) কে কখনো বাতিল করা যাবে না!**")
            else:
                await message.reply_text("❌ এই ইউজার অ্যাডমিন তালিকায় নেই।")
            return
        await message.reply_text(f"✅ **{label} (`{target_id}`) এর অ্যাডমিন পদ বাতিল করা হয়েছে।**")

    @bot.on_message(filters.command(["inspectlive", "livemembers"]) & filters.private)
    async def cmd_inspect_live(_, message: Message):
        user_id = message.from_user.id
        if not is_admin(user_id):
            return
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            await message.reply_text(
                "⚠️ **কমান্ড ব্যবহারের নিয়ম:**\n`/inspectlive <চ্যানেল/গ্রুপ লিংক বা ইউজারনেম>`\n\n"
                "📌 **উদাহরণ:**\n`/inspectlive @FreedomBase`\n`/inspectlive https://t.me/FreedomBase`"
            )
            return

        target_link = parts[1].strip()
        status_msg = await message.reply_text("⏳ **লাইভ স্ট্রিম স্ক্যান ও মেম্বার তালিকা সংগ্রহ করা হচ্ছে...**\nঅনুগ্রহ করে কিছুক্ষণ অপেক্ষা করুন।")
        res = await manager.inspect_live_stream(user_id, target_link)
        if not res.get("success"):
            err_msg = res.get("error", "লাইভ তথ্য আনতে ব্যর্থ হয়েছে।")
            await status_msg.edit_text(f"❌ {err_msg}", reply_markup=admin_panel_keyboard(user_id))
            return

        ch_title = res.get("chat_title", "Live Stream")
        ch_user = f" (@{res['chat_username']})" if res.get("chat_username") else ""
        tot = res.get("total_count", 0)
        speakers = res.get("speakers", [])
        listeners = res.get("listeners", [])
        export_file = res.get("export_file")

        speakers_txt = ""
        for idx, s in enumerate(speakers[:15], 1):
            u_part = f"@{s['username']}" if s.get("username") else "No @user"
            speakers_txt += f"  {idx}. **{s['name']}** ({u_part})\n"
        if not speakers:
            speakers_txt = "  *(কোনো সক্রিয় স্পিকার নেই)*\n"
        elif len(speakers) > 15:
            speakers_txt += f"  *...এবং আরও {len(speakers) - 15} জন*\n"

        listeners_txt = ""
        for idx, l in enumerate(listeners[:20], 1):
            u_part = f"@{l['username']}" if l.get("username") else "No @user"
            listeners_txt += f"  {idx}. **{l['name']}** ({u_part})\n"
        if not listeners:
            listeners_txt = "  *(কোনো শ্রোতা পাওয়া যায়নি)*\n"
        elif len(listeners) > 20:
            listeners_txt += f"  *...এবং আরও {len(listeners) - 20} জন*\n"

        real_humans = res.get("real_humans", [])
        active_humans = res.get("active_humans", [])
        inactive_humans = res.get("inactive_humans", [])
        with_username = res.get("with_username_humans", [])
        bots = res.get("bots_and_channels", [])

        report = (
            f"🎙️ **লাইভ মেম্বার ইন্সপেকশন রিপোর্ট:**\n\n"
            f"📢 চ্যানেল/গ্রুপ: **{ch_title}**{ch_user}\n"
            f"👥 মোট লাইভ মেম্বার: **{tot}** জন\n"
            f"👤 **আসল মানুষ (Real Humans): {len(real_humans)} জন**\n"
            f"   ├ 🟢 অনলাইন/রিসেন্ট: **{len(active_humans)}** জন\n"
            f"   ├ ⚪ ইনঅ্যাক্টিভ: **{len(inactive_humans)}** জন\n"
            f"   └ 🔤 @username সহ: **{len(with_username)}** জন\n"
            f"🤖 ফিল্টার্ড (বট/চ্যানেল): **{len(bots)}** টি\n\n"
            f"🎤 **স্পিকার তালিকা ({len(speakers)} জন):**\n"
            f"{speakers_txt}\n"
            f"🎧 **শ্রোতাদের তালিকা (শীর্ষ ২০ জন):**\n"
            f"{listeners_txt}\n"
            f"📁 *সম্পূর্ণ মেম্বার লিস্ট ও সকল ইউজারনেম নিচে ফাইল আকারে পাঠানো হলো:*"
        )

        user_action_states[user_id] = {
            "action": "INSPECTED_LIVE_RESULT",
            "participants": res.get("participants", []),
            "real_humans": real_humans,
            "active_humans": active_humans,
            "inactive_humans": inactive_humans,
            "with_username_humans": with_username,
            "chat_title": ch_title
        }
        await status_msg.edit_text(report, reply_markup=live_inspection_action_keyboard(user_id))

        if export_file and os.path.exists(export_file):
            try:
                await message.reply_document(
                    document=export_file,
                    caption=f"📋 **{ch_title}** এর সকল লাইভ মেম্বার ও @username তালিকা।"
                )
            except Exception as de:
                logger.warning(f"Could not send export file: {de}")

    async def execute_live_discovery(user_id: int, query: str, target_message):
        lang = get_user_lang(user_id)
        kw_list = [k.strip() for k in re.split(r'[,;\n|]+', query) if k.strip()]
        display_query = f"{kw_list[0]} (+{len(kw_list)-1}টি কীওয়ার্ড)" if len(kw_list) > 1 else query
        pref_country = admin_country_preferences.get(user_id, "GLOBAL")
        c_badge = get_country_badge(pref_country, lang)
        country_note = f"\n🌍 টার্গেটেড দেশ: **{c_badge}**" if pref_country != "GLOBAL" else ""
        country_note_en = f"\n🌍 Target Country: **{c_badge}**" if pref_country != "GLOBAL" else ""

        status_msg = await target_message.reply_text(
            f"🔍 **'{display_query}' বিষয়ের সক্রিয় লাইভ স্ট্রিম স্ক্যান করা হচ্ছে...**{country_note}\nটেলিগ্রাম ডিরেক্টরি থেকে যাচাই করা হচ্ছে, অনুগ্রহ করে অপেক্ষা করুন।"
            if lang == "bn" else
            f"🔍 **Scanning for active live streams matching '{display_query}'...**{country_note_en}\nPlease wait..."
        )

        res = await manager.discover_live_streams(user_id, query, country=pref_country)
        if not res.get("success"):
            await status_msg.edit_text(f"❌ {res.get('error', 'Error')}", reply_markup=live_discovery_categories_keyboard(user_id, pref_country))
            return

        lives = res.get("live_streams", [])
        if not lives:
            txt = (
                f"ℹ️ **'{display_query}' বিষয়ে এই মুহূর্তে কোনো সক্রিয় লাইভ পাওয়া যায়নি।**\n\n"
                f"{('🌍 টার্গেটেড দেশ: **' + c_badge + '**' + chr(10)) if pref_country != 'GLOBAL' else ''}"
                f"📊 মোট স্ক্যানকৃত চ্যানেল: **{res.get('total_searched', 0)}** টি\n"
                f"💡 অন্য কোনো ক্যাটাগরি বা কীওয়ার্ড দিয়ে চেষ্টা করুন। (সাধারণত দুপুর বা সন্ধ্যায় সবচেয়ে বেশি লাইভ হয়ে থাকে)"
            ) if lang == "bn" else (
                f"ℹ️ **No active live streams currently found for '{display_query}'.**\n\n"
                f"{('🌍 Target Country: **' + c_badge + '**' + chr(10)) if pref_country != 'GLOBAL' else ''}"
                f"📊 Channels Checked: **{res.get('total_searched', 0)}**\n"
                f"💡 Try another keyword or category. (Most live streams occur in the afternoon/evening)."
            )
            await status_msg.edit_text(txt, reply_markup=live_discovery_categories_keyboard(user_id, pref_country))
            return

        country_hdr = f"🌍 ফিল্টার: **{c_badge}**\n" if pref_country != "GLOBAL" else ""
        txt = (
            f"📡 **'{display_query}' বিষয়ে সক্রিয় লাইভ চ্যানেল ({len(lives)} টি পাওয়া গেছে):**\n"
            f"{country_hdr}\n"
        ) if lang == "bn" else (
            f"📡 **Active Live Streams Found for '{display_query}' ({len(lives)}):**\n"
            f"{country_hdr}\n"
        )

        rows = []
        for idx, l in enumerate(lives[:8], 1):
            u_part = f"@{l['username']}" if l.get("username") else "Private"
            flag = f"{l.get('country_flag', '')} " if l.get('country_flag') else ""
            txt += (
                f"{idx}. 📢 {flag}**{l['title']}** ({u_part})\n"
                f"   🎙️ লাইভ: *{l['call_title']}*\n"
                f"   👥 লাইভে উপস্থিত: **{l['live_participants']}** জন | মোট মেম্বার: {l['total_members']}\n\n"
            ) if lang == "bn" else (
                f"{idx}. 📢 {flag}**{l['title']}** ({u_part})\n"
                f"   🎙️ Live: *{l['call_title']}*\n"
                f"   👥 Live Listeners: **{l['live_participants']}** | Members: {l['total_members']}\n\n"
            )

            target_str = f"@{l['username']}" if l.get("username") else str(l['chat_id'])
            btn_txt = f"🔍 {idx} নং লাইভ মেম্বার ইন্সপেক্ট" if lang == "bn" else f"🔍 Inspect #{idx} Live"
            rows.append([InlineKeyboardButton(btn_txt, callback_data=f"admin_insp_quick_{target_str}")])

        rows.append([InlineKeyboardButton("🔙 ক্যাটাগরি মেনু" if lang == "bn" else "🔙 Categories", callback_data="admin_live_discovery_prompt")])

        await status_msg.edit_text(txt, reply_markup=InlineKeyboardMarkup(rows))

    @bot.on_message(filters.command(["searchlive", "findlive"]) & filters.private)
    async def cmd_search_live(_, message: Message):
        user_id = message.from_user.id
        if not is_admin(user_id):
            return
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            await message.reply_text(
                "⚠️ **কমান্ড ব্যবহারের নিয়ম:**\n`/searchlive <ক্যাটাগরি বা কীওয়ার্ড>`\n\n"
                "📌 **উদাহরণ:**\n`/searchlive trading`\n`/searchlive crypto`\n`/searchlive forex`"
            )
            return
        query = parts[1].strip()
        await execute_live_discovery(user_id, query, message)

    async def execute_dialog_live_discovery(user_id: int, target_message):
        lang = get_user_lang(user_id)
        status_msg = await target_message.reply_text(
            "🔍 **আপনার অ্যাকাউন্টগুলোর যুক্ত থাকা গ্রুপ ও চ্যানেল স্ক্যান করা হচ্ছে...**\nকোনো সক্রিয় লাইভ স্ট্রিম বা ভয়েস চ্যাট চলছে কিনা যাচাই করা হচ্ছে, অনুগ্রহ করে অপেক্ষা করুন।"
            if lang == "bn" else
            "🔍 **Scanning joined groups and channels for active live streams...**\nPlease wait..."
        )

        res = await manager.discover_dialog_live_streams(user_id)
        if not res.get("success"):
            await status_msg.edit_text(f"❌ {res.get('error', 'Error')}", reply_markup=live_discovery_categories_keyboard(user_id))
            return

        lives = res.get("live_streams", [])
        if not lives:
            txt = (
                "ℹ️ **আপনার যুক্ত থাকা কোনো গ্রুপ বা চ্যানেলে বর্তমানে সক্রিয় লাইভ পাওয়া যায়নি।**\n\n"
                f"📊 স্ক্যানকৃত গ্রুপ ও চ্যানেল: **{res.get('total_scanned', 0)}** টি\n"
                f"💡 কোনো গ্রুপে লাইভ শুরু হলে এই বাটনে ক্লিক করলেই সাথে সাথে দেখতে পাবেন।"
            ) if lang == "bn" else (
                "ℹ️ **No active live streams currently running in your joined groups/channels.**\n\n"
                f"📊 Checked Chats: **{res.get('total_scanned', 0)}**\n"
                f"💡 Run this scan whenever a group initiates a live voice chat."
            )
            await status_msg.edit_text(txt, reply_markup=live_discovery_categories_keyboard(user_id))
            return

        txt = (
            f"📡 **যুক্ত থাকা গ্রুপগুলোতে সক্রিয় লাইভ ({len(lives)} টি পাওয়া গেছে):**\n\n"
        ) if lang == "bn" else (
            f"📡 **Active Live Streams in Joined Groups ({len(lives)}):**\n\n"
        )

        rows = []
        for idx, l in enumerate(lives[:8], 1):
            u_part = f"@{l['username']}" if l.get("username") else "Private"
            txt += (
                f"{idx}. 📢 **{l['title']}** ({u_part})\n"
                f"   🎙️ লাইভ: *{l['call_title']}*\n"
                f"   👥 লাইভে উপস্থিত: **{l['live_participants']}** জন | মোট মেম্বার: {l['total_members']}\n\n"
            ) if lang == "bn" else (
                f"{idx}. 📢 **{l['title']}** ({u_part})\n"
                f"   🎙️ Live: *{l['call_title']}*\n"
                f"   👥 Live Listeners: **{l['live_participants']}** | Members: {l['total_members']}\n\n"
            )

            target_str = f"@{l['username']}" if l.get("username") else str(l['chat_id'])
            btn_txt = f"🔍 {idx} নং লাইভ মেম্বার ইন্সপেক্ট" if lang == "bn" else f"🔍 Inspect #{idx} Live"
            rows.append([InlineKeyboardButton(btn_txt, callback_data=f"admin_insp_quick_{target_str}")])

        rows.append([InlineKeyboardButton("🔙 ক্যাটাগরি মেনু" if lang == "bn" else "🔙 Categories", callback_data="admin_live_discovery_prompt")])

        await status_msg.edit_text(txt, reply_markup=InlineKeyboardMarkup(rows))

    @bot.on_message(filters.command(["scangroups", "scanmygroups", "mygroupslive"]) & filters.private)
    async def cmd_scan_my_groups(_, message: Message):
        user_id = message.from_user.id
        if not is_admin(user_id):
            return
        await execute_dialog_live_discovery(user_id, message)

    async def execute_group_discovery(user_id: int, query: str, target_message):
        lang = get_user_lang(user_id)
        kw_list = [k.strip() for k in re.split(r'[,;\n|]+', query) if k.strip()]
        display_query = f"{kw_list[0]} (+{len(kw_list)-1}টি কীওয়ার্ড)" if len(kw_list) > 1 else query
        pref_country = admin_country_preferences.get(user_id, "GLOBAL")
        c_badge = get_country_badge(pref_country, lang)
        country_note = f"\n🌍 টার্গেটেড দেশ: **{c_badge}**" if pref_country != "GLOBAL" else ""
        country_note_en = f"\n🌍 Target Country: **{c_badge}**" if pref_country != "GLOBAL" else ""

        status_msg = await target_message.reply_text(
            f"🔍 **'{display_query}' বিষয়ের গ্রুপ ও চ্যানেল স্ক্যান করা হচ্ছে...**{country_note}\nঅনলাইন মেম্বার সংখ্যা ও লাইভ স্ট্যাটাস যাচাই করা হচ্ছে, অপেক্ষা করুন।"
            if lang == "bn" else
            f"🔍 **Scanning groups & channels for '{display_query}'...**{country_note_en}\nChecking online counts and live statuses..."
        )

        res = await manager.discover_category_groups(user_id, query, country=pref_country)
        if not res.get("success"):
            await status_msg.edit_text(f"❌ {res.get('error', 'Error')}", reply_markup=group_discovery_categories_keyboard(user_id, pref_country))
            return

        groups = res.get("groups", [])
        if not groups:
            txt = (
                f"ℹ️ **'{display_query}' বিষয়ে কোনো গ্রুপ বা চ্যানেল পাওয়া যায়নি।**\n\n"
                f"{('🌍 টার্গেটেড দেশ: **' + c_badge + '**' + chr(10)) if pref_country != 'GLOBAL' else ''}"
                f"📊 স্ক্যানকৃত: **{res.get('total_searched', 0)}** টি\n"
                f"💡 অন্য কোনো কীওয়ার্ড দিয়ে চেষ্টা করুন।"
            ) if lang == "bn" else (
                f"ℹ️ **No groups or channels found for '{display_query}'.**\n\n"
                f"{('🌍 Target Country: **' + c_badge + '**' + chr(10)) if pref_country != 'GLOBAL' else ''}"
                f"📊 Searched: **{res.get('total_searched', 0)}**\n"
                f"💡 Try another keyword."
            )
            await status_msg.edit_text(txt, reply_markup=group_discovery_categories_keyboard(user_id, pref_country))
            return

        country_hdr = f"🌍 ফিল্টার: **{c_badge}**\n" if pref_country != "GLOBAL" else ""
        txt = (
            f"🔥 **'{display_query}' ক্যাটাগরির গ্রুপ ও চ্যানেল ({len(groups)} টি পাওয়া গেছে):**\n"
            f"{country_hdr}"
            f"*(অনলাইন মেম্বার সংখ্যা অনুযায়ী ক্রমানুসারে সাজানো)*\n\n"
        ) if lang == "bn" else (
            f"🔥 **Groups & Channels for '{display_query}' ({len(groups)}):**\n"
            f"{country_hdr}"
            f"*(Sorted by real-time online members count)*\n\n"
        )

        rows = []
        for idx, g in enumerate(groups[:8], 1):
            u_part = f"@{g['username']}" if g.get("username") else "Private"
            live_badge = " | 🎙️ **লাইভ চলছে!**" if g.get("has_live") else ""
            is_grp = g.get("is_group", False)
            flag = f"{g.get('country_flag', '')} " if g.get('country_flag') else ""

            if is_grp:
                online_info = f"   🟢 **বর্তমানে অনলাইনে:** **{g['online_members']}** জন 🔥\n" if g['online_members'] > 0 else "   🟢 অনলাইনে: ০ জন (এই মুহূর্তে সক্রিয় নেই)\n"
                mem_info = f"   👥 মোট মেম্বার: **{g['total_members']}** জন\n"
            else:
                online_info = "   📢 *ব্রডকাস্ট চ্যানেল (অনলাইন কাউন্ট গ্রুপে প্রযোজ্য)*\n"
                mem_info = f"   👥 মোট সাবস্ক্রাইবার: **{g['total_members']}** জন\n"

            txt += (
                f"{idx}. 📢 {flag}**{g['title']}** ({u_part})\n"
                f"   📁 টাইপ: **{g['chat_type']}**{live_badge}\n"
                f"{mem_info}"
                f"{online_info}\n"
            ) if lang == "bn" else (
                f"{idx}. 📢 {flag}**{g['title']}** ({u_part})\n"
                f"   📁 Type: **{g['chat_type']}**{live_badge}\n"
                f"   👥 Total Members: **{g['total_members']}**\n"
                f"   🟢 **Online Now:** **{g['online_members']}**\n\n"
            )

            target_str = f"@{g['username']}" if g.get("username") else str(g['chat_id'])
            grp_btn_txt = f"👥 {idx} নং গ্রুপের অ্যাক্টিভ মেম্বার" if (is_grp and lang == "bn") else (f"👥 {idx} নং চ্যানেলের মেম্বার চেক" if lang == "bn" else f"👥 #{idx} Members")
            btn_row = [InlineKeyboardButton(grp_btn_txt, callback_data=f"admin_insp_grp_{target_str}")]
            if g.get("has_live"):
                live_btn_txt = f"🎙️ {idx} নং লাইভ মেম্বার" if lang == "bn" else f"🎙️ #{idx} Live"
                btn_row.append(InlineKeyboardButton(live_btn_txt, callback_data=f"admin_insp_quick_{target_str}"))
            rows.append(btn_row)

        rows.append([InlineKeyboardButton("🔙 ক্যাটাগরি মেনু" if lang == "bn" else "🔙 Categories", callback_data="admin_group_discovery_prompt")])

        await status_msg.edit_text(txt, reply_markup=InlineKeyboardMarkup(rows))

    @bot.on_message(filters.command(["searchgroup", "findgroup"]) & filters.private)
    async def cmd_search_group(_, message: Message):
        user_id = message.from_user.id
        if not is_admin(user_id):
            return
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            await message.reply_text(
                "⚠️ **কমান্ড ব্যবহারের নিয়ম:**\n`/searchgroup <ক্যাটাগরি বা কীওয়ার্ড>`\n\n"
                "📌 **উদাহরণ:**\n`/searchgroup trading`\n`/searchgroup crypto`\n`/searchgroup forex`"
            )
            return
        query = parts[1].strip()
        await execute_group_discovery(user_id, query, message)

    @bot.on_message(filters.command(["inspectgroup", "groupmembers"]) & filters.private)
    async def cmd_inspect_group(_, message: Message):
        user_id = message.from_user.id
        if not is_admin(user_id):
            return
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            await message.reply_text(
                "⚠️ **কমান্ড ব্যবহারের নিয়ম:**\n`/inspectgroup <গ্রুপের লিংক বা ইউজারনেম>`\n\n"
                "📌 **উদাহরণ:**\n`/inspectgroup @CryptoCommunity`\n`/inspectgroup https://t.me/CryptoCommunity`"
            )
            return
        target_link = parts[1].strip()
        status_msg = await message.reply_text("⏳ **গ্রুপের সক্রিয় ও অনলাইন মেম্বারদের তালিকা সংগ্রহ করা হচ্ছে...**\nঅনুগ্রহ করে অপেক্ষা করুন।")
        res = await manager.inspect_chat_active_members(user_id, target_link)
        if not res.get("success"):
            err_msg = res.get("error", "গ্রুপের তথ্য আনতে ব্যর্থ হয়েছে।")
            await status_msg.edit_text(f"❌ {err_msg}", reply_markup=admin_panel_keyboard(user_id))
            return

        ch_title = res.get("chat_title", "Group")
        ch_user = f" (@{res['chat_username']})" if res.get("chat_username") else ""
        tot = res.get("total_count", 0)
        real_humans = res.get("real_humans", [])
        active_humans = res.get("active_humans", [])
        inactive_humans = res.get("inactive_humans", [])
        with_username = res.get("with_username_humans", [])
        bots = res.get("bots_and_channels", [])
        export_file = res.get("export_file")

        active_txt = ""
        for idx, a in enumerate(active_humans[:20], 1):
            u_part = f"@{a['username']}" if a.get("username") else "No @user"
            active_txt += f"  {idx}. {a.get('status_label', '')} **{a['name']}** ({u_part})\n"
        if not active_txt:
            active_txt = "  *(কোনো অনলাইন মেম্বার পাওয়া যায়নি)*\n"
        elif len(active_humans) > 20:
            active_txt += f"  *...এবং আরও {len(active_humans) - 20} জন সক্রিয় মেম্বার*\n"

        report = (
            f"👥 **গ্রুপ অ্যাক্টিভ মেম্বার ইন্সপেকশন রিপোর্ট:**\n\n"
            f"📢 গ্রুপ: **{ch_title}**{ch_user}\n"
            f"👥 মোট মেম্বার: **{tot}** জন\n"
            f"👤 **আসল মানুষ (Real Humans): {len(real_humans)} জন**\n"
            f"   ├ 🟢 অনলাইন/রিসেন্ট সক্রিয়: **{len(active_humans)}** জন 🔥\n"
            f"   ├ ⚪ ইনঅ্যাক্টিভ: **{len(inactive_humans)}** জন\n"
            f"   └ 🔤 @username সহ: **{len(with_username)}** জন\n"
            f"🤖 ফিল্টার্ড (বট/ডিলিটেড): **{len(bots)}** টি\n\n"
            f"🟢 **শীর্ষ সক্রিয় মেম্বারদের তালিকা:**\n"
            f"{active_txt}\n"
            f"📁 *সম্পূর্ণ মেম্বার লিস্ট ও সকল ইউজারনেম নিচে ফাইল আকারে পাঠানো হলো:*"
        )

        user_action_states[user_id] = {
            "action": "INSPECTED_LIVE_RESULT",
            "participants": res.get("participants", []),
            "real_humans": real_humans,
            "active_humans": active_humans,
            "inactive_humans": inactive_humans,
            "with_username_humans": with_username,
            "chat_title": ch_title
        }
        await status_msg.edit_text(report, reply_markup=live_inspection_action_keyboard(user_id))

        if export_file and os.path.exists(export_file):
            try:
                await message.reply_document(
                    document=export_file,
                    caption=f"📋 **{ch_title}** এর সকল গ্রুপ মেম্বার ও @username তালিকা।"
                )
            except Exception as de:
                logger.warning(f"Could not send export file: {de}")

    async def render_admins_list(user_id: int) -> str:
        lang = get_user_lang(user_id)
        super_admin_id = get_super_admin_id()
        admins = get_admins_list()

        super_label = f"`{super_admin_id}`"
        try:
            u = await bot.get_users(super_admin_id)
            if u and u.username:
                super_label = f"@{u.username} (`{super_admin_id}`)"
            elif u and u.first_name:
                super_label = f"{u.first_name} (`{super_admin_id}`)"
        except Exception:
            pass

        added_admin_lines = []
        for aid in admins:
            if aid == super_admin_id:
                continue
            label = f"`{aid}`"
            try:
                u = await bot.get_users(aid)
                if u and u.username:
                    label = f"@{u.username} (`{aid}`)"
                elif u and u.first_name:
                    label = f"{u.first_name} (`{aid}`)"
            except Exception:
                pass
            added_admin_lines.append(f"🛡️ {label}")

        if lang == "bn":
            text = "👑 **Super Admin (প্রধান মালিক / Owner):**\n"
            text += f"👑 {super_label} [Full Owner Authority]\n\n"
            text += "🛡️ **যুক্ত করা অ্যাডমিন তালিকা (Added Admins):**\n"
            text += "\n".join(added_admin_lines) if added_admin_lines else "ℹ️ কোনো অতিরিক্ত অ্যাডমিন যুক্ত নেই।"
            text += "\n\n💡 *নোট: কোনো অ্যাডমিন Super Admin-কে বাতিল করতে পারবে না। শুধুমাত্র Super Admin অ্যাডমিন রিমুভ করতে পারবেন।*"
        else:
            text = "👑 **Super Admin (Owner):**\n"
            text += f"👑 {super_label} [Full Owner Authority]\n\n"
            text += "🛡️ **Added Admins:**\n"
            text += "\n".join(added_admin_lines) if added_admin_lines else "ℹ️ No additional admins added."
            text += "\n\n💡 *Note: Only the Super Admin (Owner) can remove admins.*"
        return text

    async def render_vip_list(user_id: int) -> str:
        lang = get_user_lang(user_id)
        vips = get_vip_list()

        vip_lines = []
        for vid in vips:
            label = f"`{vid}`"
            try:
                u = await bot.get_users(vid)
                if u and u.username:
                    label = f"@{u.username} (`{vid}`)"
                elif u and u.first_name:
                    label = f"{u.first_name} (`{vid}`)"
            except Exception:
                pass
            vip_lines.append(f"💎 {label}")

        if lang == "bn":
            text = "💎 **VIP মেম্বার তালিকা (পেইড গ্রাহক):**\n\n"
            text += "\n".join(vip_lines) if vip_lines else "ℹ️ বর্তমানে কোনো VIP গ্রাহক সক্রিয় নেই।"
            text += "\n\n💡 *VIP মেম্বাররা আনলিমিটেড লাইভ কমেন্ট করতে পারেন, কিন্তু তারা অ্যাডমিন প্যানেল দেখতে বা ব্যবহার করতে পারেন না।*"
        else:
            text = "💎 **VIP Members List (Paid Subscribers):**\n\n"
            text += "\n".join(vip_lines) if vip_lines else "ℹ️ No active VIP subscribers currently."
            text += "\n\n💡 *VIP members have unlimited comments, but cannot view or access the Admin Panel.*"

        return text

    @bot.on_message(filters.command("vip_list") & filters.private)
    async def cmd_vip_list(_, message: Message):
        user_id = message.from_user.id
        if not is_admin(user_id):
            return
        vip_text = await render_vip_list(user_id)
        await message.reply_text(vip_text)

    @bot.on_message(filters.command("admin_list") & filters.private)
    async def cmd_admin_list(_, message: Message):
        user_id = message.from_user.id
        if not is_admin(user_id):
            return
        admin_text = await render_admins_list(user_id)
        await message.reply_text(admin_text)

    def render_accounts_view(user_id: int) -> Tuple[str, InlineKeyboardMarkup]:
        lang = get_user_lang(user_id)
        accounts = manager.get_user_accounts_list(user_id)
        if not accounts:
            text = tr(user_id, "no_accounts")
            return text, main_menu_keyboard(user_id)

        if lang == "bn":
            header = "👥 **আপনার যুক্ত করা অ্যাকাউন্টসমূহ (Connected Accounts):**\n\n"
            for idx, acc in enumerate(accounts, 1):
                call_status = f"🎙️ লাইভে সক্রিয়: **{acc['current_chat']}**" if acc['is_in_call'] else "🟢 প্রস্তুত (Idle)"
                uname = f"@{acc['username']}" if acc.get("username") else ""
                uname_info = f"👤 ইউজারনেম: `{uname}` | " if uname else ""
                header += (
                    f"{idx}. **{acc['first_name']}**\n"
                    f"   {uname_info}🆔 ID: `{acc['user_id']}`\n"
                    f"   স্ট্যাটাস: {call_status}\n\n"
                )
            header += "💡 কোনো অ্যাকাউন্ট বাদ দিতে চাইলে নিচের **'🗑️ অ্যাকাউন্ট রিমুভ করুন'** বাটনে চাপ দিন:"
        else:
            header = "👥 **Your Connected Accounts:**\n\n"
            for idx, acc in enumerate(accounts, 1):
                call_status = f"🎙️ In Live: **{acc['current_chat']}**" if acc['is_in_call'] else "🟢 Idle"
                uname = f"@{acc['username']}" if acc.get("username") else ""
                uname_info = f"👤 Username: `{uname}` | " if uname else ""
                header += (
                    f"{idx}. **{acc['first_name']}**\n"
                    f"   {uname_info}🆔 ID: `{acc['user_id']}`\n"
                    f"   Status: {call_status}\n\n"
                )
            header += "💡 To remove an account, click **'🗑️ Remove an Account'** below:"

        kb = accounts_list_keyboard(accounts, user_id)
        return header, kb

    @bot.on_message(filters.command("accounts") & filters.private)
    async def cmd_accounts(_, message: Message):
        user_id = message.from_user.id
        text, kb = render_accounts_view(user_id)
        await message.reply_text(text, reply_markup=kb)

    @bot.on_message(filters.command("status") & filters.private)
    async def cmd_status(_, message: Message):
        user_id = message.from_user.id
        await manager.sync_all_engines_call_status()
        accounts = manager.get_user_accounts_list(user_id)
        total = len(accounts)
        in_call = sum(1 for a in accounts if a['is_in_call'])

        text = tr(user_id, "status_title", total=total, in_call=in_call, idle=total - in_call)
        await message.reply_text(text, reply_markup=main_menu_keyboard(user_id))

    @bot.on_message(filters.command("add") & filters.private)
    async def cmd_add(_, message: Message):
        user_id = message.from_user.id
        _cleanup_user_state(user_id)
        user_login_states[user_id] = {"step": "AWAITING_PHONE"}
        await message.reply_text(
            tr(user_id, "add_phone"),
            reply_markup=cancel_keyboard(user_id)
        )

    @bot.on_message(filters.command("cancel") & filters.private)
    async def cmd_cancel(_, message: Message):
        user_id = message.from_user.id
        _cleanup_user_state(user_id)
        await message.reply_text(
            tr(user_id, "login_canceled"),
            reply_markup=main_menu_keyboard(user_id)
        )

    @bot.on_message(filters.command("add_session") & filters.private)
    async def cmd_add_session(_, message: Message):
        user_id = message.from_user.id
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            await message.reply_text("⚠️ Usage: `/add_session <session_string>`")
            return

        session_str = parts[1].strip()
        status_msg = await message.reply_text("⏳ Verifying session string...")
        res = await manager.add_string_session(session_str, owner_id=user_id)

        if res.get("success"):
            user_acc_count = len(manager.get_user_accounts_list(user_id))
            await status_msg.edit_text(
                tr(user_id, "login_success", name=res.get("name"), id=res.get("id"), phone=res.get("phone"), total=user_acc_count),
                reply_markup=main_menu_keyboard(user_id)
            )
        else:
            await status_msg.edit_text(
                f"❌ Error: `{res.get('error')}`",
                reply_markup=main_menu_keyboard(user_id)
            )

    @bot.on_message(filters.command("remove") & filters.private)
    async def cmd_remove(_, message: Message):
        user_id = message.from_user.id
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            text, kb = render_accounts_view(user_id)
            await message.reply_text(text, reply_markup=kb)
            return

        query_str = parts[1].strip()
        user_accounts = manager.get_user_accounts_list(user_id)
        target_acc = None
        for a in user_accounts:
            if a.get("session_name") == query_str or a.get("phone") == query_str or str(a.get("user_id")) == query_str:
                target_acc = a
                break

        session_to_del = target_acc["session_name"] if target_acc else query_str
        acc_name = target_acc.get("first_name", session_to_del) if target_acc else session_to_del

        success = await manager.remove_account(session_to_del, owner_id=user_id)
        if success:
            await message.reply_text(f"✅ Account `{acc_name}` removed.", reply_markup=main_menu_keyboard(user_id))
        else:
            await message.reply_text("❌ Account not found or unauthorized.", reply_markup=main_menu_keyboard(user_id))

    async def execute_live_join(user_id: int, target: str, reply_to: Message, count: Optional[int] = None):
        """Helper to execute bulk live join with real-time progress."""
        can_join, remaining_seconds = can_join_live(user_id)
        if not can_join:
            _, contact_url = await get_admin_contact(user_id=user_id)
            text, kb = get_cooldown_message(user_id, remaining_seconds, contact_url)
            await reply_to.reply_text(text, reply_markup=kb)
            return

        user_accounts = manager.get_user_accounts_list(user_id)
        total_accounts = len(user_accounts)

        if total_accounts == 0:
            await reply_to.reply_text(tr(user_id, "no_accounts"), reply_markup=main_menu_keyboard(user_id))
            return

        target_count = min(count, total_accounts) if count and count > 0 else total_accounts

        free_limit_note = ""
        if not is_vip(user_id):
            from core.subscription import FREE_LIVE_ACCOUNT_LIMIT
            if target_count > FREE_LIVE_ACCOUNT_LIMIT:
                target_count = FREE_LIVE_ACCOUNT_LIMIT
                free_limit_note = (
                    f"\n\n⚠️ **ফ্রি ইউজার লিমিট:** সাধারণ অ্যাকাউন্টের জন্য একটি লাইভে সর্বোচ্চ **{FREE_LIVE_ACCOUNT_LIMIT}টি** অ্যাকাউন্ট জয়েন করার সীমা কার্যকর হয়েছে। (আনলিমিটেড অ্যাকাউন্টের জন্য VIP সাবস্ক্রিপশন নিন 💎)"
                    if get_user_lang(user_id) == "bn" else
                    f"\n\n⚠️ **Free User Limit:** Normal users can join a maximum of **{FREE_LIVE_ACCOUNT_LIMIT} accounts** per live stream. (Upgrade to VIP for unlimited accounts 💎)"
                )

        status_msg = await reply_to.reply_text(
            tr(user_id, "join_starting", target=target, total=target_count)
        )

        async def update_progress(current, total, success, failed):
            try:
                await status_msg.edit_text(
                    tr(user_id, "join_progress", target=target, current=current, total=total, success=success, failed=failed)
                )
            except Exception:
                pass

        result = await manager.join_for_user(user_id, target, count=target_count, progress_callback=update_progress)

        details_preview = "\n".join(result["details"][:10])
        if len(result["details"]) > 10:
            details_preview += f"\n...and {len(result['details']) - 10} more"

        limit_note = ""
        if result["success"] > 0:
            if not is_vip(user_id):
                if user_id in user_live_tasks:
                    user_live_tasks[user_id].cancel()
                user_live_tasks[user_id] = asyncio.create_task(monitor_user_live_limit(user_id))
                limit_note = (
                    "\n\n⏱️ **সেশন লিমিট:** সাধারণ অ্যাকাউন্টের জন্য একটানা সর্বোচ্চ **৩০ মিনিট** লাইভ সক্রিয় থাকবে। ৩০ মিনিট পূর্ণ হলে অ্যাকাউন্টগুলো স্বয়ংক্রিয়ভাবে ডিসকানেক্ট হয়ে ১০ মিনিটের বিরতি কার্যকর হবে। (আনলিমিটেড লাইভের জন্য VIP সুবিধা প্রযোজ্য 💎)"
                    if get_user_lang(user_id) == "bn" else
                    "\n\n⏱️ **Session Limit:** Continuous live streaming is limited to **30 minutes** for Normal Users. After 30 minutes, accounts will auto-disconnect for a 10-minute cooldown. (Upgrade to VIP for unlimited 24/7 streaming 💎)"
                )
            else:
                limit_note = (
                    "\n\n💎 **VIP আনলিমিটেড লাইভ:** আপনার অ্যাকাউন্টে কোনো সময়সীমা বা বিরতি নেই। একটানা আনলিমিটেড উপভোগ করুন!"
                    if get_user_lang(user_id) == "bn" else
                    "\n\n💎 **VIP Unlimited Live:** No session limits or cooldowns. Enjoy 24/7 continuous live streaming!"
                )

        await status_msg.edit_text(
            tr(user_id, "join_completed", target=target, total=result["total"], success=result["success"], failed=result["failed"], details=details_preview) + limit_note + free_limit_note,
            reply_markup=main_menu_keyboard(user_id)
        )

    async def execute_comments(user_id: int, comments: list, reply_to: Message, is_ai: bool = False):
        """Helper to execute commenting from live connected accounts."""
        user_in_call = [e for e in manager.get_user_engines(user_id).values() if e.in_call]
        if not user_in_call:
            await reply_to.reply_text(tr(user_id, "no_accounts_in_call"), reply_markup=main_menu_keyboard(user_id))
            return

        target_count = len(user_in_call)
        if is_ai and not is_vip(user_id):
            remaining = get_remaining_ai_balance(user_id)
            if remaining <= 0:
                await notify_limit_reached(reply_to, user_id, is_manual=False)
                return
            target_count = min(target_count, remaining)

        status_msg = await reply_to.reply_text(tr(user_id, "comment_starting"))

        async def update_comment_progress(current, total, success, failed):
            try:
                await status_msg.edit_text(
                    f"💬 **Sending comments...**\nProgress: **{current}/{total}**\n✅ Sent: **{success}** | ❌ Failed: **{failed}**"
                )
            except Exception:
                pass

        res = await manager.send_comments_for_user(user_id, comments, count=target_count, progress_callback=update_comment_progress)

        # Deduct AI quota based on actual messages sent!
        if is_ai and not is_vip(user_id) and res["success"] > 0:
            record_ai_usage(user_id, count=res["success"])

        details_preview = "\n".join(res["details"][:10])
        if len(res["details"]) > 10:
            details_preview += f"\n...and {len(res['details']) - 10} more"

        balance_note = f"\n\n📊 আজকের বাকি AI ব্যালেন্স: {format_ai_balance(user_id)}" if is_ai else ""
        await status_msg.edit_text(
            tr(user_id, "comment_completed", total=res["total"], success=res["success"], details=details_preview) + balance_note,
            reply_markup=main_menu_keyboard(user_id)
        )

    async def execute_attachment_comment_flow(user_id: int, message: Message):
        """Helper to receive attachment/text and prompt user to select the account to post from."""
        user_in_call = [e for e in manager.get_user_engines(user_id).values() if e.in_call]
        if not user_in_call:
            await message.reply_text(tr(user_id, "no_accounts_in_call"), reply_markup=main_menu_keyboard(user_id))
            return

        can_use, used, limit = can_use_manual(user_id)
        if not can_use:
            await notify_limit_reached(message, user_id, is_manual=True)
            return

        media_type = "text"
        caption = message.caption or message.text or ""
        media_path = None

        ext = ""
        if message.photo:
            media_type = "photo"
            ext = ".jpg"
        elif message.video:
            media_type = "video"
            ext = ".mp4"
        elif message.document:
            media_type = "document"
            from pathlib import Path
            orig_name = getattr(message.document, "file_name", "")
            ext = Path(orig_name).suffix if orig_name else ".dat"
        elif message.voice:
            media_type = "voice"
            ext = ".ogg"
        elif message.audio:
            media_type = "audio"
            from pathlib import Path
            orig_name = getattr(message.audio, "file_name", "")
            ext = Path(orig_name).suffix if orig_name else ".mp3"
        elif message.sticker:
            media_type = "sticker"
            ext = ".webp"
        elif message.animation:
            media_type = "animation"
            ext = ".mp4"

        if media_type != "text":
            downloading_msg = await message.reply_text("⏳ মিডিয়া প্রসেস করা হচ্ছে..." if get_user_lang(user_id) == "bn" else "⏳ Processing media...")
            try:
                temp_dir = config.BASE_DIR / "temp_media"
                temp_dir.mkdir(exist_ok=True)
                file_target = str(temp_dir / f"media_{user_id}_{message.id}{ext}")
                media_path = await message.download(file_name=file_target)
                await downloading_msg.delete()
            except Exception as e:
                logger.error(f"Error downloading media: {e}")
                await downloading_msg.edit_text(f"❌ Failed to process media: {e}")
                return

        accounts_in_call = [a for a in manager.get_user_accounts_list(user_id) if a.get("is_in_call")]
        user_action_states[user_id] = {
            "action": "AWAITING_ATTACHMENT_ACCOUNT_CHOICE",
            "media_path": media_path,
            "caption": caption,
            "media_type": media_type
        }

        await message.reply_text(
            tr(user_id, "choose_account_for_comment"),
            reply_markup=account_selector_keyboard(accounts_in_call, user_id)
        )

    async def execute_inbox_text_delivery(user_id: int, target_account: str, text: str, message: Message, target_inbox: Optional[str] = None):
        """Helper to deliver text message from chosen account(s) to recipient Telegram inbox."""
        status_msg = await message.reply_text(tr(user_id, "inbox_sending"))
        username = message.from_user.username if message.from_user else None
        res = await manager.send_to_inbox_for_user(
            owner_id=user_id,
            chosen_acc=target_account,
            text=text,
            media_type="text",
            target_inbox=target_inbox,
            owner_username=username
        )
        details_preview = "\n".join(res.get("details", [])[:10])
        target_display = target_inbox or "Inbox"
        await status_msg.edit_text(
            tr(user_id, "inbox_completed", target=target_display, total=res["total"], success=res["success"], details=details_preview),
            reply_markup=main_menu_keyboard(user_id)
        )

    async def execute_inbox_media_delivery(user_id: int, target_account: str, message: Message, target_inbox: Optional[str] = None):
        """Helper to deliver media attachment from chosen account(s) to recipient Telegram inbox."""
        media_type = "text"
        caption = message.caption or message.text or ""
        media_path = None
        ext = ""

        if message.photo:
            media_type = "photo"
            ext = ".jpg"
        elif message.video:
            media_type = "video"
            ext = ".mp4"
        elif message.document:
            media_type = "document"
            from pathlib import Path
            orig_name = getattr(message.document, "file_name", "")
            ext = Path(orig_name).suffix if orig_name else ".dat"
        elif message.voice:
            media_type = "voice"
            ext = ".ogg"
        elif message.audio:
            media_type = "audio"
            from pathlib import Path
            orig_name = getattr(message.audio, "file_name", "")
            ext = Path(orig_name).suffix if orig_name else ".mp3"
        elif message.sticker:
            media_type = "sticker"
            ext = ".webp"
        elif message.animation:
            media_type = "animation"
            ext = ".mp4"

        downloading_msg = await message.reply_text(tr(user_id, "inbox_sending"))
        username = message.from_user.username if message.from_user else None
        try:
            if media_type != "text":
                temp_dir = config.BASE_DIR / "temp_media"
                temp_dir.mkdir(exist_ok=True)
                file_target = str(temp_dir / f"inbox_{user_id}_{message.id}{ext}")
                media_path = await message.download(file_name=file_target)

            res = await manager.send_to_inbox_for_user(
                owner_id=user_id,
                chosen_acc=target_account,
                text=caption,
                media_path=media_path,
                caption=caption,
                media_type=media_type,
                target_inbox=target_inbox,
                owner_username=username
            )
        except Exception as e:
            logger.error(f"Error sending to inbox: {e}")
            await downloading_msg.edit_text(f"❌ Failed to deliver to inbox: {e}", reply_markup=main_menu_keyboard(user_id))
            return
        finally:
            if media_path:
                try:
                    from pathlib import Path
                    Path(media_path).unlink(missing_ok=True)
                except Exception:
                    pass

        details_preview = "\n".join(res.get("details", [])[:10])
        target_display = target_inbox or "Inbox"
        await downloading_msg.edit_text(
            tr(user_id, "inbox_completed", target=target_display, total=res["total"], success=res["success"], details=details_preview),
            reply_markup=main_menu_keyboard(user_id)
        )

    async def execute_live_voice_delivery(user_id: int, action_data: dict, message: Message):
        """Helper to process audio/voice message and stream it directly into active live stream."""
        can_v, used_v, lim_v = can_use_live_voice(user_id)
        if not can_v:
            user_action_states.pop(user_id, None)
            _, contact_url = await get_admin_contact(user_id=user_id)
            kb = InlineKeyboardMarkup([[InlineKeyboardButton("💎 VIP মেম্বারশিপ নিন", url=contact_url)]]) if contact_url else main_menu_keyboard(user_id)
            txt = (
                f"❌ **আপনার আজকের ফ্রি ১টি লাইভ ভয়েস ব্যবহারের কোটা শেষ হয়ে গেছে!**\n\n"
                f"📊 ব্যবহৃত: **{used_v}/{lim_v}** টি\n"
                f"💡 ফ্রি ইউজাররা প্রতিদিন ১টি লাইভ ভয়েস ব্যবহার করতে পারেন। আনলিমিটেড লাইভ ভয়েস চালাতে VIP মেম্বারশিপে আপগ্রেড করুন।"
            ) if get_user_lang(user_id) == "bn" else (
                f"❌ **Your free daily limit of 1 live voice is reached!**\n\n"
                f"📊 Used: **{used_v}/{lim_v}**\n"
                f"💡 Free tier allows 1 live voice per day. Upgrade to VIP for unlimited live voice streaming."
            )
            await message.reply_text(txt, reply_markup=kb)
            return

        user_in_call = [e for e in manager.get_user_engines(user_id).values() if e.in_call]
        if not user_in_call:
            user_action_states.pop(user_id, None)
            await message.reply_text(tr(user_id, "no_accounts_in_call"), reply_markup=main_menu_keyboard(user_id))
            return

        target_account = action_data.get("target_account", "ALL")

        is_zip = bool(message.document and getattr(message.document, "file_name", "").lower().endswith(".zip"))
        if is_zip:
            if not is_vip(user_id):
                user_action_states.pop(user_id, None)
                _, contact_url = await get_admin_contact(user_id=user_id)
                kb = InlineKeyboardMarkup([[InlineKeyboardButton("💎 VIP মেম্বারশিপ নিন", url=contact_url)]]) if contact_url else main_menu_keyboard(user_id)
                await message.reply_text(
                    "❌ **বাল্ক জিপ অডিও শুধুমাত্র VIP মেম্বারদের জন্য!**\n\nফ্রি ইউজাররা প্রতিদিন ১টি একক ভয়েস পাঠাতে পারেন। আনলিমিটেড বাল্ক ভয়েসের জন্য VIP মেম্বারশিপ নিন।"
                    if get_user_lang(user_id) == "bn" else
                    "❌ **Bulk Zip Audio is a VIP-exclusive feature!**\n\nFree users can stream 1 single voice per day. Upgrade to VIP for unlimited bulk audio zip streaming.",
                    reply_markup=kb
                )
                return

            status_msg = await message.reply_text("📦 বাল্ক অডিও জিপ প্রসেস করা হচ্ছে..." if get_user_lang(user_id) == "bn" else "📦 Processing bulk audio zip file...")
            try:
                import zipfile
                temp_dir = config.BASE_DIR / "temp_media" / f"bulk_voice_{user_id}_{message.id}"
                temp_dir.mkdir(parents=True, exist_ok=True)
                zip_target = str(temp_dir / "bulk.zip")
                await message.download(file_name=zip_target)

                audio_files = []
                with zipfile.ZipFile(zip_target, "r") as z:
                    for member in z.namelist():
                        if member.lower().endswith((".mp3", ".wav", ".ogg", ".m4a", ".aac")):
                            extracted = z.extract(member, str(temp_dir))
                            clean_wav = f"{extracted}_clean.wav"
                            try:
                                proc = await asyncio.create_subprocess_exec(
                                    "ffmpeg", "-y", "-i", extracted, "-vn", "-c:a", "pcm_s16le", "-ar", "48000", "-ac", "2", clean_wav,
                                    stdout=asyncio.subprocess.DEVNULL,
                                    stderr=asyncio.subprocess.DEVNULL
                                )
                                await proc.wait()
                                if os.path.exists(clean_wav) and os.path.getsize(clean_wav) > 0:
                                    audio_files.append(clean_wav)
                                else:
                                    audio_files.append(extracted)
                            except Exception:
                                audio_files.append(extracted)

                if not audio_files:
                    await status_msg.edit_text("❌ জিপ ফাইলের ভেতরে কোনো অডিও ফাইল পাওয়া যায়নি (.mp3, .wav, .ogg)।", reply_markup=live_voice_control_keyboard(user_id))
                    return

                res = await manager.play_bulk_voices_for_user(
                    owner_id=user_id,
                    audio_paths=audio_files,
                    chosen_acc=target_account,
                    loop=False
                )
                user_action_states.pop(user_id, None)
                details = "\n".join(res.get("details", []))
                await status_msg.edit_text(
                    f"📦 **বাল্ক ভয়েস ({len(audio_files)} টি ফাইল) সফলভাবে আর্ম ও লোড করা হয়েছে!**\n\n"
                    f"⏳ **স্ট্যাটাস:** প্রতিটি অ্যাকাউন্টের জন্য ভয়েস ফাইল রেডি। লাইভ হোস্ট মাইক অন করলেই অডিওটি একবার বাজবে এবং শেষ হলে মাইক নিজে থেকেই অফ হয়ে যাবে।\n\n"
                    f"**Details:**\n{details}",
                    reply_markup=live_voice_control_keyboard(user_id)
                )
            except Exception as e:
                logger.error(f"Error processing bulk voice zip: {e}")
                await status_msg.edit_text(f"❌ বাল্ক জিপ প্রসেস করতে ব্যর্থ: {e}", reply_markup=live_voice_control_keyboard(user_id))
            return

        ext = ".ogg"
        if message.voice:
            ext = ".ogg"
        elif message.audio:
            from pathlib import Path
            orig = getattr(message.audio, "file_name", "")
            ext = Path(orig).suffix if orig else ".mp3"
        elif message.video:
            ext = ".mp4"
        elif message.document:
            from pathlib import Path
            orig = getattr(message.document, "file_name", "")
            ext = Path(orig).suffix if orig else ".mp3"

        status_msg = await message.reply_text("⏳ লাইভে ভয়েস প্রসেস ও লোড করা হচ্ছে..." if get_user_lang(user_id) == "bn" else "⏳ Processing voice audio for live stream...")
        try:
            temp_dir = config.BASE_DIR / "temp_media"
            temp_dir.mkdir(exist_ok=True)
            file_target = str(temp_dir / f"live_voice_{user_id}_{message.id}{ext}")
            media_path = await message.download(file_name=file_target)

            # Convert to standard 48000Hz stereo PCM WAV for crystal clear WebRTC streaming
            try:
                converted_target = str(temp_dir / f"live_voice_{user_id}_{message.id}_clean.wav")
                proc = await asyncio.create_subprocess_exec(
                    "ffmpeg", "-y", "-i", media_path, "-vn", "-c:a", "pcm_s16le", "-ar", "48000", "-ac", "2", converted_target,
                    stdout=asyncio.subprocess.DEVNULL,
                    stderr=asyncio.subprocess.DEVNULL
                )
                await proc.wait()
                if os.path.exists(converted_target) and os.path.getsize(converted_target) > 0:
                    media_path = converted_target
            except Exception as cv_err:
                logger.debug(f"Audio ffmpeg conversion notice: {cv_err}")

            uploaded_audios = action_data.setdefault("uploaded_audios", [])
            uploaded_audios.append(media_path)

            res = await manager.play_bulk_voices_for_user(
                owner_id=user_id,
                audio_paths=uploaded_audios,
                chosen_acc=target_account,
                loop=False  # Play ONCE, then automatically stop and mute mic!
            )
            if not is_vip(user_id):
                record_live_voice_usage(user_id, 1)

            total_accounts = res.get("total", 1)
            audio_count = len(uploaded_audios)
            details = "\n".join(res.get("details", []))

            if get_user_lang(user_id) == "bn":
                msg_text = (
                    f"🎙️ **ভয়েস #{audio_count} সফলভাবে গ্রহণ ও আর্ম করা হয়েছে!**\n\n"
                    f"📊 **অ্যাকাউন্ট সংখ্যা:** {total_accounts} টি | **আপলোডকৃত ভয়েস:** {audio_count} টি\n"
                    f"⏳ **স্ট্যাটাস:** লাইভ হোস্ট যে অ্যাকাউন্টের মাইক অন করবে, সেই অ্যাকাউন্টের অডিওটি সাথে সাথে একবার বাজবে এবং শেষ হলে মাইক অটো মিউট হবে।\n\n"
                    f"• আরো অডিও পাঠাতে চাইলে পাঠান (পরবর্তী অ্যাকাউন্টের জন্য সেট হবে)।\n"
                    f"• আপলোড শেষ হলে নিচে **[✅ সম্পন্ন (Done)]** বাটনে চাপুন।\n\n"
                    f"**Details:**\n{details}"
                )
            else:
                msg_text = (
                    f"🎙️ **Voice #{audio_count} successfully armed & loaded!**\n\n"
                    f"📊 **Accounts:** {total_accounts} | **Uploaded Voices:** {audio_count}\n"
                    f"⏳ **Status:** When host unmutes any account, its assigned audio will play once, then auto-mute.\n\n"
                    f"• You can send more audios to assign to next accounts.\n"
                    f"• When finished, click **[✅ Done]** below.\n\n"
                    f"**Details:**\n{details}"
                )
            await status_msg.edit_text(msg_text, reply_markup=voice_upload_progress_keyboard(user_id))
        except Exception as e:
            logger.error(f"Error streaming live voice: {e}")
            await status_msg.edit_text(f"❌ Failed to stream voice in live: {e}", reply_markup=live_voice_control_keyboard(user_id))


    @bot.on_message(filters.command("comment") & filters.private)
    async def cmd_comment(_, message: Message):
        user_id = message.from_user.id
        parts = message.text.split(maxsplit=1)
        if len(parts) < 2:
            user_action_states[user_id] = {"action": "AWAITING_CUSTOM_COMMENT"}
            await message.reply_text(tr(user_id, "custom_comment_prompt"), reply_markup=cancel_keyboard(user_id))
            return

        text = parts[1].strip()
        comments = [c.strip() for c in text.split("\n") if c.strip()]
        await execute_comments(user_id, comments, message)

    @bot.on_message(filters.command("join") & filters.private)
    async def cmd_join(_, message: Message):
        user_id = message.from_user.id
        can_join, remaining_seconds = can_join_live(user_id)
        if not can_join:
            _, contact_url = await get_admin_contact(user_id=user_id)
            text, kb = get_cooldown_message(user_id, remaining_seconds, contact_url)
            await message.reply_text(text, reply_markup=kb)
            return

        parts = message.text.split()
        if len(parts) < 2:
            user_action_states[user_id] = {"action": "AWAITING_JOIN_LINK"}
            await message.reply_text(
                tr(user_id, "join_prompt"),
                reply_markup=cancel_keyboard(user_id)
            )
            return

        target = parts[1].strip()
        count = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else None

        user_accounts = manager.get_user_accounts_list(user_id)
        if len(user_accounts) > 1 and count is None:
            user_action_states[user_id] = {"action": "AWAITING_COUNT", "target": target}
            await message.reply_text(
                tr(user_id, "choose_count", target=target, total=len(user_accounts)),
                reply_markup=count_selection_keyboard(len(user_accounts), user_id)
            )
            return

        await execute_live_join(user_id, target, message, count=count)

    @bot.on_message(filters.command("leave") & filters.private)
    async def cmd_leave(_, message: Message):
        user_id = message.from_user.id
        if user_id in user_live_tasks:
            user_live_tasks[user_id].cancel()
            user_live_tasks.pop(user_id, None)
        user_live_start_times.pop(user_id, None)
        status_msg = await message.reply_text(tr(user_id, "leave_progress"))
        res = await manager.leave_for_user(user_id)
        await status_msg.edit_text(
            tr(user_id, "leave_completed", total=res["total"], success=res["success"]),
            reply_markup=main_menu_keyboard(user_id)
        )

    @bot.on_message(filters.command("inbox") & filters.private)
    async def cmd_inbox(_, message: Message):
        user_id = message.from_user.id
        accounts = manager.get_user_accounts_list(user_id)
        if not accounts:
            await message.reply_text(tr(user_id, "no_accounts"), reply_markup=main_menu_keyboard(user_id))
            return

        parts = message.text.split(maxsplit=1)
        if len(parts) > 1:
            target = parts[1].strip()
            user_action_states[user_id] = {
                "action": "AWAITING_INBOX_CONTENT",
                "target_account": "ALL",
                "target_inbox": target
            }
            await message.reply_text(
                tr(user_id, "inbox_prompt", target=target),
                reply_markup=cancel_keyboard(user_id)
            )
        else:
            await message.reply_text(
                tr(user_id, "inbox_select_account"),
                reply_markup=inbox_account_selector_keyboard(accounts, user_id)
            )

    @bot.on_message(filters.command("backup") & filters.private)
    async def cmd_backup(_, message: Message):
        user_id = message.from_user.id
        from core.subscription import is_admin
        if not is_admin(user_id):
            await message.reply_text("❌ শুধুমাত্র অ্যাডমিনরা ব্যাকআপ ডাউনলোড করতে পারবেন।")
            return

        status_msg = await message.reply_text("📦 সার্ভার সেশন ব্যাকআপ তৈরি করা হচ্ছে...")
        import zipfile
        from datetime import datetime
        backup_zip = config.BASE_DIR / f"sessions_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
        try:
            with zipfile.ZipFile(backup_zip, 'w', compression=zipfile.ZIP_DEFLATED) as z:
                for root, dirs, files in os.walk(config.SESSIONS_DIR):
                    for file in files:
                        full_path = Path(root) / file
                        rel_path = full_path.relative_to(config.BASE_DIR)
                        z.write(full_path, arcname=str(rel_path).replace("\\", "/"))

            await message.reply_document(
                document=str(backup_zip),
                caption=f"📁 **সার্ভার সেশন ব্যাকআপ সম্পন্ন!**\n📅 তারিখ: `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`\n📦 ফাইলের নাম: `{backup_zip.name}`"
            )
            await status_msg.delete()
        except Exception as e:
            await status_msg.edit_text(f"❌ ব্যাকআপ তৈরিতে সমস্যা: `{e}`")
        finally:
            try:
                backup_zip.unlink(missing_ok=True)
            except Exception:
                pass

    # Media router for manual comments with attachments (photos, videos, documents, voice, stickers) and inbox delivery
    @bot.on_message(filters.private & (filters.photo | filters.video | filters.document | filters.voice | filters.audio | filters.sticker | filters.animation))
    async def media_message_router(_, message: Message):
        user_id = message.from_user.id
        action_data = user_action_states.get(user_id)
        if isinstance(action_data, dict):
            if action_data.get("action") == "AWAITING_ATTACHMENT_COMMENT":
                user_action_states.pop(user_id, None)
                await execute_attachment_comment_flow(user_id, message)
                return
            elif action_data.get("action") == "AWAITING_INBOX_CONTENT":
                target_account = action_data.get("target_account", "ALL")
                target_inbox = action_data.get("target_inbox")
                user_engines = manager.get_user_engines(user_id)
                target_count = len(user_engines) if target_account == "ALL" else 1

                # If user only targeted 1 account, send immediately!
                if target_count <= 1:
                    user_action_states.pop(user_id, None)
                    await execute_inbox_media_delivery(user_id, target_account, message, target_inbox=target_inbox)
                    return

                caption = message.caption or ""
                media_type = "text"
                ext = ""
                if message.photo:
                    media_type = "photo"
                    ext = ".jpg"
                elif message.video:
                    media_type = "video"
                    ext = ".mp4"
                elif message.document:
                    media_type = "document"
                    from pathlib import Path
                    orig_name = getattr(message.document, "file_name", "")
                    ext = Path(orig_name).suffix if orig_name else ".dat"
                elif message.voice:
                    media_type = "voice"
                    ext = ".ogg"
                elif message.audio:
                    media_type = "audio"
                    from pathlib import Path
                    orig_name = getattr(message.audio, "file_name", "")
                    ext = Path(orig_name).suffix if orig_name else ".mp3"
                elif message.sticker:
                    media_type = "sticker"
                    ext = ".webp"
                elif message.animation:
                    media_type = "animation"
                    ext = ".mp4"

                temp_dir = config.BASE_DIR / "temp_media"
                temp_dir.mkdir(exist_ok=True)
                file_target = str(temp_dir / f"inbox_{user_id}_{message.id}{ext}")
                media_path = await message.download(file_name=file_target)

                items = action_data.setdefault("items", [])
                items.append({
                    "media_type": media_type,
                    "media_path": media_path,
                    "caption": caption
                })
                item_count = len(items)
                target_display = target_inbox or "Inbox"

                if get_user_lang(user_id) == "bn":
                    cap_note = f"\n📝 ক্যাপশন: *{caption[:50]}...*" if caption else ""
                    txt = (
                        f"📸 **ছবি/মিডিয়া #{item_count} গ্রহণ করা হয়েছে!**{cap_note}\n\n"
                        f"🎯 প্রাপক: `{target_display}`\n"
                        f"👥 অ্যাকাউন্ট সংখ্যা: **{target_count} টি** | 📦 লোড করা আইটেম: **{item_count} টি**\n\n"
                        f"• আপনি চাইলে আরও ছবি (ক্যাপশন সহ) বা টেক্সট পাঠাতে পারেন (পরবর্তী অ্যাকাউন্টে যাবে)।\n"
                        f"• সবগুলো ছবি ও টেক্সট দেওয়া শেষ হলে নিচে **[🚀 এখনই পাঠান]** বাটনে চাপুন।"
                    )
                else:
                    cap_note = f"\n📝 Caption: *{caption[:50]}...*" if caption else ""
                    txt = (
                        f"📸 **Photo/Media #{item_count} received!**{cap_note}\n\n"
                        f"🎯 Target: `{target_display}`\n"
                        f"👥 Accounts: **{target_count}** | 📦 Items: **{item_count}**\n\n"
                        f"• You can send more photos (with caption) or text for the next accounts.\n"
                        f"• When finished, click **[🚀 Send Now]** below."
                    )
                await message.reply_text(txt, reply_markup=inbox_send_now_keyboard(user_id, count=item_count, current_delay=action_data.get("delay_preset", "1-5")))
                return
            elif action_data.get("action") == "AWAITING_LIVE_VOICE_AUDIO":
                await execute_live_voice_delivery(user_id, action_data, message)
                return

    # Interactive text router
    @bot.on_message(filters.private & filters.text & ~filters.command(["start", "help", "add", "cancel", "accounts", "join", "leave", "comment", "status", "remove", "add_session", "admin_stats", "set_vip", "del_vip", "vip_list", "inbox", "backup"]))
    async def interactive_text_router(_, message: Message):
        user_id = message.from_user.id
        text = message.text.strip()

        action_data = user_action_states.get(user_id)

        # Custom Delay Input
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_CUSTOM_DELAY":
            clean_text = text.replace(" ", "")
            min_d = None
            max_d = None
            label = ""

            if "-" in clean_text:
                parts = clean_text.split("-", 1)
                try:
                    p1 = float(parts[0])
                    p2 = float(parts[1])
                    if p1 > 0 and p2 >= p1:
                        min_d, max_d = p1, p2
                        label = f"{p1:g}-{p2:g}"
                except ValueError:
                    pass
            else:
                try:
                    val = float(clean_text)
                    if val > 0:
                        min_d, max_d = val, val
                        label = f"{val:g}"
                except ValueError:
                    pass

            if min_d is None or max_d is None:
                err = "❌ দয়া করে সঠিক সংখ্যা বা রেঞ্জ লিখুন! (যেমন: 5 অথবা 2-5)" if get_user_lang(user_id) == "bn" else "❌ Please enter a valid number or range! (e.g. 5 or 2-5)"
                await message.reply_text(err, reply_markup=cancel_keyboard(user_id))
                return

            action_data["action"] = action_data.get("previous_action", "AWAITING_INBOX_CONTENT")
            action_data["delay_preset"] = label
            action_data["custom_min_delay"] = min_d
            action_data["custom_max_delay"] = max_d

            items = action_data.get("items", [])
            item_count = len(items)
            target_inbox = action_data.get("target_inbox")
            target_display = target_inbox or "Inbox"
            target_account = action_data.get("target_account", "ALL")
            user_accounts = manager.get_user_accounts_list(user_id)
            target_count = len(user_accounts) if target_account == "ALL" else 1

            if get_user_lang(user_id) == "bn":
                txt = (
                    f"✅ **মেসেজিং বিরতি ম্যানুয়ালি সেট করা হয়েছে: `{label}` সেকেন্ড!**\n\n"
                    f"🎯 প্রাপক: `{target_display}`\n"
                    f"👥 অ্যাকাউন্ট সংখ্যা: **{target_count} টি** | 📦 সংগৃহীত আইটেম: **{item_count} টি**\n\n"
                    f"• প্রতিটি অ্যাকাউন্টের মাঝে এখন `{label}` সেকেন্ড বিরতি দিয়ে মেসেজ যাবে।\n"
                    f"• নতুন ছবি/টেক্সট দিতে পারেন অথবা প্রস্তুত হলে নিচে **[🚀 এখনই পাঠান]** বাটনে চাপ দিন।"
                )
            else:
                txt = (
                    f"✅ **Messaging delay manually set: `{label}` seconds!**\n\n"
                    f"🎯 Target: `{target_display}`\n"
                    f"👥 Accounts: **{target_count}** | 📦 Items: **{item_count}**\n\n"
                    f"• Messages will now be sent with `{label}`s delay between accounts.\n"
                    f"• Send more items or click **[🚀 Send Now]** below."
                )
            await message.reply_text(txt, reply_markup=inbox_send_now_keyboard(user_id, count=item_count, current_delay=label))
            return

        # Poll Voting Link Input
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_POLL_LINK":
            parsed = parse_telegram_post_link(text)
            if not parsed:
                err = "❌ সঠিক টেলিগ্রাম পোল বা মেসেজের লিংক দিন! (যেমন: `https://t.me/channel/123`)" if get_user_lang(user_id) == "bn" else "❌ Please provide a valid Telegram poll/message link! (e.g. `https://t.me/channel/123`)"
                await message.reply_text(err, reply_markup=cancel_keyboard(user_id))
                return

            chat_id, message_id = parsed
            status_msg = await message.reply_text("⏳ পোল তথ্য যাচাই করা হচ্ছে..." if get_user_lang(user_id) == "bn" else "⏳ Fetching poll info...")
            poll_info = await manager.get_poll_info_for_user(user_id, chat_id, message_id)
            if "error" in poll_info:
                await status_msg.edit_text(
                    f"❌ পোল পাওয়া যায়নি বা অ্যাক্সেস করা যায়নি: `{poll_info['error']}`" if get_user_lang(user_id) == "bn" else f"❌ Could not fetch poll: `{poll_info['error']}`",
                    reply_markup=main_menu_keyboard(user_id)
                )
                user_action_states.pop(user_id, None)
                return

            action_data["action"] = "AWAITING_POLL_VOTE"
            action_data["chat_id"] = chat_id
            action_data["message_id"] = message_id
            action_data["options"] = poll_info["options"]

            q_text = poll_info["question"]
            opts_count = len(poll_info["options"])
            if get_user_lang(user_id) == "bn":
                txt = (
                    f"🗳️ **পোল শনাক্ত হয়েছে!**\n\n"
                    f"❓ **প্রশ্ন:** *{q_text}*\n"
                    f"📊 মোট অপশন: **{opts_count} টি**\n\n"
                    f"👉 আপনার সবগুলো অ্যাকাউন্ট দিয়ে **কোন অপশনে ভোট দিতে চান** নিচের বাটন থেকে নির্বাচন করুন:"
                )
            else:
                txt = (
                    f"🗳️ **Poll Detected!**\n\n"
                    f"❓ **Question:** *{q_text}*\n"
                    f"📊 Total Options: **{opts_count}**\n\n"
                    f"👉 Select which option all your accounts should vote for:"
                )
            await status_msg.edit_text(txt, reply_markup=poll_options_keyboard(poll_info["options"], user_id))
            return

        # Post Engagement Link Input
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_POST_ENGAGE_LINK":
            parsed = parse_telegram_post_link(text)
            if not parsed:
                clean_ch = text.strip().replace("http://", "").replace("https://", "").replace("t.me/", "").lstrip("@").rstrip("/")
                if clean_ch and "/" not in clean_ch:
                    user_accounts = manager.get_user_accounts_list(user_id)
                    if user_accounts:
                        engine = manager.get_user_engines(user_id).get(user_accounts[0])
                        if engine:
                            try:
                                await engine.ensure_started()
                                async for latest_m in engine.client.get_chat_history(clean_ch, limit=1):
                                    parsed = (clean_ch, latest_m.id)
                                    break
                            except Exception as fe:
                                logger.debug(f"Could not auto-fetch latest post for {clean_ch}: {fe}")

            if not parsed:
                err = (
                    "❌ **সঠিক টেলিগ্রাম পোস্টের লিংক দিন!** (যেমন: `https://t.me/channel/123`)\n\n"
                    "💡 **টিপস:** আপনি যদি চ্যানেলের প্রতিটি নতুন পোস্টে কোনো লিংক ছাড়াই স্বয়ংক্রিয়ভাবে ভিউ এবং রিঅ্যাকশন পেতে চান, তবে মেনু থেকে **📡 অটো চ্যানেল মনিটর** অপশনটি ব্যবহার করুন।"
                ) if get_user_lang(user_id) == "bn" else (
                    "❌ **Please provide a valid Telegram post link!** (e.g. `https://t.me/channel/123`)\n\n"
                    "💡 **Tip:** If you want automatic views and reactions on all new channel posts, use **📡 Auto Channel Monitor** from the main menu."
                )
                await message.reply_text(err, reply_markup=cancel_keyboard(user_id))
                return

            chat_id, message_id = parsed
            engage_mode = action_data.get("engage_mode", "both")

            if engage_mode == "views":
                user_accounts = manager.get_user_accounts_list(user_id)
                if len(user_accounts) <= 1:
                    can_eng, allowed_cnt, used_e, lim_e = can_use_post_engage(user_id, 1)
                    if not can_eng:
                        user_action_states.pop(user_id, None)
                        _, contact_url = await get_admin_contact(user_id=user_id)
                        kb = InlineKeyboardMarkup([[InlineKeyboardButton("💎 VIP মেম্বারশিপ নিন", url=contact_url)]]) if contact_url else main_menu_keyboard(user_id)
                        err_msg = (
                            f"❌ **আপনার আজকের ফ্রি পোস্ট ভিউ লিমিট (৫টি অ্যাকাউন্ট) শেষ হয়ে গেছে!**\n\n"
                            f"📊 ব্যবহৃত: **{used_e}/{lim_e}** টি অ্যাকাউন্ট\n"
                            f"💡 প্রতিদিন ফ্রিতে সর্বোচ্চ ৫টি অ্যাকাউন্ট দিয়ে ভিউ বাড়ানো যায়। আনলিমিটেড ভিউর জন্য VIP মেম্বারশিপে আপগ্রেড করুন।"
                        ) if get_user_lang(user_id) == "bn" else (
                            f"❌ **Your free daily post view limit (5 accounts) is reached!**\n\n"
                            f"📊 Used: **{used_e}/{lim_e}** accounts\n"
                            f"💡 Free tier allows up to 5 accounts daily. Upgrade to VIP for unlimited views."
                        )
                        await message.reply_text(err_msg, reply_markup=kb)
                        return

                    user_action_states.pop(user_id, None)
                    status_msg = await message.reply_text("👁️ ভিউ বাড়ানো হচ্ছে..." if get_user_lang(user_id) == "bn" else "👁️ Boosting views...")
                    res = await manager.react_and_view_post_for_user(user_id, "ALL", chat_id, message_id, do_view=True, do_react=False)
                    if not is_vip(user_id) and res.get("success", 0) > 0:
                        record_engage_usage(user_id, res["success"])
                    details = "\n".join(res.get("details", [])[:10])
                    txt = f"👁️ **পোস্ট ভিউ সম্পন্ন!**\n\n✅ সফল: **{res['success']}/{res['total']}** টি অ্যাকাউন্ট\n\n{details}" if get_user_lang(user_id) == "bn" else f"👁️ **Post Views Completed!**\n\n✅ Successful: **{res['success']}/{res['total']}** accounts\n\n{details}"
                    await status_msg.edit_text(txt, reply_markup=main_menu_keyboard(user_id))
                    return

                action_data["chat_id"] = chat_id
                action_data["message_id"] = message_id
                action_data["action"] = "AWAITING_VIEW_ACC_SELECT"
                rem_e = get_remaining_engage_balance(user_id)
                quota_note = "" if is_vip(user_id) else (f"\n(💡 ফ্রি কোটা: আজ **{rem_e}/{FREE_DAILY_ENGAGE_ACCOUNT_LIMIT}** টি অ্যাকাউন্ট বাকি)" if get_user_lang(user_id) == "bn" else f"\n(💡 Free quota: **{rem_e}/{FREE_DAILY_ENGAGE_ACCOUNT_LIMIT}** accounts left today)")
                if get_user_lang(user_id) == "bn":
                    msg = f"👥 **কোন অ্যাকাউন্টগুলো দিয়ে ভিউ বাড়াতে চান?**{quota_note}\n\nসবগুলো বা নির্দিষ্ট অ্যাকাউন্ট বেছে নিন:"
                else:
                    msg = f"👥 **Which accounts should boost views?**{quota_note}\n\nSelect all or choose specific accounts:"
                await message.reply_text(msg, reply_markup=generic_account_selector_keyboard(user_accounts, user_id, "btn_viewacc"))
                return

            action_data["chat_id"] = chat_id
            action_data["message_id"] = message_id
            action_data["action"] = "AWAITING_REACTION_SELECTION"

            if get_user_lang(user_id) == "bn":
                txt = (
                    "❤️ **কোন রিঅ্যাকশনটি দিতে চান নির্বাচন করুন:**\n\n"
                    "নিচের যেকোনো ইমোজিতে চাপ দিন অথবা র‍্যান্ডম রিঅ্যাকশন বেছে নিন:"
                )
            else:
                txt = (
                    "❤️ **Select Reaction Emoji:**\n\n"
                    "Choose an emoji below or pick Random Reaction:"
                )
        # Auto Live Join - Step 1: Channel/Group Target Link or Username
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_AUTO_LIVE_TARGET":
            raw_items = [x.strip() for x in text.replace(",", "\n").split("\n") if x.strip()]
            if not raw_items:
                err = "❌ দয়া করে চ্যানেল বা গ্রুপের সঠিক লিংক বা ইউজারনেম দিন!" if get_user_lang(user_id) == "bn" else "❌ Please provide a valid channel or group link/username!"
                await message.reply_text(err, reply_markup=cancel_keyboard(user_id))
                return

            status_msg = await message.reply_text("⏳ টার্গেট চ্যানেল/গ্রুপ যাচাই করা হচ্ছে..." if get_user_lang(user_id) == "bn" else "⏳ Validating target(s)...")

            added_targets = []
            failed_targets = []

            for item in raw_items:
                res = await manager.resolve_auto_live_target(user_id, item)
                if "error" in res:
                    failed_targets.append(f"`{item}`: {res['error']}")
                else:
                    saved = add_live_target(
                        user_id=user_id,
                        target_input=item,
                        chat_id=res["chat_id"],
                        title=res["title"],
                        username=res.get("username", ""),
                        invite_link=res.get("invite_link", ""),
                        accounts_count=0
                    )
                    added_targets.append((saved, res))

            user_action_states.pop(user_id, None)

            if not added_targets:
                err_details = "\n".join(failed_targets[:5])
                err_text = f"❌ কোনো টার্গেট যুক্ত করা সম্ভব হয়নি:\n\n{err_details}" if get_user_lang(user_id) == "bn" else f"❌ Could not add target(s):\n\n{err_details}"
                await status_msg.edit_text(err_text, reply_markup=cancel_keyboard(user_id))
                return

            user_accounts = manager.get_user_accounts_list(user_id)
            total_accs = len(user_accounts)

            resp_lines = []
            for saved, res in added_targets:
                live_badge = "🔴 (এখনই লাইভ চলছে!)" if res.get("is_live") else "🟢 (মনিটরিং সক্রিয়)"
                u_str = f" (@{res['username']})" if res.get("username") else ""
                resp_lines.append(f"• **{res['title']}**{u_str} {live_badge}")

            warn_str = ""
            if failed_targets:
                warn_str = f"\n⚠️ ব্যর্থ ({len(failed_targets)}টি): {', '.join([f.split(':')[0] for f in failed_targets[:3]])}\n"

            if get_user_lang(user_id) == "bn":
                txt = (
                    "✅ **অটো লাইভ জয়েন টার্গেট সফলভাবে সংরক্ষিত হয়েছে!**\n\n"
                    f"{chr(10).join(resp_lines)}{warn_str}\n\n"
                    f"👥 নির্বাচিত জয়েনিং অ্যাকাউন্ট: **সবগুলো ({total_accs} টি)**\n"
                    "⏱️ যখনই এই চ্যানেল বা গ্রুপে লাইভ শুরু হবে, বট স্বয়ংক্রিয়ভাবে আপনার অ্যাকাউন্টগুলো জয়েন করিয়ে দেবে এবং আপনাকে নোটিফিকেশন পাঠাবে!\n\n"
                    "💡 নিচে বাটনে চাপ দিয়ে যেকোনো সময় অ্যাকাউন্ট সংখ্যা বা সেটিংস পরিবর্তন করতে পারেন।"
                )
            else:
                txt = (
                    "✅ **Auto Live Target Successfully Saved!**\n\n"
                    f"{chr(10).join(resp_lines)}{warn_str}\n\n"
                    f"👥 Joined Accounts: **All ({total_accs} accounts)**\n"
                    "⏱️ Whenever a live stream starts in this chat, your accounts will automatically join and you will receive a notification!\n\n"
                    "💡 Use the buttons below to customize settings."
                )

            if len(added_targets) == 1:
                t_obj = added_targets[0][0]
                await status_msg.edit_text(txt, reply_markup=auto_live_target_detail_keyboard(t_obj, user_id))
            else:
                all_targets = get_user_live_targets(user_id)
                await status_msg.edit_text(txt, reply_markup=auto_live_list_keyboard(all_targets, user_id))
            return

        # Auto Live Join - Step 2: Custom Accounts Count Input
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_AUTO_LIVE_CUSTOM_COUNT":
            target_id = action_data.get("target_id")
            if not text.isdigit() or int(text) < 0:
                err = "❌ দয়া করে সঠিক সংখ্যা লিখুন! (যেমন: 5 অথবা 0 লিখলে সবগুলো)" if get_user_lang(user_id) == "bn" else "❌ Please enter a valid number! (e.g. 5, or 0 for All)"
                await message.reply_text(err, reply_markup=cancel_keyboard(user_id))
                return

            cnt = int(text)
            update_live_target_count(target_id, cnt)
            user_action_states.pop(user_id, None)

            target = get_live_target_by_id(target_id)
            ch_title = target.get("chat_title", "Target") if target else "Target"
            cnt_text = f"{cnt} টি" if cnt > 0 else "সবগুলো (All)"

            if get_user_lang(user_id) == "bn":
                txt = f"✅ **'{ch_title}' এর জন্য লাইভ জয়েন অ্যাকাউন্ট সংখ্যা `{cnt_text}` সেট করা হয়েছে!**"
            else:
                txt = f"✅ **Live join accounts count set to `{cnt_text}` for '{ch_title}'!**"

            if target:
                await message.reply_text(txt, reply_markup=auto_live_target_detail_keyboard(target, user_id))
            else:
                await message.reply_text(txt, reply_markup=main_menu_keyboard(user_id))
            return

        # Auto Channel Monitor - Step 1: Channel Link/Username (Single or Multiple)
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_AUTO_MON_CHANNEL":
            raw_items = [x.strip() for x in text.replace(",", "\n").split("\n") if x.strip()]
            if not raw_items:
                err = "❌ দয়া করে এক বা একাধিক চ্যানেলের লিংক বা ইউজারনেম দিন!" if get_user_lang(user_id) == "bn" else "❌ Please send valid channel links or usernames!"
                await message.reply_text(err, reply_markup=cancel_keyboard(user_id))
                return

            status_msg = await message.reply_text("⏳ চ্যানেল(গুলো) যাচাই করা হচ্ছে..." if get_user_lang(user_id) == "bn" else "⏳ Validating channel(s)...")

            resolved_channels = []
            failed_channels = []

            for item in raw_items:
                res = await manager.resolve_channel_for_user(user_id, item)
                if "error" in res:
                    failed_channels.append(f"`{item}`: {res['error']}")
                else:
                    if not any(c["chat_id"] == res["chat_id"] for c in resolved_channels):
                        resolved_channels.append(res)

            if not resolved_channels:
                err_details = "\n".join(failed_channels[:5])
                err_text = f"❌ কোনো চ্যানেল যাচাই করা সম্ভব হয়নি:\n\n{err_details}" if get_user_lang(user_id) == "bn" else f"❌ Could not verify channel(s):\n\n{err_details}"
                await status_msg.edit_text(err_text, reply_markup=cancel_keyboard(user_id))
                return

            action_data["action"] = "AWAITING_AUTO_MON_VIEWS"
            action_data["channels"] = resolved_channels

            user_accounts = manager.get_user_accounts_list(user_id)
            total_accs = len(user_accounts)

            ch_list_str = ""
            for idx, ch in enumerate(resolved_channels, start=1):
                u_str = f" (@{ch['username']})" if ch.get("username") else ""
                ch_list_str += f"{idx}. **{ch['title']}**{u_str}\n"

            warn_str = ""
            if failed_channels:
                warn_str = f"\n⚠️ ব্যর্থ হয়েছে ({len(failed_channels)}টি): {', '.join([f.split(':')[0] for f in failed_channels[:3]])}\n"

            if get_user_lang(user_id) == "bn":
                limit_info = (
                    f"⚠️ **ফ্রি ইউজার সীমা:** প্রতিদিন সর্বোচ্চ **{FREE_DAILY_ENGAGE_ACCOUNT_LIMIT}টি** অ্যাকাউন্ট ব্যবহার করতে পারবেন। (VIP মেম্বারদের জন্য আনলিমিটেড)\n\n"
                    f"👉 প্রতিটি চ্যানেলের নতুন পোস্টে কতটি করে ভিউ চান লিখে পাঠান (সর্বোচ্চ {FREE_DAILY_ENGAGE_ACCOUNT_LIMIT}):"
                ) if not is_vip(user_id) else (
                    f"(আপনার কাছে মোট **{total_accs}টি** অ্যাকাউন্ট যুক্ত আছে)\n\n"
                    f"👉 প্রতিটি চ্যানেলের নতুন পোস্টে কতটি করে ভিউ চান লিখে পাঠান (যেমন: `5` বা `10`):"
                )
                txt = (
                    f"✅ **মোট {len(resolved_channels)}টি চ্যানেল সফলভাবে শনাক্ত হয়েছে!**\n\n"
                    f"{ch_list_str}{warn_str}\n"
                    f"👁️ **ভিউ সংখ্যা নির্ধারণ করুন:**\n"
                    f"{limit_info}"
                )
            else:
                limit_info = (
                    f"⚠️ **Free Tier Limit:** Free users can use up to **{FREE_DAILY_ENGAGE_ACCOUNT_LIMIT}** accounts daily. (VIP is Unlimited)\n\n"
                    f"👉 Enter desired views count per post (max {FREE_DAILY_ENGAGE_ACCOUNT_LIMIT}):"
                ) if not is_vip(user_id) else (
                    f"(You currently have **{total_accs}** connected accounts)\n\n"
                    f"👉 Enter desired views count per post (e.g. `5` or `10`):"
                )
                txt = (
                    f"✅ **{len(resolved_channels)} Channel(s) Verified!**\n\n"
                    f"{ch_list_str}{warn_str}\n"
                    f"👁️ **Set Views Count:**\n"
                    f"{limit_info}"
                )
            await status_msg.edit_text(txt, reply_markup=cancel_keyboard(user_id))
            return

        # Auto Channel Monitor - Step 2: Desired View Count
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_AUTO_MON_VIEWS":
            clean_text = text.strip()
            if not clean_text.isdigit() or int(clean_text) <= 0:
                err = "❌ দয়া করে একটি সঠিক ধনাত্মক সংখ্যা লিখুন! (যেমন: 5 বা 10)" if get_user_lang(user_id) == "bn" else "❌ Please enter a valid positive number! (e.g. 5 or 10)"
                await message.reply_text(err, reply_markup=cancel_keyboard(user_id))
                return

            views_count = int(clean_text)
            limit_notice = ""
            if not is_vip(user_id) and views_count > FREE_DAILY_ENGAGE_ACCOUNT_LIMIT:
                views_count = FREE_DAILY_ENGAGE_ACCOUNT_LIMIT
                limit_notice = (
                    f"\n\nℹ️ **ফ্রি লিমিট নোটিশ:** সাধারণ ইউজারদের জন্য সর্বোচ্চ {FREE_DAILY_ENGAGE_ACCOUNT_LIMIT}টি অ্যাকাউন্ট লিমিট প্রযোজ্য। তাই ভিউ সংখ্যা স্বয়ংক্রিয়ভাবে **{FREE_DAILY_ENGAGE_ACCOUNT_LIMIT}টি** সেট করা হলো। (আনলিমিটেডের জন্য VIP নিন)"
                    if get_user_lang(user_id) == "bn" else
                    f"\n\nℹ️ **Free Limit Notice:** Free tier is limited to {FREE_DAILY_ENGAGE_ACCOUNT_LIMIT} accounts. Automatically set to **{FREE_DAILY_ENGAGE_ACCOUNT_LIMIT}** views! (Upgrade to VIP for unlimited)"
                )

            action_data["views_count"] = views_count
            action_data["action"] = "AWAITING_AUTO_MON_REACTION"

            channels = action_data.get("channels", [])
            ch_count = len(channels)
            ch_display = f"{ch_count}টি চ্যানেল" if ch_count > 1 else (channels[0]["title"] if channels else "Channel")

            if get_user_lang(user_id) == "bn":
                txt = (
                    f"📢 **নির্বাচিত চ্যানেল:** {ch_display}\n"
                    f"👁️ **ভিউ সংখ্যা:** {views_count} টি{limit_notice}\n\n"
                    f"❤️ **কোন ধরনের রিঅ্যাকশন দিতে চান নির্বাচন করুন:**\n"
                    f"• `🎲 সকল পজিটিভ রিঅ্যাকশন`: বট বিভিন্ন পজিটিভ রিঅ্যাকশন (🔥, ❤️, 💖, 👍, 🎉 ইত্যাদি) মিক্স করে দেবে।\n"
                    f"• অথবা নিচে থেকে নির্দিষ্ট কোনো ইমোজি বেছে নিন:"
                )
            else:
                txt = (
                    f"📢 **Target Channel(s):** {ch_display}\n"
                    f"👁️ **Views Count:** {views_count}{limit_notice}\n\n"
                    f"❤️ **Select Reaction Preference:**\n"
                    f"• `🎲 All Positive Reactions`: Bot randomly picks positive reactions (🔥, ❤️, 💖, 👍, 🎉 etc.).\n"
                    f"• Or choose a specific emoji below:"
                )
            await message.reply_text(txt, reply_markup=auto_reaction_choice_keyboard(user_id))
            return

        # Auto Channel Monitor Custom Emoji Input
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_CUSTOM_REACTION":
            user_action_states.pop(user_id, None)
            raw_emojis = text.strip()
            # Split by comma or whitespace to support single or multiple emojis
            clean_emojis = " ".join([e.strip() for e in raw_emojis.replace(",", " ").split() if e.strip()])
            if not clean_emojis:
                user_action_states[user_id] = action_data
                err_msg = "❌ দয়া করে কমপক্ষে একটি সঠিক ইমোজি লিখুন! (যেমন: 🔥 বা 🔥 ❤️ ⚡)" if get_user_lang(user_id) == "bn" else "❌ Please enter at least one valid emoji! (e.g. 🔥 or 🔥 ❤️ ⚡)"
                await message.reply_text(err_msg, reply_markup=cancel_keyboard(user_id))
                return

            is_editing = action_data.get("is_editing", False)
            if is_editing:
                mon_id = action_data.get("monitor_id")
                updated = update_monitor_reaction(mon_id, user_id, "SPECIFIC", clean_emojis)
                if updated:
                    mon = get_monitor_by_id(mon_id)
                    st = "🟢 সক্রিয় (Active)" if mon.get("is_active", True) else "⏸️ সাময়িক বন্ধ (Paused)"
                    if get_user_lang(user_id) == "bn":
                        txt = (
                            f"✅ **চ্যানেল রিঅ্যাকশন সফলভাবে পরিবর্তন করা হয়েছে!**\n\n"
                            f"📢 **চ্যানেল:** {mon.get('channel_title', 'Channel')}\n"
                            f"📊 **স্ট্যাটাস:** {st}\n"
                            f"👁️ **ভিউ:** **{mon.get('views_count', 5)}** টি\n"
                            f"❤️ **কাস্টম রিঅ্যাকশন:** {clean_emojis}\n\n"
                            f"💡 *এখন থেকে নতুন পোস্টে এই রিঅ্যাকশনগুলো স্বয়ংক্রিয়ভাবে অ্যাকাউন্টভেদে বিতরণ করা হবে।*"
                        )
                    else:
                        txt = (
                            f"✅ **Monitor Reaction Updated Successfully!**\n\n"
                            f"📢 **Channel:** {mon.get('channel_title', 'Channel')}\n"
                            f"📊 **Status:** {st}\n"
                            f"👁️ **Views:** **{mon.get('views_count', 5)}**\n"
                            f"❤️ **Custom Reaction:** {clean_emojis}\n\n"
                            f"💡 *New posts will now automatically receive these rotated custom reactions.*"
                        )
                    await message.reply_text(txt, reply_markup=auto_monitor_detail_keyboard(user_id, mon_id, mon.get("is_active", True)))
                else:
                    await message.reply_text("❌ মনিটর পাওয়া যায়নি বা আপডেট ব্যর্থ হয়েছে।", reply_markup=main_menu_keyboard(user_id))
                return

            views = action_data.get("views_count", 5)
            channels = action_data.get("channels", [])
            if not channels and "channel_id" in action_data:
                channels = [{
                    "chat_id": action_data["channel_id"],
                    "title": action_data.get("channel_title", "Channel"),
                    "username": action_data.get("channel_username", ""),
                    "last_msg_id": action_data.get("last_msg_id", 0)
                }]

            for ch in channels:
                add_channel_monitor(
                    user_id=user_id,
                    channel_id=ch["chat_id"],
                    channel_title=ch.get("title", "Channel"),
                    channel_username=ch.get("username", ""),
                    views_count=views,
                    reaction_mode="SPECIFIC",
                    specific_emoji=clean_emojis,
                    last_msg_id=ch.get("last_msg_id", 0),
                    invite_link=ch.get("invite_link", "")
                )

            if len(channels) == 1:
                ch_title = channels[0].get("title", "Channel")
                ch_user = channels[0].get("username", "")
                if get_user_lang(user_id) == "bn":
                    txt = (
                        "🎉 **অটো চ্যানেল পোস্ট মনিটর সফলভাবে চালু হয়েছে!**\n\n"
                        f"📢 **চ্যানেল:** {ch_title} (@{ch_user or 'Private'})\n"
                        f"👁️ **ভিউ সংখ্যা:** প্রতি পোস্টে **{views}টি** ভিউ\n"
                        f"❤️ **কাস্টম রিঅ্যাকশন:** {clean_emojis}\n"
                        f"⏱️ **অটো টাইমিং:** নতুন পোস্ট আসার **১ থেকে ৫ সেকেন্ডের** মধ্যে সম্পন্ন হবে!\n\n"
                        "💡 *এখন থেকে এই চ্যানেলে নতুন যেকোনো পোস্ট হলেই স্বয়ংক্রিয়ভাবে ভিউ ও কাস্টম রিঅ্যাকশন প্রদান করা হবে।*"
                    )
                else:
                    txt = (
                        "🎉 **Auto Channel Post Monitor Activated!**\n\n"
                        f"📢 **Channel:** {ch_title} (@{ch_user or 'Private'})\n"
                        f"👁️ **Views Target:** **{views}** views per post\n"
                        f"❤️ **Custom Reactions:** {clean_emojis}\n"
                        f"⏱️ **Timing:** Automatically delivered within **1–5 seconds** of new post!\n\n"
                        "💡 *Whenever you publish a new post in this channel, views and custom reactions will be applied automatically.*"
                    )
            else:
                ch_names = "\n".join([f"• **{c.get('title', 'Channel')}** (@{c.get('username') or 'Private'})" for c in channels])
                if get_user_lang(user_id) == "bn":
                    txt = (
                        f"🎉 **মোট {len(channels)}টি চ্যানেলে অটো পোস্ট মনিটর সফলভাবে চালু হয়েছে!**\n\n"
                        f"📋 **যুক্ত হওয়া চ্যানেলসমূহ:**\n{ch_names}\n\n"
                        f"👁️ **ভিউ সংখ্যা:** প্রতি চ্যানেলে নতুন পোস্টে **{views}টি** ভিউ\n"
                        f"❤️ **কাস্টম রিঅ্যাকশন:** {clean_emojis}\n"
                        f"⏱️ **অটো টাইমিং:** নতুন পোস্ট আসার **১ থেকে ৫ সেকেন্ডের** মধ্যে সম্পন্ন হবে!\n\n"
                        "💡 *এখন থেকে এই চ্যানেলগুলোতে নতুন পোস্ট আসার সাথে সাথেই স্বয়ংক্রিয়ভাবে বুস্টিং শুরু হবে।*"
                    )
                else:
                    txt = (
                        f"🎉 **Auto Post Monitor Activated for {len(channels)} Channels!**\n\n"
                        f"📋 **Added Channels:**\n{ch_names}\n\n"
                        f"👁️ **Views Target:** **{views}** views per post\n"
                        f"❤️ **Custom Reactions:** {clean_emojis}\n"
                        f"⏱️ **Timing:** Automatically delivered within **1–5 seconds** of new post!\n\n"
                        "💡 *Whenever new posts are published in these channels, views and reactions will be applied automatically.*"
                    )
            await message.reply_text(txt, reply_markup=main_menu_keyboard(user_id))
            return

        # Auto Channel Monitor 2-5 Emoji Pool (Per Post Single Random Emoji)
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_POOL_REACTION":
            raw_emojis = text.strip()
            emojis = [e.strip() for e in re.split(r'[\s,]+', raw_emojis) if e.strip()]
            if len(emojis) < 2 or len(emojis) > 5:
                err_msg = (
                    "❌ **ভুল ইনপুট!** অনুগ্রহ করে সর্বনিম্ন **২টি** এবং সর্বোচ্চ **৫টি** ইমোজি দিন!\n"
                    "📌 উদাহরণ: `🔥 ❤️ 👍` অথবা `🔥 ❤️ ⚡ 🚀 💯`"
                ) if get_user_lang(user_id) == "bn" else (
                    "❌ **Invalid Input!** Please send between **2 to 5 emojis** separated by space or comma!\n"
                    "📌 Example: `🔥 ❤️ 👍` or `🔥 ❤️ ⚡ 🚀 💯`"
                )
                await message.reply_text(err_msg, reply_markup=cancel_keyboard(user_id))
                return

            user_action_states.pop(user_id, None)
            clean_pool = " ".join(emojis)
            is_editing = action_data.get("is_editing", False)

            if is_editing:
                mon_id = action_data.get("monitor_id")
                updated = update_monitor_reaction(mon_id, user_id, "POOL_PER_POST", clean_pool)
                if updated:
                    mon = get_monitor_by_id(mon_id)
                    st = "🟢 সক্রিয় (Active)" if mon.get("is_active", True) else "⏸️ সাময়িক বন্ধ (Paused)"
                    if get_user_lang(user_id) == "bn":
                        txt = (
                            f"✅ **চ্যানেল রিঅ্যাকশন সফলভাবে পরিবর্তন করা হয়েছে!**\n\n"
                            f"📢 **চ্যানেল:** {mon.get('channel_title', 'Channel')}\n"
                            f"📊 **স্ট্যাটাস:** {st}\n"
                            f"👁️ **ভিউ:** **{mon.get('views_count', 5)}** টি\n"
                            f"🎯 **ইমোজি পুল ({len(emojis)}টি):** {clean_pool}\n"
                            f"🎲 **মোড:** প্রতি নতুন পোস্টে এই পুল থেকে **যেকোনো ১টি ইমোজি** লটারির মতো বেছে নেওয়া হবে এবং সব অ্যাকাউন্ট দিয়ে সেই একই ইমোজিটি পড়বে!"
                        )
                    else:
                        txt = (
                            f"✅ **Monitor Reaction Updated Successfully!**\n\n"
                            f"📢 **Channel:** {mon.get('channel_title', 'Channel')}\n"
                            f"📊 **Status:** {st}\n"
                            f"👁️ **Views:** **{mon.get('views_count', 5)}**\n"
                            f"🎯 **Emoji Pool ({len(emojis)}):** {clean_pool}\n"
                            f"🎲 **Mode:** 1 random emoji picked per post across all accounts."
                        )
                    await message.reply_text(txt, reply_markup=auto_monitor_detail_keyboard(user_id, mon_id, mon.get("is_active", True)))
                else:
                    await message.reply_text("❌ মনিটর পাওয়া যায়নি বা আপডেট ব্যর্থ হয়েছে।", reply_markup=main_menu_keyboard(user_id))
                return

            views = action_data.get("views_count", 5)
            channels = action_data.get("channels", [])
            if not channels and "channel_id" in action_data:
                channels = [{
                    "chat_id": action_data["channel_id"],
                    "title": action_data.get("channel_title", "Channel"),
                    "username": action_data.get("channel_username", ""),
                    "last_msg_id": action_data.get("last_msg_id", 0)
                }]

            for ch in channels:
                add_channel_monitor(
                    user_id=user_id,
                    channel_id=ch["chat_id"],
                    channel_title=ch.get("title", "Channel"),
                    channel_username=ch.get("username", ""),
                    views_count=views,
                    reaction_mode="POOL_PER_POST",
                    specific_emoji=clean_pool,
                    last_msg_id=ch.get("last_msg_id", 0),
                    invite_link=ch.get("invite_link", "")
                )

            if len(channels) == 1:
                ch_title = channels[0].get("title", "Channel")
                ch_user = channels[0].get("username", "")
                if get_user_lang(user_id) == "bn":
                    txt = (
                        "🎉 **অটো চ্যানেল পোস্ট মনিটর সফলভাবে চালু হয়েছে!**\n\n"
                        f"📢 **চ্যানেল:** {ch_title} (@{ch_user or 'Private'})\n"
                        f"👁️ **ভিউ সংখ্যা:** প্রতি পোস্টে **{views}টি** ভিউ\n"
                        f"🎯 **ইমোজি পুল ({len(emojis)}টি):** {clean_pool}\n"
                        f"🎲 **মোড:** প্রতি পোস্টে পুল থেকে **যেকোনো ১টি নির্দিষ্ট ইমোজি** পড়বে (সব অ্যাকাউন্ট একযোগে সেই ইমোজি দেবে)!\n"
                        f"⏱️ **অটো টাইমিং:** নতুন পোস্ট আসার **১ থেকে ৫ সেকেন্ডের** মধ্যে সম্পন্ন হবে!\n\n"
                        "💡 *এখন থেকে নতুন যেকোনো পোস্ট আসলেই স্বয়ংক্রিয়ভাবে বুস্টিং কার্যকর হবে।*"
                    )
                else:
                    txt = (
                        "🎉 **Auto Channel Post Monitor Activated!**\n\n"
                        f"📢 **Channel:** {ch_title} (@{ch_user or 'Private'})\n"
                        f"👁️ **Views Target:** **{views}** views per post\n"
                        f"🎯 **Emoji Pool ({len(emojis)}):** {clean_pool}\n"
                        f"🎲 **Mode:** 1 random emoji chosen per post across all accounts.\n"
                        f"⏱️ **Timing:** Automatically delivered within **1–5 seconds** of new post!"
                    )
            else:
                ch_names = "\n".join([f"• **{c.get('title', 'Channel')}** (@{c.get('username') or 'Private'})" for c in channels])
                if get_user_lang(user_id) == "bn":
                    txt = (
                        f"🎉 **মোট {len(channels)}টি চ্যানেলে অটো পোস্ট মনিটর সফলভাবে চালু হয়েছে!**\n\n"
                        f"📋 **যুক্ত হওয়া চ্যানেলসমূহ:**\n{ch_names}\n\n"
                        f"👁️ **ভিউ সংখ্যা:** প্রতি চ্যানেলে নতুন পোস্টে **{views}টি** ভিউ\n"
                        f"🎯 **ইমোজি পুল ({len(emojis)}টি):** {clean_pool}\n"
                        f"🎲 **মোড:** প্রতি পোস্টে পুল থেকে **যেকোনো ১টি নির্দিষ্ট ইমোজি** পড়বে!\n"
                        f"⏱️ **অটো টাইমিং:** নতুন পোস্ট আসার **১ থেকে ৫ সেকেন্ডের** মধ্যে সম্পন্ন হবে!"
                    )
                else:
                    txt = (
                        f"🎉 **Auto Post Monitor Activated for {len(channels)} Channels!**\n\n"
                        f"📋 **Added Channels:**\n{ch_names}\n\n"
                        f"👁️ **Views Target:** **{views}** views per post\n"
                        f"🎯 **Emoji Pool ({len(emojis)}):** {clean_pool}\n"
                        f"🎲 **Mode:** 1 random emoji chosen per post across all accounts."
                    )
            await message.reply_text(txt, reply_markup=main_menu_keyboard(user_id))
            return

        # Admin Add VIP
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_ADD_VIP_ID":
            user_action_states.pop(user_id, None)
            if not is_admin(user_id):
                return
            target_id, label = await resolve_target_user(text)
            if not target_id:
                await message.reply_text(f"❌ ইউজার `{text}` খুঁজে পাওয়া যায়নি! সঠিক টেলিগ্রাম ইউজারনেম (@username) বা ইউজার আইডি দিন।", reply_markup=admin_panel_keyboard(user_id))
                return
            add_vip_user(target_id)
            await message.reply_text(f"💎 **{label} (`{target_id}`) সফলভাবে VIP মেম্বার তালিকায় যুক্ত হয়েছে!**\nতারা আনলিমিটেড লাইভ কমেন্ট করতে পারবে।", reply_markup=admin_panel_keyboard(user_id))
            return

        # Admin Remove VIP
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_DEL_VIP_ID":
            user_action_states.pop(user_id, None)
            if not is_admin(user_id):
                return
            target_id, label = await resolve_target_user(text)
            if not target_id:
                await message.reply_text(f"❌ ইউজার `{text}` খুঁজে পাওয়া যায়নি! সঠিক টেলিগ্রাম ইউজারনেম (@username) বা ইউজার আইডি দিন।", reply_markup=admin_panel_keyboard(user_id))
                return
            remove_vip_user(target_id)
            await message.reply_text(f"✅ **{label} (`{target_id}`) এর VIP মেম্বারশিপ বাতিল করা হয়েছে।**", reply_markup=admin_panel_keyboard(user_id))
            return

        # Admin Add Admin
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_ADD_ADMIN_ID":
            user_action_states.pop(user_id, None)
            if not is_admin(user_id):
                return
            target_id, label = await resolve_target_user(text)
            if not target_id:
                await message.reply_text(f"❌ ইউজার `{text}` খুঁজে পাওয়া যায়নি! সঠিক টেলিগ্রাম ইউজারনেম (@username) বা ইউজার আইডি দিন।", reply_markup=admin_panel_keyboard(user_id))
                return
            add_admin_user(target_id)
            await message.reply_text(f"🛡️ **{label} (`{target_id}`) সফলভাবে অ্যাডমিন হিসেবে যুক্ত হয়েছে!**\nতারা এখন থেকে অ্যাডমিন প্যানেল দেখতে ও পরিচালনা করতে পারবে।", reply_markup=admin_panel_keyboard(user_id))
            return

        # Admin Remove Admin (Only Super Admin)
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_DEL_ADMIN_ID":
            user_action_states.pop(user_id, None)
            if not is_admin(user_id):
                return
            target_id, label = await resolve_target_user(text)
            if not target_id:
                await message.reply_text(f"❌ ইউজার `{text}` খুঁজে পাওয়া যায়নি! সঠিক টেলিগ্রাম ইউজারনেম (@username) বা ইউজার আইডি দিন।", reply_markup=admin_panel_keyboard(user_id))
                return
            success, reason = remove_admin_user(target_id, requester_id=user_id)
            if not success:
                if reason == "ONLY_SUPER_ADMIN":
                    await message.reply_text("🚫 **অননুমোদিত অ্যাকশন!**\nযুক্ত হওয়া কোনো অ্যাডমিন অন্য অ্যাডমিনকে বাদ দিতে পারবে না। শুধুমাত্র **Super Admin (মালিক)** অ্যাডমিন বাতিল করতে পারবেন।", reply_markup=admin_panel_keyboard(user_id))
                elif reason == "CANNOT_REMOVE_SUPER_ADMIN":
                    await message.reply_text("🚫 **Super Admin (Owner) কে কখনো বাতিল করা যাবে না!**", reply_markup=admin_panel_keyboard(user_id))
                else:
                    await message.reply_text("❌ এই ইউজার অ্যাডমিন তালিকায় নেই।", reply_markup=admin_panel_keyboard(user_id))
                return
            await message.reply_text(f"✅ **{label} (`{target_id}`) এর অ্যাডমিন পদ বাতিল করা হয়েছে।**", reply_markup=admin_panel_keyboard(user_id))
            return

        # Admin Live Stream Inspector Link
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_ADMIN_INSPECT_LINK":
            user_action_states.pop(user_id, None)
            if not is_admin(user_id):
                return
            target_link = text.strip()
            status_msg = await message.reply_text("⏳ **লাইভ স্ট্রিম স্ক্যান ও মেম্বার তালিকা সংগ্রহ করা হচ্ছে...**\nঅনুগ্রহ করে কিছুক্ষণ অপেক্ষা করুন।")
            res = await manager.inspect_live_stream(user_id, target_link)
            if not res.get("success"):
                err_msg = res.get("error", "লাইভ তথ্য আনতে ব্যর্থ হয়েছে।")
                await status_msg.edit_text(f"❌ {err_msg}", reply_markup=admin_panel_keyboard(user_id))
                return

            ch_title = res.get("chat_title", "Live Stream")
            ch_user = f" (@{res['chat_username']})" if res.get("chat_username") else ""
            tot = res.get("total_count", 0)
            speakers = res.get("speakers", [])
            listeners = res.get("listeners", [])
            export_file = res.get("export_file")

            speakers_txt = ""
            for idx, s in enumerate(speakers[:15], 1):
                u_part = f"@{s['username']}" if s.get("username") else "No @user"
                speakers_txt += f"  {idx}. **{s['name']}** ({u_part})\n"
            if not speakers:
                speakers_txt = "  *(কোনো সক্রিয় স্পিকার নেই)*\n"
            elif len(speakers) > 15:
                speakers_txt += f"  *...এবং আরও {len(speakers) - 15} জন*\n"

            listeners_txt = ""
            for idx, l in enumerate(listeners[:20], 1):
                u_part = f"@{l['username']}" if l.get("username") else "No @user"
                listeners_txt += f"  {idx}. **{l['name']}** ({u_part})\n"
            if not listeners:
                listeners_txt = "  *(কোনো শ্রোতা পাওয়া যায়নি)*\n"
            elif len(listeners) > 20:
                listeners_txt += f"  *...এবং আরও {len(listeners) - 20} জন*\n"

            report = (
                f"🎙️ **লাইভ মেম্বার ইন্সপেকশন রিপোর্ট:**\n\n"
                f"📢 চ্যানেল/গ্রুপ: **{ch_title}**{ch_user}\n"
                f"👥 মোট লাইভ মেম্বার: **{tot}** জন\n\n"
                f"🎤 **স্পিকার তালিকা ({len(speakers)} জন):**\n"
                f"{speakers_txt}\n"
                f"🎧 **শ্রোতাদের তালিকা (শীর্ষ ২০ জন):**\n"
                f"{listeners_txt}\n"
                f"📁 *সম্পূর্ণ মেম্বার লিস্ট ও সকল ইউজারনেম নিচে ফাইল আকারে পাঠানো হলো:*"
            )

            user_action_states[user_id] = {
                "action": "INSPECTED_LIVE_RESULT",
                "participants": res.get("participants", []),
                "chat_title": ch_title
            }
            await status_msg.edit_text(report, reply_markup=live_inspection_action_keyboard(user_id))

            if export_file and os.path.exists(export_file):
                try:
                    await message.reply_document(
                        document=export_file,
                        caption=f"📋 **{ch_title}** এর সকল লাইভ মেম্বার ও @username তালিকা।"
                    )
                except Exception as de:
                    logger.warning(f"Could not send export file: {de}")
            return

        # Admin Live DM Message Text / Media Input
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_LIVE_DM_TEXT":
            msg_text = (message.text or message.caption or "").strip()
            media_path = None
            media_type = None

            status_download = None
            if message.photo:
                status_download = await message.reply_text("📥 ফটো ডাউনলোড হচ্ছে...")
                media_path = await message.download()
                media_type = "photo"
            elif message.video:
                status_download = await message.reply_text("📥 ভিডিও ডাউনলোড হচ্ছে...")
                media_path = await message.download()
                media_type = "video"
            elif message.document:
                status_download = await message.reply_text("📥 ফাইল ডাউনলোড হচ্ছে...")
                media_path = await message.download()
                media_type = "document"
            elif message.audio or message.voice:
                status_download = await message.reply_text("📥 অডিও ডাউনলোড হচ্ছে...")
                media_path = await message.download()
                media_type = "audio"

            if status_download:
                try:
                    await status_download.delete()
                except Exception:
                    pass

            if not msg_text and not media_path:
                await message.reply_text("❌ দয়া করে একটি টেক্সট মেসেজ, ফটো বা ভিডিও পাঠান!", reply_markup=cancel_keyboard(user_id))
                return

            participants = action_data.get("participants", [])
            valid_targets = [p for p in participants if p.get("username") or p.get("user_id")]
            if not valid_targets:
                await message.reply_text("❌ মেসেজ পাঠানোর মতো কোনো ভ্যালিড মেম্বার পাওয়া যায়নি।", reply_markup=admin_panel_keyboard(user_id))
                return

            action_data["action"] = "AWAITING_LIVE_DM_COUNT"
            action_data["template_text"] = msg_text
            action_data["media_path"] = media_path
            action_data["media_type"] = media_type

            admin_engines = manager.get_user_engines(user_id)
            all_engines = admin_engines if admin_engines else manager.engines
            acc_count = len(all_engines)

            content_lbl = f"মিডিয়া ({media_type.capitalize()})" if media_type else "টেক্সট"
            if msg_text and media_type:
                content_lbl += " + ক্যাপশন"

            prompt = (
                f"✉️ **মেসেজের কনটেন্ট প্রস্তুত ({content_lbl})!**\n"
                f"🔄 **মাল্টি-অ্যাকাউন্ট রোটেশন:** মোট **{acc_count}টি** অ্যাকাউন্ট স্বয়ংক্রিয়ভাবে ভাগ করে নিয়ে মেসেজ পাঠাবে (কোনো অ্যাকাউন্টে প্রেশার পড়বে না)।\n\n"
                f"👥 মোট প্রাপ্ত মেম্বার: **{len(valid_targets)}** জন\n\n"
                f"👉 **কতজন মেম্বারের কাছে পাঠাতে চান নির্বাচন করুন:**"
            ) if get_user_lang(user_id) == "bn" else (
                f"✉️ **Message Content Ready ({content_lbl})!**\n"
                f"🔄 **Multi-Account Auto Rotation:** Distributing across **{acc_count}** accounts.\n\n"
                f"👥 Total Available Attendees: **{len(valid_targets)}**\n\n"
                f"👉 **Select target attendees count:**"
            )
            await message.reply_text(prompt, reply_markup=live_dm_count_keyboard(user_id, len(valid_targets)))
            return

        # Admin Custom Live Discovery Keyword Search
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_CUSTOM_LIVE_SEARCH":
            user_action_states.pop(user_id, None)
            if not is_admin(user_id):
                return
            query_str = text.strip()
            await execute_live_discovery(user_id, query_str, message)
            return

        # Admin Custom Group Discovery Keyword Search
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_CUSTOM_GROUP_SEARCH":
            user_action_states.pop(user_id, None)
            if not is_admin(user_id):
                return
            query_str = text.strip()
            await execute_group_discovery(user_id, query_str, message)
            return

        # Manual single account removal by typing phone number
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_REMOVE_PHONE":
            entered_clean = text.strip()
            digits_only = re.sub(r"\D", "", entered_clean)

            user_accounts = manager.get_user_accounts_list(user_id)
            matched_acc = None
            for a in user_accounts:
                acc_phone = a.get("phone", "")
                acc_digits = re.sub(r"\D", "", acc_phone)
                # Match full phone, numeric digits, or session_name
                if (acc_phone and entered_clean == acc_phone) or (digits_only and digits_only == acc_digits) or (entered_clean == a.get("session_name")):
                    matched_acc = a
                    break

            lang = get_user_lang(user_id)
            if not matched_acc:
                if lang == "bn":
                    err_msg = (
                        "❌ **নম্বর মেলেনি বা অ্যাকাউন্ট পাওয়া যায়নি!**\n\n"
                        "আপনার সংযুক্ত অ্যাকাউন্টের তালিকায় এই নম্বরের কোনো অ্যাকাউন্ট পাওয়া যায়নি।\n"
                        "দয়া করে আপনার যুক্ত করা সঠিক ফোন নম্বরটি কান্ট্রি কোডসহ মিলিয়ে লিখে পাঠান (অথবা বাতিল করতে নিচের বাটনে চাপুন):"
                    )
                else:
                    err_msg = (
                        "❌ **Phone number not found!**\n\n"
                        "No connected account with this phone number was found in your accounts list.\n"
                        "Please check your accounts and send the exact phone number with country code (or cancel below):"
                    )
                await message.reply_text(err_msg, reply_markup=cancel_keyboard(user_id))
                return

            user_action_states.pop(user_id, None)
            session_name = matched_acc["session_name"]
            acc_name = matched_acc.get("first_name", session_name)

            success = await manager.remove_account(session_name, owner_id=user_id)
            if success:
                in_call = sum(1 for a in manager.get_user_engines(user_id).values() if a.in_call)
                if in_call == 0 and user_id in user_live_tasks:
                    user_live_tasks[user_id].cancel()
                    user_live_tasks.pop(user_id, None)
                    user_live_start_times.pop(user_id, None)

                notice = (
                    f"✅ **'{acc_name}' অ্যাকাউন্টটি সফলভাবে মুছে ফেলা হয়েছে!**\n\n"
                    if lang == "bn" else
                    f"✅ **Account '{acc_name}' has been successfully removed!**\n\n"
                )
            else:
                notice = (
                    "❌ অ্যাকাউন্টটি বাদ দেওয়া সম্ভব হয়নি।\n\n"
                    if lang == "bn" else
                    "❌ Failed to remove account.\n\n"
                )

            rem_text, rem_kb = render_accounts_view(user_id)
            await message.reply_text(f"{notice}{rem_text}", reply_markup=rem_kb)
            return

        # Custom comment text received
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_CUSTOM_COMMENT":
            user_action_states.pop(user_id, None)
            comments = [c.strip() for c in text.split("\n") if c.strip()]
            await execute_comments(user_id, comments, message)
            return

        # AI Humanize comment prompt received
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_AI_COMMENT_PROMPT":
            user_action_states.pop(user_id, None)
            user_in_call = [e for e in manager.get_user_engines(user_id).values() if e.in_call]
            if not user_in_call:
                await message.reply_text(tr(user_id, "no_accounts_in_call"), reply_markup=main_menu_keyboard(user_id))
                return

            can_use, used, limit = can_use_ai(user_id)
            if not can_use:
                await notify_limit_reached(message, user_id, is_manual=False)
                return

            gen_msg = await message.reply_text(tr(user_id, "ai_generating"))
            comments_count = max(len(user_in_call), 3)
            ai_comments = await generate_ai_comments(user_topic_prompt=text, count=comments_count)

            preview_items = "\n".join([f"🔹 {c}" for c in ai_comments[:5]])
            try:
                await gen_msg.edit_text(tr(user_id, "ai_comments_preview", preview=preview_items))
            except Exception:
                pass

            await execute_comments(user_id, ai_comments, message, is_ai=True)
            return

        # Manual attachment / text comment received
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_ATTACHMENT_COMMENT":
            user_action_states.pop(user_id, None)
            await execute_attachment_comment_flow(user_id, message)
            return

        # Inbox target received (User ID or Username)
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_INBOX_TARGET":
            raw_target = text.strip()
            action_data["action"] = "AWAITING_INBOX_CONTENT"
            action_data["target_inbox"] = raw_target
            await message.reply_text(
                tr(user_id, "inbox_prompt", target=raw_target),
                reply_markup=cancel_keyboard(user_id)
            )
            return

        # Inbox content received (text)
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_INBOX_CONTENT":
            target_account = action_data.get("target_account", "ALL")
            target_inbox = action_data.get("target_inbox")
            user_engines = manager.get_user_engines(user_id)
            target_count = len(user_engines) if target_account == "ALL" else 1

            items = action_data.setdefault("items", [])
            # Check if last item was a photo/media with NO caption: attach this text as caption!
            if items and items[-1].get("media_path") and not items[-1].get("caption"):
                items[-1]["caption"] = text
                item_count = len(items)
                target_display = target_inbox or "Inbox"
                if get_user_lang(user_id) == "bn":
                    txt = (
                        f"✍️ **আগের ছবির সাথে ক্যাপশন/টেক্সট যুক্ত করা হয়েছে!**\n\n"
                        f"📝 ক্যাপশন: *{text[:50]}...*\n"
                        f"🎯 প্রাপক: `{target_display}`\n"
                        f"👥 অ্যাকাউন্ট: **{target_count} টি** | 📦 সংগৃহীত আইটেম: **{item_count} টি**\n\n"
                        f"• আরও ছবি বা টেক্সট পাঠাতে পারেন, অথবা নিচে **[🚀 এখনই পাঠান]** চাপুন।"
                    )
                else:
                    txt = (
                        f"✍️ **Caption/Text attached to the previous photo!**\n\n"
                        f"📝 Caption: *{text[:50]}...*\n"
                        f"🎯 Target: `{target_display}`\n"
                        f"👥 Accounts: **{target_count}** | 📦 Items: **{item_count}**\n\n"
                        f"• Send more items, or click **[🚀 Send Now]** below."
                    )
                await message.reply_text(txt, reply_markup=inbox_send_now_keyboard(user_id, count=item_count, current_delay=action_data.get("delay_preset", "1-5")))
                return

            # Check if user provided multiple lines separated by Enter (\n)
            lines = [line.strip() for line in text.split("\n") if line.strip()]
            if len(lines) > 1:
                for line in lines:
                    items.append({"media_type": "text", "media_path": None, "caption": line})
                item_count = len(items)
                target_display = target_inbox or "Inbox"
                delay_preset = action_data.get("delay_preset", "1-5") if isinstance(action_data, dict) else "1-5"

                if get_user_lang(user_id) == "bn":
                    txt = (
                        f"✍️ **{len(lines)} টি টেক্সট মেসেজ শনাক্ত হয়েছে!** (Enter দিয়ে আলাদা করা)\n\n"
                        f"🎯 প্রাপক: `{target_display}`\n"
                        f"👥 অ্যাকাউন্ট সংখ্যা: **{target_count} টি** | 📦 মোট মেসেজ: **{item_count} টি**\n\n"
                        f"• প্রতিটি অ্যাকাউন্টের মাঝে বিরতি (Delay) নির্বাচন করুন বা ম্যানুয়ালি সেট করুন।\n"
                        f"• সব প্রস্তুত হলে নিচে **[🚀 এখনই পাঠান]** বাটনে চাপ দিন।"
                    )
                else:
                    txt = (
                        f"✍️ **{len(lines)} text messages detected!** (Separated by Enter)\n\n"
                        f"🎯 Target: `{target_display}`\n"
                        f"👥 Accounts: **{target_count}** | 📦 Total items: **{item_count}**\n\n"
                        f"• Choose or manually set the delay time per account.\n"
                        f"• When ready, click **[🚀 Send Now]** below."
                    )
                await message.reply_text(txt, reply_markup=inbox_send_now_keyboard(user_id, count=item_count, current_delay=delay_preset))
                return

            # If user selected only 1 account and no items yet, send directly!
            if target_count <= 1 and not items:
                user_action_states.pop(user_id, None)
                await execute_inbox_text_delivery(user_id, target_account, text, message, target_inbox=target_inbox)
                return

            items.append({
                "media_type": "text",
                "media_path": None,
                "caption": text
            })
            item_count = len(items)
            target_display = target_inbox or "Inbox"

            if get_user_lang(user_id) == "bn":
                txt = (
                    f"✍️ **টেক্সট মেসেজ #{item_count} গ্রহণ করা হয়েছে!**\n\n"
                    f"🎯 প্রাপক: `{target_display}`\n"
                    f"👥 অ্যাকাউন্ট সংখ্যা: **{target_count} টি** | 📦 সংগৃহীত আইটেম: **{item_count} টি**\n\n"
                    f"• আরও ছবি বা টেক্সট পাঠাতে পারেন (পরবর্তী অ্যাকাউন্টের জন্য)।\n"
                    f"• সব আইটেম প্রস্তুত হলে নিচে **[🚀 এখনই পাঠান]** চাপুন।"
                )
            else:
                txt = (
                    f"✍️ **Text Message #{item_count} received!**\n\n"
                    f"🎯 Target: `{target_display}`\n"
                    f"👥 Accounts: **{target_count}** | 📦 Items: **{item_count}**\n\n"
                    f"• You can send more items for the next accounts.\n"
                    f"• When ready, click **[🚀 Send Now]** below."
                )
            await message.reply_text(txt, reply_markup=inbox_send_now_keyboard(user_id, count=item_count, current_delay=action_data.get("delay_preset", "1-5")))
            return

        # Step 1 of join: Link received
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_JOIN_LINK":
            target = text
            user_accounts = manager.get_user_accounts_list(user_id)
            total = len(user_accounts)

            if total <= 1:
                user_action_states.pop(user_id, None)
                await execute_live_join(user_id, target, message, count=1)
            else:
                user_action_states[user_id] = {"action": "AWAITING_COUNT", "target": target}
                await message.reply_text(
                    tr(user_id, "choose_count", target=target, total=total),
                    reply_markup=count_selection_keyboard(total, user_id)
                )
            return

        # Step 2 of join: User typed custom number of accounts
        if isinstance(action_data, dict) and action_data.get("action") == "AWAITING_COUNT":
            target = action_data.get("target")
            user_action_states.pop(user_id, None)
            count = int(text) if text.isdigit() else None
            await execute_live_join(user_id, target, message, count=count)
            return

        # Handle login state (phone / code / 2fa)
        state = user_login_states.get(user_id)
        if not state:
            return

        step = state.get("step")

        # Step 1: Phone number received
        if step == "AWAITING_PHONE":
            raw_clean = re.sub(r"[^\d+]", "", text).strip()
            if raw_clean.startswith("00"):
                phone_clean = f"+{raw_clean[2:]}"
            elif raw_clean.startswith("01") and len(raw_clean) == 11:
                phone_clean = f"+88{raw_clean}"
            elif not raw_clean.startswith("+"):
                phone_clean = f"+{raw_clean}"
            else:
                phone_clean = raw_clean

            session_name = f"user_{user_id}_{phone_clean.replace('+', '')}"
            status_msg = await message.reply_text("⏳ Connecting to Telegram...")

            temp_client = Client(
                name=session_name,
                api_id=config.API_ID,
                api_hash=config.API_HASH,
                workdir=str(config.SESSIONS_DIR)
            )

            try:
                await temp_client.connect()
                sent_code = await temp_client.send_code(phone_clean)

                # Check if the number is registered on Telegram
                if not getattr(sent_code, "is_phone_registered", True):
                    await status_msg.edit_text(
                        tr(user_id, "phone_not_registered"),
                        reply_markup=main_menu_keyboard(user_id)
                    )
                    _cleanup_user_state(user_id)
                    return

                # Detect delivery destination (App vs SMS vs Call)
                code_type = getattr(sent_code, "type", None)
                dest = "টেলিগ্রাম অ্যাপের নোটিফিকেশনে (Telegram App)" if get_user_lang(user_id) == "bn" else "Telegram App Notification"
                if code_type and "SMS" in str(code_type):
                    dest = "মোবাইল সিমের SMS-এ" if get_user_lang(user_id) == "bn" else "SIM SMS"
                elif code_type and "CALL" in str(code_type):
                    dest = "ফোন কলের মাধ্যমে" if get_user_lang(user_id) == "bn" else "Phone Call"

                state["step"] = "AWAITING_CODE"
                state["client"] = temp_client
                state["session_name"] = session_name
                state["phone"] = phone_clean
                state["phone_code_hash"] = sent_code.phone_code_hash

                await status_msg.edit_text(
                    tr(user_id, "code_sent_dynamic", phone=phone_clean, dest=dest),
                    reply_markup=cancel_keyboard(user_id)
                )
            except FloodWait as e:
                await status_msg.edit_text(f"⚠️ FloodWait: Please wait {e.value} seconds before trying again.")
                _cleanup_user_state(user_id)
            except Exception as e:
                await status_msg.edit_text(f"❌ Error: `{e}`")
                _cleanup_user_state(user_id)

        # Step 2: Login OTP Code received
        elif step == "AWAITING_CODE":
            code_clean = re.sub(r"\D", "", text)
            temp_client: Client = state["client"]
            phone = state["phone"]
            code_hash = state["phone_code_hash"]
            session_name = state["session_name"]

            status_msg = await message.reply_text("⏳ Verifying code...")

            try:
                user = await temp_client.sign_in(phone, code_hash, code_clean)
                await _finalize_login(temp_client, session_name, status_msg, user_id)
            except SessionPasswordNeeded:
                state["step"] = "AWAITING_2FA"
                await status_msg.edit_text(
                    tr(user_id, "two_factor"),
                    reply_markup=cancel_keyboard(user_id)
                )
            except (PhoneCodeInvalid, PhoneCodeExpired):
                await status_msg.edit_text("❌ Code is invalid or expired! Please enter the correct code:")
            except Exception as e:
                await status_msg.edit_text(f"❌ Login error: `{e}`")

        # Step 3: 2FA Password received
        elif step == "AWAITING_2FA":
            temp_client: Client = state["client"]
            session_name = state["session_name"]
            password = text

            status_msg = await message.reply_text("⏳ Verifying 2FA password...")

            try:
                await temp_client.check_password(password)
                await _finalize_login(temp_client, session_name, status_msg, user_id)
            except PasswordHashInvalid:
                await status_msg.edit_text("❌ 2FA password incorrect! Please try again:")
            except Exception as e:
                await status_msg.edit_text(f"❌ Login error: `{e}`")

    async def _finalize_login(temp_client: Client, session_name: str, status_msg: Message, user_id: int):
        """Helper to register and initialize the new logged in account for this owner."""
        try:
            me = await temp_client.get_me()
            from core.session_store import add_account_metadata
            add_account_metadata(
                session_name=session_name,
                user_id=me.id,
                first_name=me.first_name,
                owner_id=user_id,
                phone=me.phone_number or "",
                username=me.username or ""
            )

            # Detach client from temporary login state before cleanup so it won't be disconnected
            if user_id in user_login_states:
                user_login_states[user_id]["client"] = None

            try:
                await temp_client.disconnect()
            except Exception:
                pass

            client = Client(
                name=session_name,
                api_id=config.API_ID,
                api_hash=config.API_HASH,
                workdir=str(config.SESSIONS_DIR)
            )

            from core.call_engine import AccountCallEngine
            engine = AccountCallEngine(client, session_name, owner_id=user_id)
            await engine.start()
            manager.engines[session_name] = engine

            _cleanup_user_state(user_id)

            user_acc_count = len(manager.get_user_accounts_list(user_id))
            await status_msg.edit_text(
                tr(user_id, "login_success", name=me.first_name, id=me.id, phone=me.phone_number, total=user_acc_count),
                reply_markup=main_menu_keyboard(user_id)
            )
        except Exception as e:
            await status_msg.edit_text(f"❌ Error starting account: `{e}`")

    def _cleanup_user_state(user_id: int):
        user_action_states.pop(user_id, None)
        if user_id in user_login_states:
            try:
                c = user_login_states[user_id].get("client")
                # Never disconnect if this client is now an active engine
                is_active = any(e.client == c for e in manager.engines.values())
                if c and not is_active:
                    asyncio.create_task(c.disconnect())
            except Exception:
                pass
            user_login_states.pop(user_id, None)

    # Callback Query handlers for inline buttons
    @bot.on_callback_query()
    async def on_callback(_, query: CallbackQuery):
        data = query.data
        user_id = query.from_user.id

        # Section header buttons — do nothing when clicked
        if data == "noop":
            await query.answer()
            return

        if data == "btn_toggle_lang":
            current_lang = get_user_lang(user_id)
            new_lang = "en" if current_lang == "bn" else "bn"
            set_user_lang(user_id, new_lang)
            await query.answer(tr(user_id, "lang_switched"))

            accounts = manager.get_user_accounts_list(user_id)
            text = (
                f"{tr(user_id, 'start_title')}\n\n"
                f"{tr(user_id, 'welcome', name=query.from_user.first_name)}\n"
                f"{tr(user_id, 'desc')}\n\n"
                f"{tr(user_id, 'acc_count', count=len(accounts))}\n\n"
                f"{tr(user_id, 'commands')}\n\n"
                f"{tr(user_id, 'choose_btn')}"
            )
            await query.message.edit_text(text, reply_markup=main_menu_keyboard(user_id))

        elif data == "btn_accounts":
            await query.answer()
            text, kb = render_accounts_view(user_id)
            try:
                await query.message.edit_text(text, reply_markup=kb)
            except MessageNotModified:
                pass

        elif data == "btn_prompt_manual_remove":
            await query.answer()
            user_action_states[user_id] = {"action": "AWAITING_REMOVE_PHONE"}
            lang = get_user_lang(user_id)
            if lang == "bn":
                msg_text = (
                    "🗑️ **অ্যাকাউন্ট রিমুভ ভেরিফিকেশন:**\n\n"
                    "সুরক্ষা ও নিশ্চিতকরণের স্বার্থে, আপনি যে অ্যাকাউন্টটি তালিকা থেকে মুছে ফেলতে চান তার **সম্পূর্ণ ফোন নম্বরটি কান্ট্রি কোডসহ** লিখে মেসেজ পাঠান:\n\n"
                    "📌 **উদাহরণ:** `+88017XXXXXXXX` বা `+1XXXXXXXXXX`\n\n"
                    "⚠️ *সতর্কতা: প্রতিবার শুধুমাত্র একটি অ্যাকাউন্ট বাদ দেওয়া যাবে।*"
                )
            else:
                msg_text = (
                    "🗑️ **Account Removal Verification:**\n\n"
                    "For security and confirmation, please send the **full phone number (with country code)** of the account you want to remove:\n\n"
                    "📌 **Example:** `+88017XXXXXXXX` or `+1XXXXXXXXXX`\n\n"
                    "⚠️ *Notice: Only one account can be removed at a time.*"
                )
            await query.message.reply_text(msg_text, reply_markup=cancel_keyboard(user_id))

        elif data == "btn_add":
            await query.answer()
            _cleanup_user_state(user_id)
            user_login_states[user_id] = {"step": "AWAITING_PHONE"}
            await query.message.reply_text(
                tr(user_id, "add_phone"),
                reply_markup=cancel_keyboard(user_id)
            )

        elif data == "btn_join_prompt":
            accounts = manager.get_user_accounts_list(user_id)
            if not accounts:
                await query.answer(tr(user_id, "no_accounts"), show_alert=True)
                return
            can_join, remaining_seconds = can_join_live(user_id)
            if not can_join:
                _, contact_url = await get_admin_contact(user_id=user_id)
                text, kb = get_cooldown_message(user_id, remaining_seconds, contact_url)
                await query.answer("⏳ ১০ মিনিটের বিরতি (Cooldown) চলছে!", show_alert=True)
                await query.message.reply_text(text, reply_markup=kb)
                return
            await query.answer()
            user_action_states[user_id] = {"action": "AWAITING_JOIN_LINK"}
            await query.message.reply_text(
                tr(user_id, "join_prompt"),
                reply_markup=cancel_keyboard(user_id)
            )

        elif data.startswith("btn_count_"):
            count = int(data.split("_")[2])
            action_data = user_action_states.pop(user_id, None)
            if isinstance(action_data, dict) and action_data.get("target"):
                target = action_data["target"]
                await query.answer()
                await execute_live_join(user_id, target, query.message, count=count)
            else:
                await query.answer("Session expired or invalid.", show_alert=True)

        elif data == "btn_custom_count_prompt":
            action_data = user_action_states.get(user_id)
            if isinstance(action_data, dict) and action_data.get("target"):
                user_action_states[user_id] = {"action": "AWAITING_COUNT", "target": action_data["target"]}
                await query.answer()
                msg = (
                    "🔢 **কতটি অ্যাকাউন্ট দিয়ে লাইভে জয়েন করতে চান তা লিখে মেসেজ পাঠান:**\n\n"
                    "📌 উদাহরণ: `3` অথবা `8` অথবা `10` লিখে পাঠান।"
                ) if get_user_lang(user_id) == "bn" else (
                    "🔢 **Type how many accounts you want to join with:**\n\n"
                    "📌 Example: Type `3`, `8`, or `10` and send."
                )
                await query.message.reply_text(msg, reply_markup=cancel_keyboard(user_id))
            else:
                await query.answer("Session expired. Please click Join Live Stream again.", show_alert=True)

        elif data == "btn_random_comment":
            user_in_call = [e for e in manager.get_user_engines(user_id).values() if e.in_call]
            if not user_in_call:
                await query.answer(tr(user_id, "no_accounts_in_call"), show_alert=True)
                return
            await query.answer()
            shuffled = RANDOM_COMMENTS.copy()
            random.shuffle(shuffled)
            await execute_comments(user_id, shuffled, query.message)

        elif data == "btn_custom_comment":
            user_in_call = [e for e in manager.get_user_engines(user_id).values() if e.in_call]
            if not user_in_call:
                await query.answer(tr(user_id, "no_accounts_in_call"), show_alert=True)
                return
            await query.answer()
            user_action_states[user_id] = {"action": "AWAITING_CUSTOM_COMMENT"}
            await query.message.reply_text(
                tr(user_id, "custom_comment_prompt"),
                reply_markup=cancel_keyboard(user_id)
            )

        elif data == "btn_ai_comment":
            user_in_call = [e for e in manager.get_user_engines(user_id).values() if e.in_call]
            if not user_in_call:
                await query.answer(tr(user_id, "no_accounts_in_call"), show_alert=True)
                return

            can_use, used, limit = can_use_ai(user_id)
            if not can_use:
                await notify_limit_reached(query, user_id, is_manual=False)
                return

            await query.answer()
            balance = format_ai_balance(user_id)
            user_action_states[user_id] = {"action": "AWAITING_AI_COMMENT_PROMPT"}
            await query.message.reply_text(
                tr(user_id, "ai_comment_prompt", balance=balance),
                reply_markup=cancel_keyboard(user_id)
            )

        elif data == "btn_attachment_comment":
            user_in_call = [e for e in manager.get_user_engines(user_id).values() if e.in_call]
            if not user_in_call:
                await query.answer(tr(user_id, "no_accounts_in_call"), show_alert=True)
                return

            can_use, used, limit = can_use_manual(user_id)
            if not can_use:
                await notify_limit_reached(query, user_id, is_manual=True)
                return

            await query.answer()
            balance = format_manual_balance(user_id)
            user_action_states[user_id] = {"action": "AWAITING_ATTACHMENT_COMMENT"}
            await query.message.reply_text(
                tr(user_id, "attachment_comment_prompt", balance=balance),
                reply_markup=cancel_keyboard(user_id)
            )

        elif data.startswith("btn_sendatt_"):
            target_account = data.replace("btn_sendatt_", "")
            action_data = user_action_states.pop(user_id, None)

            if not isinstance(action_data, dict) or action_data.get("action") != "AWAITING_ATTACHMENT_ACCOUNT_CHOICE":
                await query.answer("Session expired or invalid.", show_alert=True)
                return

            media_path = action_data.get("media_path")
            caption = action_data.get("caption", "")
            media_type = action_data.get("media_type", "text")

            user_in_call = [e for e in manager.get_user_engines(user_id).values() if e.in_call]
            if not user_in_call:
                if media_path:
                    try:
                        from pathlib import Path
                        Path(media_path).unlink(missing_ok=True)
                    except Exception:
                        pass
                await query.answer(tr(user_id, "no_accounts_in_call"), show_alert=True)
                return

            if not is_vip(user_id):
                remaining = get_remaining_manual_balance(user_id)
                if remaining <= 0:
                    if media_path:
                        try:
                            from pathlib import Path
                            Path(media_path).unlink(missing_ok=True)
                        except Exception:
                            pass
                    await notify_limit_reached(query, user_id, is_manual=True)
                    return

            await query.answer()
            status_msg = await query.message.reply_text(tr(user_id, "attachment_starting"))

            async def update_att_progress(current, total, success, failed):
                try:
                    await status_msg.edit_text(
                        f"📎 **Sending {media_type}...**\nProgress: **{current}/{total}**\n✅ Sent: **{success}** | ❌ Failed: **{failed}**"
                    )
                except Exception:
                    pass

            try:
                if target_account == "ALL":
                    max_count = None
                    if not is_vip(user_id):
                        max_count = min(len(user_in_call), get_remaining_manual_balance(user_id))
                    res = await manager.send_attachment_for_user(
                        owner_id=user_id,
                        media_path=media_path,
                        caption=caption,
                        media_type=media_type,
                        count=max_count,
                        progress_callback=update_att_progress
                    )
                else:
                    engine = manager.get_user_engines(user_id).get(target_account)
                    if not engine or not engine.in_call:
                        await status_msg.edit_text("❌ Selected account is not in live.", reply_markup=main_menu_keyboard(user_id))
                        return

                    single_res = await engine.send_attachment_comment(media_path=media_path, caption=caption, media_type=media_type)
                    if single_res.get("success"):
                        res = {"total": 1, "success": 1, "failed": 0, "details": [f"📎 {engine.account_id}: Sent {media_type}"]}
                    else:
                        res = {"total": 1, "success": 0, "failed": 1, "details": [f"❌ {engine.account_id}: {single_res.get('error')}"]}
            finally:
                if media_path:
                    try:
                        from pathlib import Path
                        Path(media_path).unlink(missing_ok=True)
                    except Exception:
                        pass

            # Record manual usage based on successful sends
            if not is_vip(user_id) and res.get("success", 0) > 0:
                record_manual_usage(user_id, count=res["success"])

            details_preview = "\n".join(res["details"][:10])
            balance_note = f"\n\n📊 আজকের বাকি ম্যানুয়াল ব্যালেন্স: {format_manual_balance(user_id)}" if get_user_lang(user_id) == "bn" else f"\n\n📊 Remaining Manual Balance: {format_manual_balance(user_id)}"
            await status_msg.edit_text(
                tr(user_id, "attachment_completed", total=res["total"], success=res["success"], details=details_preview) + balance_note,
                reply_markup=main_menu_keyboard(user_id)
            )

        elif data == "btn_send_to_me":
            accounts = manager.get_user_accounts_list(user_id)
            if not accounts:
                await query.answer(tr(user_id, "no_accounts"), show_alert=True)
                return
            await query.answer()
            await query.message.reply_text(
                tr(user_id, "inbox_select_account"),
                reply_markup=inbox_account_selector_keyboard(accounts, user_id)
            )

        elif data.startswith("btn_inbox_acc_"):
            target_account = data.replace("btn_inbox_acc_", "")
            await query.answer()
            user_action_states[user_id] = {
                "action": "AWAITING_INBOX_TARGET",
                "target_account": target_account
            }
            await query.message.reply_text(
                tr(user_id, "inbox_target_prompt"),
                reply_markup=inbox_target_keyboard(user_id)
            )

        elif data == "btn_inbox_target_self":
            action_data = user_action_states.get(user_id)
            if not isinstance(action_data, dict):
                action_data = {"target_account": "ALL"}
                user_action_states[user_id] = action_data
            action_data["action"] = "AWAITING_INBOX_CONTENT"
            action_data["target_inbox"] = "me"
            await query.answer()
            self_lbl = "My Own Inbox (নিজের ইনবক্স)" if get_user_lang(user_id) == "bn" else "My Own Inbox"
            await query.message.reply_text(
                tr(user_id, "inbox_prompt", target=self_lbl),
                reply_markup=cancel_keyboard(user_id)
            )

        elif data == "btn_delay_custom_prompt":
            action_data = user_action_states.get(user_id)
            if not isinstance(action_data, dict):
                await query.answer("Session expired.", show_alert=True)
                return
            await query.answer()
            action_data["previous_action"] = action_data.get("action", "AWAITING_INBOX_CONTENT")
            action_data["action"] = "AWAITING_CUSTOM_DELAY"

            if get_user_lang(user_id) == "bn":
                msg = (
                    "⏱️ **প্রতিটি অ্যাকাউন্টের মেসেজিং বিরতি (Delay) ম্যানুয়ালি কত সেকেন্ড রাখতে চান?**\n\n"
                    "আপনি যে কোনো সময় সেকেন্ড হিসেবে লিখে পাঠাতে পারেন:\n"
                    "• **নির্দিষ্ট সময়:** যেমন `3` বা `5` বা `10` লিখে পাঠান\n"
                    "• **র‍্যান্ডম বিরতি:** যেমন `2-5` বা `3-8` লিখে পাঠান\n\n"
                    "✍️ *কাঙ্ক্ষিত সেকেন্ড সংখ্যাটি এখনই লিখে মেসেজ সেন্ড করুন:*"
                )
            else:
                msg = (
                    "⏱️ **Set manual messaging delay per account (in seconds):**\n\n"
                    "You can enter any duration:\n"
                    "• **Exact seconds:** e.g. `3` or `5` or `10`\n"
                    "• **Random range:** e.g. `2-5` or `3-8`\n\n"
                    "✍️ *Type the number of seconds and send now:*"
                )
            await query.message.reply_text(msg, reply_markup=cancel_keyboard(user_id))

        elif data.startswith("btn_delay_"):
            new_delay = data.replace("btn_delay_", "")
            action_data = user_action_states.get(user_id)
            if not isinstance(action_data, dict):
                await query.answer("Session expired.", show_alert=True)
                return
            action_data["delay_preset"] = new_delay
            await query.answer(f"⏱️ বিরতি সেট: {new_delay} সেকেন্ড" if get_user_lang(user_id) == "bn" else f"⏱️ Delay set: {new_delay}s")
            count = len(action_data.get("items", []))
            try:
                await query.message.edit_reply_markup(
                    reply_markup=inbox_send_now_keyboard(user_id, count=count, current_delay=new_delay)
                )
            except Exception:
                pass

        elif data == "btn_inbox_send_now":
            action_data = user_action_states.pop(user_id, None)
            if not isinstance(action_data, dict):
                await query.answer("❌ কোনো সক্রিয় সেশন পাওয়া যায়নি!", show_alert=True)
                return
            await query.answer()
            items = action_data.get("items", [])
            if not items:
                await query.message.reply_text("❌ পাঠানোর জন্য কোনো ছবি বা টেক্সট পাওয়া যায়নি।", reply_markup=main_menu_keyboard(user_id))
                return

            target_account = action_data.get("target_account", "ALL")
            target_inbox = action_data.get("target_inbox")
            status_msg = await query.message.reply_text(tr(user_id, "inbox_sending"))
            username = query.from_user.username if query.from_user else None

            delay_preset = action_data.get("delay_preset", "1-5")
            if delay_preset == "1-3":
                min_d, max_d = 1.0, 3.0
            elif delay_preset == "3-7":
                min_d, max_d = 3.0, 7.0
            elif delay_preset == "5-10":
                min_d, max_d = 5.0, 10.0
            elif delay_preset == "1-5":
                min_d, max_d = 1.0, 5.0
            elif "custom_min_delay" in action_data and "custom_max_delay" in action_data:
                min_d = float(action_data["custom_min_delay"])
                max_d = float(action_data["custom_max_delay"])
            elif "-" in str(delay_preset):
                try:
                    parts = str(delay_preset).split("-", 1)
                    min_d, max_d = float(parts[0]), float(parts[1])
                except Exception:
                    min_d, max_d = 1.0, 5.0
            else:
                try:
                    val = float(str(delay_preset).replace("s", ""))
                    min_d, max_d = val, val
                except Exception:
                    min_d, max_d = 1.0, 5.0

            res = await manager.send_to_inbox_for_user(
                owner_id=user_id,
                chosen_acc=target_account,
                target_inbox=target_inbox,
                owner_username=username,
                items=items,
                min_delay=min_d,
                max_delay=max_d
            )
            details_preview = "\n".join(res.get("details", [])[:10])
            target_display = target_inbox or "Inbox"
            await status_msg.edit_text(
                tr(user_id, "inbox_completed", target=target_display, total=res["total"], success=res["success"], details=details_preview),
                reply_markup=main_menu_keyboard(user_id)
            )

        elif data == "btn_poll_vote_prompt":
            accounts = manager.get_user_accounts_list(user_id)
            if not accounts:
                await query.answer(tr(user_id, "no_accounts"), show_alert=True)
                return
            await query.answer()
            user_action_states[user_id] = {"action": "AWAITING_POLL_LINK"}
            if get_user_lang(user_id) == "bn":
                msg = (
                    "🗳️ **টেলিগ্রাম পোল বা ভোটের লিংক দিন:**\n\n"
                    "যে চ্যানেলে বা পাবলিক গ্রুপে পোল রয়েছে তার মেসেজ লিংকটি পাঠিয়ে দিন।\n\n"
                    "📌 **উদাহরণ:**\n`https://t.me/channel_name/123`"
                )
            else:
                msg = (
                    "🗳️ **Send Telegram Poll Link:**\n\n"
                    "Please send the message link containing the poll:\n\n"
                    "📌 **Example:**\n`https://t.me/channel_name/123`"
                )
            await query.message.reply_text(msg, reply_markup=cancel_keyboard(user_id))

        elif data.startswith("btn_poll_opt_"):
            opt_idx = int(data.replace("btn_poll_opt_", ""))
            action_data = user_action_states.get(user_id)
            if not isinstance(action_data, dict) or "chat_id" not in action_data:
                await query.answer("Session expired.", show_alert=True)
                return
            await query.answer()
            action_data["option_idx"] = opt_idx
            user_accounts = manager.get_user_accounts_list(user_id)

            if len(user_accounts) <= 1:
                can_p, allowed_cnt, used_p, lim_p = can_use_poll_vote(user_id, 1)
                if not can_p:
                    user_action_states.pop(user_id, None)
                    _, contact_url = await get_admin_contact(user_id=user_id)
                    kb = InlineKeyboardMarkup([[InlineKeyboardButton("💎 VIP মেম্বারশিপ নিন", url=contact_url)]]) if contact_url else main_menu_keyboard(user_id)
                    err_msg = (
                        f"❌ **আপনার আজকের ফ্রি পোল ভোট লিমিট (৫টি অ্যাকাউন্ট) শেষ হয়ে গেছে!**\n\n"
                        f"📊 ব্যবহৃত: **{used_p}/{lim_p}** টি অ্যাকাউন্ট\n"
                        f"💡 প্রতিদিন ফ্রিতে সর্বোচ্চ ৫টি অ্যাকাউন্ট দিয়ে ভোট দেওয়া যায়। আনলিমিটেড ভোটের জন্য VIP মেম্বারশিপে আপগ্রেড করুন।"
                    ) if get_user_lang(user_id) == "bn" else (
                        f"❌ **Your free daily poll vote limit (5 accounts) is reached!**\n\n"
                        f"📊 Used: **{used_p}/{lim_p}** accounts\n"
                        f"💡 Free tier allows up to 5 accounts daily. Upgrade to VIP for unlimited votes."
                    )
                    await query.message.reply_text(err_msg, reply_markup=kb)
                    return

                user_action_states.pop(user_id, None)
                chat_id = action_data["chat_id"]
                message_id = action_data["message_id"]
                status_msg = await query.message.reply_text("⏳ ভোট দেওয়া হচ্ছে..." if get_user_lang(user_id) == "bn" else "⏳ Casting vote...")
                res = await manager.vote_poll_for_user(user_id, chosen_acc="ALL", chat_id=chat_id, message_id=message_id, option_idx=opt_idx)
                if not is_vip(user_id) and res.get("success", 0) > 0:
                    record_poll_usage(user_id, res["success"])
                details = "\n".join(res.get("details", [])[:10])
                txt = f"🗳️ **পোল ভোটিং সম্পন্ন!**\n\n✅ সফল: **{res['success']}/{res['total']}** টি অ্যাকাউন্ট\n\n{details}" if get_user_lang(user_id) == "bn" else f"🗳️ **Poll Voting Completed!**\n\n✅ Successful: **{res['success']}/{res['total']}** accounts\n\n{details}"
                await status_msg.edit_text(txt, reply_markup=main_menu_keyboard(user_id))
                return

            action_data["action"] = "AWAITING_POLL_ACC_SELECT"
            rem_p = get_remaining_poll_balance(user_id)
            quota_note = "" if is_vip(user_id) else (f"\n(💡 ফ্রি কোটা: আজ **{rem_p}/{FREE_DAILY_POLL_ACCOUNT_LIMIT}** টি অ্যাকাউন্ট বাকি)" if get_user_lang(user_id) == "bn" else f"\n(💡 Free quota: **{rem_p}/{FREE_DAILY_POLL_ACCOUNT_LIMIT}** accounts left today)")
            if get_user_lang(user_id) == "bn":
                msg = f"👥 **কোন অ্যাকাউন্ট দিয়ে অপশন #{opt_idx + 1}-এ ভোট দিতে চান?**{quota_note}\n\nসবগুলো বা নির্দিষ্ট অ্যাকাউন্ট বেছে নিন:"
            else:
                msg = f"👥 **Which accounts should vote for option #{opt_idx + 1}?**{quota_note}\n\nSelect all or choose specific accounts:"
            await query.message.edit_text(msg, reply_markup=generic_account_selector_keyboard(user_accounts, user_id, "btn_pollacc"))

        elif data.startswith("btn_pollacc_"):
            target_acc = data.replace("btn_pollacc_", "")
            action_data = user_action_states.pop(user_id, None)
            if not isinstance(action_data, dict) or "chat_id" not in action_data or "option_idx" not in action_data:
                await query.answer("Session expired.", show_alert=True)
                return
            await query.answer()
            chat_id = action_data["chat_id"]
            message_id = action_data["message_id"]
            opt_idx = action_data["option_idx"]

            user_accounts = manager.get_user_accounts_list(user_id)
            if target_acc == "ALL":
                req_count = len(user_accounts)
            elif target_acc.isdigit():
                req_count = int(target_acc)
            else:
                req_count = 1

            can_p, allowed_cnt, used_p, lim_p = can_use_poll_vote(user_id, req_count)
            if not can_p:
                _, contact_url = await get_admin_contact(user_id=user_id)
                kb = InlineKeyboardMarkup([[InlineKeyboardButton("💎 VIP মেম্বারশিপ নিন", url=contact_url)]]) if contact_url else main_menu_keyboard(user_id)
                err_msg = (
                    f"❌ **আপনার আজকের ফ্রি পোল ভোট লিমিট (৫টি অ্যাকাউন্ট) শেষ হয়ে গেছে!**\n\n"
                    f"📊 ব্যবহৃত: **{used_p}/{lim_p}** টি অ্যাকাউন্ট\n"
                    f"💡 প্রতিদিন ফ্রিতে সর্বোচ্চ ৫টি অ্যাকাউন্ট দিয়ে ভোট দেওয়া যায়। আনলিমিটেড ভোটের জন্য VIP মেম্বারশিপে আপগ্রেড করুন।"
                ) if get_user_lang(user_id) == "bn" else (
                    f"❌ **Your free daily poll vote limit (5 accounts) is reached!**\n\n"
                    f"📊 Used: **{used_p}/{lim_p}** accounts\n"
                    f"💡 Free tier allows up to 5 accounts daily. Upgrade to VIP for unlimited votes."
                )
                await query.message.reply_text(err_msg, reply_markup=kb)
                return

            limit_notice = ""
            if not is_vip(user_id) and allowed_cnt < req_count:
                target_acc = str(allowed_cnt)
                limit_notice = (
                    f"\n\nℹ️ *ফ্রি ইউজার হিসেবে আজ আর {allowed_cnt}টি অ্যাকাউন্টের কোটা বাকি আছে। তাই {allowed_cnt}টি অ্যাকাউন্ট দিয়ে ভোট প্রদান করা হলো।*"
                    if get_user_lang(user_id) == "bn" else
                    f"\n\nℹ️ *As a free user, only {allowed_cnt} account quota remained today. Voting with {allowed_cnt} accounts.*"
                )

            status_msg = await query.message.reply_text("⏳ নির্বাচিত অ্যাকাউন্ট থেকে ভোট দেওয়া হচ্ছে..." if get_user_lang(user_id) == "bn" else "⏳ Casting votes from selected accounts...")
            res = await manager.vote_poll_for_user(user_id, chosen_acc=target_acc, chat_id=chat_id, message_id=message_id, option_idx=opt_idx)
            if not is_vip(user_id) and res.get("success", 0) > 0:
                record_poll_usage(user_id, res["success"])
            details = "\n".join(res.get("details", [])[:10])

            if get_user_lang(user_id) == "bn":
                txt = (
                    f"🗳️ **পোল ভোটিং সম্পন্ন!**\n\n"
                    f"✅ সফল: **{res['success']}/{res['total']}** টি অ্যাকাউন্ট\n\n"
                    f"{details}{limit_notice}"
                )
            else:
                txt = (
                    f"🗳️ **Poll Voting Completed!**\n\n"
                    f"✅ Successful: **{res['success']}/{res['total']}** accounts\n\n"
                    f"{details}{limit_notice}"
                )
            await status_msg.edit_text(txt, reply_markup=main_menu_keyboard(user_id))

        elif data.startswith("btn_viewacc_"):
            target_acc = data.replace("btn_viewacc_", "")
            action_data = user_action_states.pop(user_id, None)
            if not isinstance(action_data, dict) or "chat_id" not in action_data:
                await query.answer("Session expired.", show_alert=True)
                return
            await query.answer()
            chat_id = action_data["chat_id"]
            message_id = action_data["message_id"]

            user_accounts = manager.get_user_accounts_list(user_id)
            if target_acc == "ALL":
                req_count = len(user_accounts)
            elif target_acc.isdigit():
                req_count = int(target_acc)
            else:
                req_count = 1

            can_eng, allowed_cnt, used_e, lim_e = can_use_post_engage(user_id, req_count)
            if not can_eng:
                _, contact_url = await get_admin_contact(user_id=user_id)
                kb = InlineKeyboardMarkup([[InlineKeyboardButton("💎 VIP মেম্বারশিপ নিন", url=contact_url)]]) if contact_url else main_menu_keyboard(user_id)
                err_msg = (
                    f"❌ **আপনার আজকের ফ্রি পোস্ট ভিউ লিমিট (৫টি অ্যাকাউন্ট) শেষ হয়ে গেছে!**\n\n"
                    f"📊 ব্যবহৃত: **{used_e}/{lim_e}** টি অ্যাকাউন্ট\n"
                    f"💡 প্রতিদিন ফ্রিতে সর্বোচ্চ ৫টি অ্যাকাউন্ট দিয়ে ভিউ বাড়ানো যায়। আনলিমিটেড সুবিধার জন্য VIP মেম্বারশিপে আপগ্রেড করুন।"
                ) if get_user_lang(user_id) == "bn" else (
                    f"❌ **Your free daily post view limit (5 accounts) is reached!**\n\n"
                    f"📊 Used: **{used_e}/{lim_e}** accounts\n"
                    f"💡 Free tier allows up to 5 accounts daily. Upgrade to VIP for unlimited views."
                )
                await query.message.reply_text(err_msg, reply_markup=kb)
                return

            limit_notice = ""
            if not is_vip(user_id) and allowed_cnt < req_count:
                target_acc = str(allowed_cnt)
                limit_notice = (
                    f"\n\nℹ️ *ফ্রি ইউজার হিসেবে আজ আর {allowed_cnt}টি অ্যাকাউন্টের কোটা বাকি আছে। তাই {allowed_cnt}টি অ্যাকাউন্ট ব্যবহার করা হলো।*"
                    if get_user_lang(user_id) == "bn" else
                    f"\n\nℹ️ *As a free user, only {allowed_cnt} account quota remained today. Boosting views with {allowed_cnt} accounts.*"
                )

            status_msg = await query.message.reply_text("👁️ নির্বাচিত অ্যাকাউন্ট দিয়ে ভিউ বাড়ানো হচ্ছে..." if get_user_lang(user_id) == "bn" else "👁️ Boosting post views across selected accounts...")
            res = await manager.react_and_view_post_for_user(user_id, chosen_acc=target_acc, chat_id=chat_id, message_id=message_id, do_view=True, do_react=False)
            if not is_vip(user_id) and res.get("success", 0) > 0:
                record_engage_usage(user_id, res["success"])
            details = "\n".join(res.get("details", [])[:10])
            txt = f"👁️ **পোস্ট ভিউ সম্পন্ন!**\n\n✅ সফল: **{res['success']}/{res['total']}** টি অ্যাকাউন্ট\n\n{details}{limit_notice}" if get_user_lang(user_id) == "bn" else f"👁️ **Post Views Completed!**\n\n✅ Successful: **{res['success']}/{res['total']}** accounts\n\n{details}{limit_notice}"
            await status_msg.edit_text(txt, reply_markup=main_menu_keyboard(user_id))

        elif data == "btn_post_engage_prompt":
            accounts = manager.get_user_accounts_list(user_id)
            if not accounts:
                await query.answer(tr(user_id, "no_accounts"), show_alert=True)
                return
            await query.answer()
            if get_user_lang(user_id) == "bn":
                msg = "👁️ **পোস্ট ভিউ ও রিঅ্যাকশন প্যানেল:**\n\nআপনি কী করতে চান নির্বাচন করুন:"
            else:
                msg = "👁️ **Post Views & Reactions:**\n\nSelect what you want to do:"
            await query.message.reply_text(msg, reply_markup=post_engage_mode_keyboard(user_id))

        elif data.startswith("btn_engage_mode_"):
            mode = data.replace("btn_engage_mode_", "")
            await query.answer()
            user_action_states[user_id] = {"action": "AWAITING_POST_ENGAGE_LINK", "engage_mode": mode}
            mode_names = {"views": "ভিউ (Views)", "react": "রিঅ্যাকশন (Reactions)", "both": "ভিউ + রিঅ্যাকশন (Views + Reactions)"}
            mode_str = mode_names.get(mode, mode)
            if get_user_lang(user_id) == "bn":
                msg = (
                    f"🎯 **নির্বাচিত মোড:** `{mode_str}`\n\n"
                    f"🔗 **পোস্টের লিংক পাঠান:**\n"
                    f"যে টেলিগ্রাম পোস্টটিতে প্রয়োগ করতে চান তার লিংকটি দিন:\n\n"
                    f"📌 **উদাহরণ:**\n`https://t.me/channel_name/123`"
                )
            else:
                msg = (
                    f"🎯 **Selected Mode:** `{mode}`\n\n"
                    f"🔗 **Send Post Link:**\n"
                    f"Send the Telegram post link you want to engage:\n\n"
                    f"📌 **Example:**\n`https://t.me/channel_name/123`"
                )
            await query.message.reply_text(msg, reply_markup=cancel_keyboard(user_id))

        elif data.startswith("btn_react_emoji_"):
            emoji = data.replace("btn_react_emoji_", "")
            action_data = user_action_states.get(user_id)
            if not isinstance(action_data, dict) or "chat_id" not in action_data:
                await query.answer("Session expired.", show_alert=True)
                return
            await query.answer()
            action_data["chosen_emoji"] = emoji
            user_accounts = manager.get_user_accounts_list(user_id)

            if len(user_accounts) <= 1:
                can_eng, allowed_cnt, used_e, lim_e = can_use_post_engage(user_id, 1)
                if not can_eng:
                    user_action_states.pop(user_id, None)
                    _, contact_url = await get_admin_contact(user_id=user_id)
                    kb = InlineKeyboardMarkup([[InlineKeyboardButton("💎 VIP মেম্বারশিপ নিন", url=contact_url)]]) if contact_url else main_menu_keyboard(user_id)
                    err_msg = (
                        f"❌ **আপনার আজকের ফ্রি ভিউ ও রিঅ্যাকশন লিমিট (৫টি অ্যাকাউন্ট) শেষ হয়ে গেছে!**\n\n"
                        f"📊 ব্যবহৃত: **{used_e}/{lim_e}** টি অ্যাকাউন্ট\n"
                        f"💡 প্রতিদিন ফ্রিতে সর্বোচ্চ ৫টি অ্যাকাউন্ট দিয়ে রিঅ্যাকশন দেওয়া যায়। আনলিমিটেড ফিচারের জন্য VIP মেম্বারশিপে আপগ্রেড করুন।"
                    ) if get_user_lang(user_id) == "bn" else (
                        f"❌ **Your free daily views & reactions limit (5 accounts) is reached!**\n\n"
                        f"📊 Used: **{used_e}/{lim_e}** accounts\n"
                        f"💡 Free tier allows up to 5 accounts daily. Upgrade to VIP for unlimited reactions."
                    )
                    await query.message.reply_text(err_msg, reply_markup=kb)
                    return

                user_action_states.pop(user_id, None)
                chat_id = action_data["chat_id"]
                message_id = action_data["message_id"]
                engage_mode = action_data.get("engage_mode", "both")
                do_view = engage_mode in ("views", "both")
                do_react = engage_mode in ("react", "both")
                status_msg = await query.message.reply_text("🚀 প্রক্রিয়া শুরু হচ্ছে..." if get_user_lang(user_id) == "bn" else "🚀 Processing across accounts...")
                res = await manager.react_and_view_post_for_user(user_id, chosen_acc="ALL", chat_id=chat_id, message_id=message_id, emoji=emoji, do_view=do_view, do_react=do_react)
                if not is_vip(user_id) and res.get("success", 0) > 0:
                    record_engage_usage(user_id, res["success"])
                details = "\n".join(res.get("details", [])[:10])
                txt = f"🚀 **পোস্ট এনগেজমেন্ট সম্পন্ন!**\n\n✅ সফল: **{res['success']}/{res['total']}** টি অ্যাকাউন্ট\n\n{details}" if get_user_lang(user_id) == "bn" else f"🚀 **Post Engagement Completed!**\n\n✅ Successful: **{res['success']}/{res['total']}** accounts\n\n{details}"
                await status_msg.edit_text(txt, reply_markup=main_menu_keyboard(user_id))
                return

            action_data["action"] = "AWAITING_REACT_ACC_SELECT"
            rem_e = get_remaining_engage_balance(user_id)
            quota_note = "" if is_vip(user_id) else (f"\n(💡 ফ্রি কোটা: আজ **{rem_e}/{FREE_DAILY_ENGAGE_ACCOUNT_LIMIT}** টি অ্যাকাউন্ট বাকি)" if get_user_lang(user_id) == "bn" else f"\n(💡 Free quota: **{rem_e}/{FREE_DAILY_ENGAGE_ACCOUNT_LIMIT}** accounts left today)")
            if get_user_lang(user_id) == "bn":
                msg = f"👥 **কোন অ্যাকাউন্টগুলো দিয়ে রিঅ্যাকশন / ভিউ দিতে চান?**{quota_note}\n\nসবগুলো বা নির্দিষ্ট অ্যাকাউন্ট বেছে নিন:"
            else:
                msg = f"👥 **Which accounts should react/view?**{quota_note}\n\nSelect all or choose specific accounts:"
            await query.message.edit_text(msg, reply_markup=generic_account_selector_keyboard(user_accounts, user_id, "btn_reactacc"))

        elif data.startswith("btn_reactacc_"):
            target_acc = data.replace("btn_reactacc_", "")
            action_data = user_action_states.pop(user_id, None)
            if not isinstance(action_data, dict) or "chat_id" not in action_data:
                await query.answer("Session expired.", show_alert=True)
                return
            await query.answer()
            chat_id = action_data["chat_id"]
            message_id = action_data["message_id"]
            emoji = action_data.get("chosen_emoji", "RANDOM")
            engage_mode = action_data.get("engage_mode", "both")
            do_view = engage_mode in ("views", "both")
            do_react = engage_mode in ("react", "both")

            user_accounts = manager.get_user_accounts_list(user_id)
            if target_acc == "ALL":
                req_count = len(user_accounts)
            elif target_acc.isdigit():
                req_count = int(target_acc)
            else:
                req_count = 1

            can_eng, allowed_cnt, used_e, lim_e = can_use_post_engage(user_id, req_count)
            if not can_eng:
                _, contact_url = await get_admin_contact(user_id=user_id)
                kb = InlineKeyboardMarkup([[InlineKeyboardButton("💎 VIP মেম্বারশিপ নিন", url=contact_url)]]) if contact_url else main_menu_keyboard(user_id)
                err_msg = (
                    f"❌ **আপনার আজকের ফ্রি ভিউ ও রিঅ্যাকশন লিমিট (৫টি অ্যাকাউন্ট) শেষ হয়ে গেছে!**\n\n"
                    f"📊 ব্যবহৃত: **{used_e}/{lim_e}** টি অ্যাকাউন্ট\n"
                    f"💡 প্রতিদিন ফ্রিতে সর্বোচ্চ ৫টি অ্যাকাউন্ট দিয়ে রিঅ্যাকশন দেওয়া যায়। আনলিমিটেড ফিচারের জন্য VIP মেম্বারশিপে আপগ্রেড করুন।"
                ) if get_user_lang(user_id) == "bn" else (
                    f"❌ **Your free daily views & reactions limit (5 accounts) is reached!**\n\n"
                    f"📊 Used: **{used_e}/{lim_e}** accounts\n"
                    f"💡 Free tier allows up to 5 accounts daily. Upgrade to VIP for unlimited reactions."
                )
                await query.message.reply_text(err_msg, reply_markup=kb)
                return

            limit_notice = ""
            if not is_vip(user_id) and allowed_cnt < req_count:
                target_acc = str(allowed_cnt)
                limit_notice = (
                    f"\n\nℹ️ *ফ্রি ইউজার হিসেবে আজ আর {allowed_cnt}টি অ্যাকাউন্টের কোটা বাকি আছে। তাই {allowed_cnt}টি অ্যাকাউন্ট ব্যবহার করা হলো।*"
                    if get_user_lang(user_id) == "bn" else
                    f"\n\nℹ️ *As a free user, only {allowed_cnt} account quota remained today. Operating with {allowed_cnt} accounts.*"
                )

            status_msg = await query.message.reply_text("🚀 নির্বাচিত অ্যাকাউন্ট থেকে প্রক্রিয়া শুরু হচ্ছে..." if get_user_lang(user_id) == "bn" else "🚀 Processing from selected accounts...")
            res = await manager.react_and_view_post_for_user(user_id, chosen_acc=target_acc, chat_id=chat_id, message_id=message_id, emoji=emoji, do_view=do_view, do_react=do_react)
            if not is_vip(user_id) and res.get("success", 0) > 0:
                record_engage_usage(user_id, res["success"])
            details = "\n".join(res.get("details", [])[:10])

            if get_user_lang(user_id) == "bn":
                txt = (
                    f"🚀 **পোস্ট এনগেজমেন্ট সম্পন্ন!**\n\n"
                    f"✅ সফল: **{res['success']}/{res['total']}** টি অ্যাকাউন্ট\n\n"
                    f"{details}{limit_notice}"
                )
            else:
                txt = (
                    f"🚀 **Post Engagement Completed!**\n\n"
                    f"✅ Successful: **{res['success']}/{res['total']}** accounts\n\n"
                    f"{details}{limit_notice}"
                )
        # Auto Live Join Callbacks
        elif data == "btn_auto_live_menu":
            await query.answer()
            targets = get_user_live_targets(user_id)
            active_cnt = sum(1 for t in targets if t.get("is_active", True))
            live_cnt = sum(1 for t in targets if t.get("is_currently_live"))
            total_joins = sum(t.get("total_auto_joins", 0) for t in targets)

            if get_user_lang(user_id) == "bn":
                txt = (
                    "🔴 **অটো লাইভ জয়েন কন্ট্রোল প্যানেল (Auto Live Join):**\n\n"
                    "এখানে আপনার কাঙ্ক্ষিত চ্যানেল বা গ্রুপের লিংক/ইউজারনেম সেট করে রাখুন। "
                    "যখনই তারা টেলিগ্রামে লাইভ স্ট্রিম বা ভয়েস চ্যাট শুরু করবে, **আপনার অ্যাকাউন্টগুলো স্বয়ংক্রিয়ভাবে লাইভে জয়েন হয়ে যাবে!**\n\n"
                    f"📋 মোট টার্গেট: **{len(targets)} টি**\n"
                    f"🟢 সক্রিয় মনিটরিং: **{active_cnt} টি**\n"
                    f"🔴 বর্তমানে লাইভ চলছে: **{live_cnt} টি**\n"
                    f"⚡ মোট স্বয়ংক্রিয় জয়েন সম্পন্ন: **{total_joins} বার**\n\n"
                    "👉 নতুন চ্যানেল যোগ করতে বা বর্তমান টার্গেটগুলো দেখতে নিচের বাটন ব্যবহার করুন:"
                )
            else:
                txt = (
                    "🔴 **Auto Live Join Control Panel:**\n\n"
                    "Add your target channel or group links here. "
                    "Whenever they start a live stream or voice chat, **your accounts will automatically join the live!**\n\n"
                    f"📋 Total Targets: **{len(targets)}**\n"
                    f"🟢 Active Monitoring: **{active_cnt}**\n"
                    f"🔴 Currently Live: **{live_cnt}**\n"
                    f"⚡ Total Auto Joins: **{total_joins} times**\n\n"
                    "👉 Use the buttons below to manage your targets:"
                )
            await query.message.edit_text(txt, reply_markup=auto_live_menu_keyboard(user_id, len(targets)))

        elif data == "auto_live_add":
            accounts = manager.get_user_accounts_list(user_id)
            if not accounts:
                await query.answer(tr(user_id, "no_accounts"), show_alert=True)
                return
            await query.answer()
            user_action_states[user_id] = {"action": "AWAITING_AUTO_LIVE_TARGET"}
            if get_user_lang(user_id) == "bn":
                msg = (
                    "🔴 **টার্গেট চ্যানেল বা গ্রুপের লিংক/ইউজারনেম পাঠান:**\n\n"
                    "যে চ্যানেল বা গ্রুপে লাইভ শুরু হওয়ার সাথে সাথে অটো জয়েন হতে চান, তার লিংক বা ইউজারনেম দিন:\n\n"
                    "📌 **ফরম্যাট উদাহরণ:**\n"
                    "• ইউজারনেম: `@mychannel` বা `@mygroup`\n"
                    "• পাবলিক লিংক: `https://t.me/mychannel`\n"
                    "• প্রাইভেট লিংক: `https://t.me/+AbCdEfGhIjKlMnOp`\n\n"
                    "💡 *একসাথে একাধিক লিংক দিতে চাইলে প্রতি লাইনে একটি করে লিংক লিখে এক মেসেজেই পাঠিয়ে দিতে পারেন!*\n"
                    "বাতিল করতে `/cancel` লিখুন।"
                )
            else:
                msg = (
                    "🔴 **Send Target Channel or Group Link / Username:**\n\n"
                    "Send the link or username of the channel/group to auto-join whenever it goes live:\n\n"
                    "📌 **Examples:**\n"
                    "• Username: `@mychannel` or `@mygroup`\n"
                    "• Public Link: `https://t.me/mychannel`\n"
                    "• Private Link: `https://t.me/+AbCdEfGhIjKlMnOp`\n\n"
                    "💡 *You can also send multiple targets at once (one per line)!*\n"
                    "Type `/cancel` to cancel."
                )
            await query.message.reply_text(msg, reply_markup=cancel_keyboard(user_id))

        elif data == "auto_live_list":
            await query.answer()
            targets = get_user_live_targets(user_id)
            if not targets:
                no_target_msg = (
                    "📋 **আপনার কোনো অটো লাইভ জয়েন টার্গেট নেই!**\n\n"
                    "কোনো চ্যানেল বা গ্রুপে লাইভ শুরু হলে অটো জয়েন পেতে নিচে **[➕ নতুন টার্গেট যোগ করুন]** বাটনে চাপ দিন।"
                    if get_user_lang(user_id) == "bn" else
                    "📋 **No Auto Live Targets configured!**\n\n"
                    "Click **[➕ Add New Target]** below to start auto-monitoring a channel or group."
                )
                await query.message.edit_text(no_target_msg, reply_markup=auto_live_list_keyboard([], user_id))
                return

            list_title = (
                f"📋 **আপনার সংরক্ষিত লাইভ টার্গেট তালিকা ({len(targets)} টি):**\n\n"
                "নিচের যেকোনো টার্গেটে ক্লিক করে বিস্তারিত দেখতে, সক্রিয়/বন্ধ করতে বা অ্যাকাউন্ট সংখ্যা পরিবর্তন করতে পারেন:\n\n"
                "• 🔴 = বর্তমানে লাইভ চলছে\n"
                "• 🟢 = মনিটরিং সক্রিয় (লাইভের অপেক্ষায়)\n"
                "• ⚪ = সাময়িক বন্ধ (Paused)"
                if get_user_lang(user_id) == "bn" else
                f"📋 **Your Saved Live Targets ({len(targets)}):**\n\n"
                "Click on any target below to view details, toggle status, or adjust account counts:\n\n"
                "• 🔴 = Live Stream Active Now\n"
                "• 🟢 = Active Monitoring (Waiting for Live)\n"
                "• ⚪ = Paused"
            )
            await query.message.edit_text(list_title, reply_markup=auto_live_list_keyboard(targets, user_id))

        elif data.startswith("auto_live_view_"):
            target_id = data.replace("auto_live_view_", "")
            target = get_live_target_by_id(target_id)
            if not target:
                await query.answer("❌ Target not found!", show_alert=True)
                targets = get_user_live_targets(user_id)
                await query.message.edit_text("Target not found", reply_markup=auto_live_list_keyboard(targets, user_id))
                return

            await query.answer()
            title = target.get("chat_title", "Target")
            u_name = f"@{target.get('chat_username')}" if target.get("chat_username") else (target.get("invite_link") or target.get("target_input"))
            is_live = target.get("is_currently_live", False)
            is_active = target.get("is_active", True)
            acc_cnt = target.get("accounts_count", 0)
            acc_str = f"{acc_cnt} টি" if acc_cnt > 0 else "সবগুলো (All Accounts)"
            total_joins = target.get("total_auto_joins", 0)
            last_join = target.get("last_joined_at") or "এখনও হয়নি (Never)"

            if is_live:
                status_str = "🔴 **বর্তমানে লাইভ স্ট্রিম চলছে!**"
            elif is_active:
                status_str = "🟢 **সক্রিয় (লাইভ শুরু হলেই জয়েন হবে)**"
            else:
                status_str = "⚪ **সাময়িক বন্ধ (Paused)**"

            if get_user_lang(user_id) == "bn":
                detail_txt = (
                    f"🎯 **টার্গেট বিবরণ:**\n\n"
                    f"📢 নাম: **{title}**\n"
                    f"🔗 লিংক/ইউজারনেম: `{u_name}`\n"
                    f"📊 বর্তমান অবস্থা: {status_str}\n"
                    f"👥 জয়েনিং অ্যাকাউন্ট: **{acc_str}**\n"
                    f"⚡ মোট অটো জয়েন: **{total_joins} বার**\n"
                    f"🕒 সর্বশেষ অটো জয়েন: `{last_join}`\n\n"
                    "💡 সেটিংস পরিবর্তন করতে নিচের বাটনগুলো ব্যবহার করুন:"
                )
            else:
                status_en = "🔴 **LIVE STREAM ACTIVE NOW!**" if is_live else ("🟢 **Active (Listening for Live)**" if is_active else "⚪ **Paused**")
                acc_en = f"{acc_cnt} Accounts" if acc_cnt > 0 else "All Accounts"
                last_join_en = target.get("last_joined_at") or "Never"
                detail_txt = (
                    f"🎯 **Target Details:**\n\n"
                    f"📢 Name: **{title}**\n"
                    f"🔗 Link/Username: `{u_name}`\n"
                    f"📊 Status: {status_en}\n"
                    f"👥 Accounts to Join: **{acc_en}**\n"
                    f"⚡ Total Auto Joins: **{total_joins}**\n"
                    f"🕒 Last Auto Joined: `{last_join_en}`\n\n"
                    "💡 Use the buttons below to update settings:"
                )
            await query.message.edit_text(detail_txt, reply_markup=auto_live_target_detail_keyboard(target, user_id))

        elif data.startswith("auto_live_toggle_"):
            target_id = data.replace("auto_live_toggle_", "")
            new_status = toggle_live_target(target_id)
            target = get_live_target_by_id(target_id)
            alert = "🟢 টার্গেট সক্রিয় করা হয়েছে!" if new_status else "⏸️ টার্গেট সাময়িক বন্ধ করা হয়েছে!"
            if get_user_lang(user_id) != "bn":
                alert = "🟢 Target activated!" if new_status else "⏸️ Target paused!"
            await query.answer(alert)
            if target:
                title = target.get("chat_title", "Target")
                u_name = f"@{target.get('chat_username')}" if target.get("chat_username") else (target.get("invite_link") or target.get("target_input"))
                is_live = target.get("is_currently_live", False)
                acc_cnt = target.get("accounts_count", 0)
                acc_str = f"{acc_cnt} টি" if acc_cnt > 0 else "সবগুলো (All Accounts)"
                total_joins = target.get("total_auto_joins", 0)
                last_join = target.get("last_joined_at") or "এখনও হয়নি (Never)"
                status_str = "🔴 **বর্তমানে লাইভ স্ট্রিম চলছে!**" if is_live else ("🟢 **সক্রিয় (লাইভ শুরু হলেই জয়েন হবে)**" if new_status else "⚪ **সাময়িক বন্ধ (Paused)**")
                detail_txt = (
                    f"🎯 **টার্গেট বিবরণ:**\n\n"
                    f"📢 নাম: **{title}**\n"
                    f"🔗 লিংক/ইউজারনেম: `{u_name}`\n"
                    f"📊 বর্তমান অবস্থা: {status_str}\n"
                    f"👥 জয়েনিং অ্যাকাউন্ট: **{acc_str}**\n"
                    f"⚡ মোট অটো জয়েন: **{total_joins} বার**\n"
                    f"🕒 সর্বশেষ অটো জয়েন: `{last_join}`\n\n"
                    "💡 সেটিংস পরিবর্তন করতে নিচের বাটনগুলো ব্যবহার করুন:"
                )
                await query.message.edit_text(detail_txt, reply_markup=auto_live_target_detail_keyboard(target, user_id))

        elif data.startswith("auto_live_del_"):
            target_id = data.replace("auto_live_del_", "")
            delete_live_target(target_id)
            alert = "🗑️ টার্গেট সফলভাবে মুছে ফেলা হয়েছে!" if get_user_lang(user_id) == "bn" else "🗑️ Target deleted!"
            await query.answer(alert, show_alert=True)
            targets = get_user_live_targets(user_id)
            list_title = (
                f"📋 **আপনার সংরক্ষিত লাইভ টার্গেট তালিকা ({len(targets)} টি):**" if get_user_lang(user_id) == "bn"
                else f"📋 **Your Saved Live Targets ({len(targets)}):**"
            )
            await query.message.edit_text(list_title, reply_markup=auto_live_list_keyboard(targets, user_id))

        elif data.startswith("auto_live_cntmenu_"):
            target_id = data.replace("auto_live_cntmenu_", "")
            accounts = manager.get_user_accounts_list(user_id)
            await query.answer()
            prompt = (
                "👥 **এই টার্গেটে কতগুলো অ্যাকাউন্ট দিয়ে লাইভে জয়েন করতে চান?**\n\n"
                "সবগুলো অ্যাকাউন্ট বা নির্দিষ্ট সংখ্যা বেছে নিন:"
                if get_user_lang(user_id) == "bn" else
                "👥 **How many accounts should join this live stream?**\n\n"
                "Select All accounts or choose a specific number:"
            )
            await query.message.edit_text(prompt, reply_markup=auto_live_count_selection_keyboard(target_id, len(accounts), user_id))

        elif data.startswith("auto_live_setcnt_"):
            parts = data.split("_")
            cnt = int(parts[-1])
            target_id = "_".join(parts[3:-1])
            update_live_target_count(target_id, cnt)
            cnt_text = f"{cnt} টি" if cnt > 0 else "সবগুলো (All)"
            ans = f"✅ অ্যাকাউন্ট সংখ্যা: {cnt_text}"
            await query.answer(ans)
            target = get_live_target_by_id(target_id)
            if target:
                title = target.get("chat_title", "Target")
                u_name = f"@{target.get('chat_username')}" if target.get("chat_username") else (target.get("invite_link") or target.get("target_input"))
                is_live = target.get("is_currently_live", False)
                is_active = target.get("is_active", True)
                status_str = "🔴 **বর্তমানে লাইভ স্ট্রিম চলছে!**" if is_live else ("🟢 **সক্রিয় (লাইভ শুরু হলেই জয়েন হবে)**" if is_active else "⚪ **সাময়িক বন্ধ (Paused)**")
                detail_txt = (
                    f"🎯 **টার্গেট বিবরণ:**\n\n"
                    f"📢 নাম: **{title}**\n"
                    f"🔗 লিংক/ইউজারনেম: `{u_name}`\n"
                    f"📊 বর্তমান অবস্থা: {status_str}\n"
                    f"👥 জয়েনিং অ্যাকাউন্ট: **{cnt_text}**\n"
                    f"⚡ মোট অটো জয়েন: **{target.get('total_auto_joins', 0)} বার**\n"
                    f"🕒 সর্বশেষ অটো জয়েন: `{target.get('last_joined_at') or 'এখনও হয়নি'}`\n\n"
                    "💡 সেটিংস পরিবর্তন করতে নিচের বাটনগুলো ব্যবহার করুন:"
                )
                await query.message.edit_text(detail_txt, reply_markup=auto_live_target_detail_keyboard(target, user_id))

        elif data.startswith("auto_live_custcnt_"):
            target_id = data.replace("auto_live_custcnt_", "")
            await query.answer()
            user_action_states[user_id] = {"action": "AWAITING_AUTO_LIVE_CUSTOM_COUNT", "target_id": target_id}
            msg = (
                "✍️ **লাইভ জয়েন করার জন্য কয়টি অ্যাকাউন্ট ব্যবহার করতে চান?**\n\n"
                "কাঙ্ক্ষিত সংখ্যাটি লিখে পাঠান (যেমন: `3`, `5`, `10` ইত্যাদি):\n"
                "*(সবগুলো অ্যাকাউন্ট ব্যবহার করতে `0` লিখুন)*"
                if get_user_lang(user_id) == "bn" else
                "✍️ **Enter the number of accounts you want to join with:**\n\n"
                "Send a number (e.g. `3`, `5`, `10` etc.):\n"
                "*(Send `0` to use All accounts)*"
            )
            await query.message.reply_text(msg, reply_markup=cancel_keyboard(user_id))

        elif data.startswith("auto_live_test_"):
            target_id = data.replace("auto_live_test_", "")
            target = get_live_target_by_id(target_id)
            if not target:
                await query.answer("Target not found", show_alert=True)
                return
            await query.answer("🚀 টেস্টিং শুরু হচ্ছে...", show_alert=False)
            chat_target = target.get("invite_link") or (f"@{target.get('chat_username').lstrip('@')}" if target.get("chat_username") else target.get("chat_id"))
            acc_cnt = target.get("accounts_count", 0)
            join_cnt = acc_cnt if acc_cnt > 0 else None
            await execute_live_join(user_id, str(chat_target), query.message, count=join_cnt)

        elif data == "btn_auto_mon_menu":
            await query.answer()
            monitors = get_user_monitors(user_id)
            if get_user_lang(user_id) == "bn":
                txt = (
                    "📡 **অটো চ্যানেল পোস্ট মনিটর (Auto Post Boost):**\n\n"
                    "এখানে আপনার চ্যানেল সেট করে রাখলে নতুন পোস্ট করার সাথে সাথেই "
                    "**১-৫ সেকেন্ডের মধ্যে** স্বয়ংক্রিয়ভাবে ভিউ এবং পজিটিভ রিঅ্যাকশন প্রদান করা হবে!\n\n"
                    f"📋 **আপনার মনিটর করা চ্যানেল:** {len(monitors)} টি"
                )
            else:
                txt = (
                    "📡 **Auto Channel Post Monitor:**\n\n"
                    "Configure your channel here to automatically receive views and positive reactions "
                    "within **1-5 seconds** of publishing a new post!\n\n"
                    f"📋 **Monitored Channels:** {len(monitors)}"
                )
            await query.message.edit_text(txt, reply_markup=auto_monitor_menu_keyboard(user_id, monitors))

        elif data == "btn_amon_add":
            accounts = manager.get_user_accounts_list(user_id)
            if not accounts:
                await query.answer(tr(user_id, "no_accounts"), show_alert=True)
                return
            await query.answer()
            user_action_states[user_id] = {"action": "AWAITING_AUTO_MON_CHANNEL"}
            if get_user_lang(user_id) == "bn":
                msg = (
                    "🔗 **চ্যানেলের লিংক বা ইউজারনেম পাঠান:**\n\n"
                    "যে চ্যানেলের নতুন পোস্টে অটো ভিউ ও রিঅ্যাকশন চান, তার লিংক বা ইউজারনেম দিন:\n\n"
                    "📌 **এক বা একাধিক চ্যানেল দিতে পারেন:**\n"
                    "• একটির জন্য: `@mychannel` বা `https://t.me/mychannel`\n"
                    "• একাধিক চ্যানেল একসাথে যুক্ত করতে প্রতি লাইনে একটি করে লিংক/ইউজারনেম দিন:\n"
                    "  `@channel1`\n"
                    "  `@channel2`\n"
                    "  `https://t.me/channel3`\n\n"
                    "• অথবা প্রাইভেট চ্যানেলের ইনভাইট লিংক: `https://t.me/+AbCdEf`"
                )
            else:
                msg = (
                    "🔗 **Send Channel Link(s) or Username(s):**\n\n"
                    "Send the channel link or @username you want to monitor:\n\n"
                    "📌 **Single or Multiple Channels:**\n"
                    "• Single: `@mychannel` or `https://t.me/mychannel`\n"
                    "• Multiple channels at once (one per line):\n"
                    "  `@channel1`\n"
                    "  `@channel2`\n"
                    "  `https://t.me/channel3`\n\n"
                    "• Or private channel invite link: `https://t.me/+AbCdEf`"
                )
            await query.message.reply_text(msg, reply_markup=cancel_keyboard(user_id))

        elif data.startswith("btn_amon_react_"):
            action_data = user_action_states.get(user_id)
            if not isinstance(action_data, dict):
                await query.answer("Session expired.", show_alert=True)
                return

            raw_mode = data.replace("btn_amon_react_", "")

            # If user selected CUSTOM_INPUT:
            if raw_mode == "CUSTOM_INPUT":
                await query.answer()
                user_action_states[user_id] = {
                    **action_data,
                    "action": "AWAITING_CUSTOM_REACTION"
                }
                if get_user_lang(user_id) == "bn":
                    txt = (
                        "✍️ **ম্যানুয়াল কাস্টম রিঅ্যাকশন ইমোজি পাঠান:**\n\n"
                        "আপনার পছন্দের এক বা একাধিক ইমোজি মেসেজে লিখে পাঠান।\n\n"
                        "📌 **উদাহরণ:**\n"
                        "• যেকোনো একটি: `🔥` অথবা `❤️` অথবা `⚡`\n"
                        "• একাধিক ইমোজি দিতে স্পেস বা কমা দিয়ে লিখুন (প্রতিটি অ্যাকাউন্টে এলোমেলোভাবে দেওয়া হবে):\n"
                        "  `🔥 ❤️ 🚀 ⚡ 💯`\n\n"
                        "💡 *বাতিল করতে /cancel চাপুন বা নিচের বাটন ক্লিক করুন।*"
                    )
                else:
                    txt = (
                        "✍️ **Send Custom Reaction Emoji(s):**\n\n"
                        "Send your desired Telegram emoji(s) as a text message.\n\n"
                        "📌 **Examples:**\n"
                        "• Single: `🔥` or `❤️` or `⚡`\n"
                        "• Multiple (rotated across accounts):\n"
                        "  `🔥 ❤️ 🚀 ⚡ 💯`\n\n"
                        "💡 *To cancel, type /cancel or click below.*"
                    )
                await query.message.reply_text(txt, reply_markup=cancel_keyboard(user_id))
                return

            # If user selected POOL_PER_POST (2-5 Emoji Pool with 1 random emoji per post across all accounts):
            if raw_mode == "POOL_PER_POST":
                await query.answer()
                user_action_states[user_id] = {
                    **action_data,
                    "action": "AWAITING_POOL_REACTION"
                }
                if get_user_lang(user_id) == "bn":
                    txt = (
                        "🎯 **২ থেকে ৫টি ইমোজি পুল সেট করুন (প্রতি পোস্টে ১টি র‍্যান্ডম):**\n\n"
                        "আপনি যে ২ থেকে ৫টি ইমোজির মধ্য থেকে লটারি করতে চান, সেগুলো স্পেস বা কমা দিয়ে লিখুন।\n\n"
                        "📌 **উদাহরণ:**\n"
                        "• ৩টি ইমোজি: `🔥 ❤️ 👍`\n"
                        "• ৪টি ইমোজি: `🔥, ❤️, ⚡, 🚀`\n"
                        "• ৫টি ইমোজি: `🔥 ❤️ ⚡ 🚀 💯`\n\n"
                        "💡 **কীভাবে কাজ করবে:**\n"
                        "চ্যানেলে যখনই নতুন কোনো পোস্ট আসবে, বট আপনার দেওয়া এই ইমোজিগুলো থেকে **লটারির মতো যেকোনো ১টি নির্দিষ্ট ইমোজি বেছে নেবে** এবং ওই পোস্টে সব অ্যাকাউন্ট দিয়ে শুধুমাত্র সেই ১টি ইমোজিই রিঅ্যাকশন পড়বে! পরবর্তী পোস্টে আবার অন্য একটি ইমোজি বেছে নেওয়া হবে।\n\n"
                        "💡 *বাতিল করতে /cancel চাপুন বা নিচের বাটন ক্লিক করুন।*"
                    )
                else:
                    txt = (
                        "🎯 **Set 2–5 Emoji Pool (1 Random per Post):**\n\n"
                        "Send between 2 to 5 emojis separated by space or comma.\n\n"
                        "📌 **Examples:**\n"
                        "• 3 emojis: `🔥 ❤️ 👍`\n"
                        "• 4 emojis: `🔥, ❤️, ⚡, 🚀`\n"
                        "• 5 emojis: `🔥 ❤️ ⚡ 🚀 💯`\n\n"
                        "💡 **How it works:**\n"
                        "For every new post published in your channel, the bot will pick **ONE random emoji** from this pool, and all accounts will react with that exact same emoji on that post!\n\n"
                        "💡 *To cancel, type /cancel or click below.*"
                    )
                await query.message.reply_text(txt, reply_markup=cancel_keyboard(user_id))
                return

            # Non-custom input: pop state
            user_action_states.pop(user_id, None)

            if raw_mode == "RANDOM_POSITIVE":
                r_mode = "RANDOM_POSITIVE"
                spec_emoji = None
                r_display = "🎲 সকল পজিটিভ রিঅ্যাকশন (Positive Mix)"
            elif raw_mode == "NONE":
                r_mode = "NONE"
                spec_emoji = None
                r_display = "👁️ শুধুমাত্র ভিউ (কোনো রিঅ্যাকশন নয়)"
            elif raw_mode.startswith("SPECIFIC_"):
                r_mode = "SPECIFIC"
                spec_emoji = raw_mode.replace("SPECIFIC_", "")
                r_display = f"নির্দিষ্ট ইমোজি ({spec_emoji})"
            else:
                r_mode = "RANDOM_POSITIVE"
                spec_emoji = None
                r_display = "🎲 পজিটিভ রিঅ্যাকশন"

            is_editing = action_data.get("is_editing", False) or action_data.get("action") == "EDITING_REACTION"
            if is_editing:
                mon_id = action_data.get("monitor_id")
                updated = update_monitor_reaction(mon_id, user_id, r_mode, spec_emoji)
                if updated:
                    mon = get_monitor_by_id(mon_id)
                    st = "🟢 সক্রিয় (Active)" if mon.get("is_active", True) else "⏸️ সাময়িক বন্ধ (Paused)"
                    if get_user_lang(user_id) == "bn":
                        txt = (
                            f"✅ **চ্যানেল রিঅ্যাকশন সফলভাবে পরিবর্তন করা হয়েছে!**\n\n"
                            f"📢 **চ্যানেল:** {mon.get('channel_title', 'Channel')}\n"
                            f"📊 **স্ট্যাটাস:** {st}\n"
                            f"👁️ **ভিউ:** **{mon.get('views_count', 5)}** টি\n"
                            f"❤️ **নতুন রিঅ্যাকশন:** {r_display}\n\n"
                            f"💡 *এখন থেকে নতুন পোস্টে এই রিঅ্যাকশন প্রদান করা হবে।*"
                        )
                    else:
                        txt = (
                            f"✅ **Monitor Reaction Updated Successfully!**\n\n"
                            f"📢 **Channel:** {mon.get('channel_title', 'Channel')}\n"
                            f"📊 **Status:** {st}\n"
                            f"👁️ **Views:** **{mon.get('views_count', 5)}**\n"
                            f"❤️ **New Reaction:** {r_display}\n\n"
                            f"💡 *New posts will now receive this reaction.*"
                        )
                    await query.message.edit_text(txt, reply_markup=auto_monitor_detail_keyboard(user_id, mon_id, mon.get("is_active", True)))
                else:
                    await query.answer("Monitor not found or update failed.", show_alert=True)
                return

            if ("channel_id" not in action_data and "channels" not in action_data) or "views_count" not in action_data:
                await query.answer("Session expired.", show_alert=True)
                return
            await query.answer()

            views = action_data.get("views_count", 5)
            channels = action_data.get("channels", [])
            if not channels and "channel_id" in action_data:
                channels = [{
                    "chat_id": action_data["channel_id"],
                    "title": action_data.get("channel_title", "Channel"),
                    "username": action_data.get("channel_username", ""),
                    "last_msg_id": action_data.get("last_msg_id", 0)
                }]

            for ch in channels:
                add_channel_monitor(
                    user_id=user_id,
                    channel_id=ch["chat_id"],
                    channel_title=ch.get("title", "Channel"),
                    channel_username=ch.get("username", ""),
                    views_count=views,
                    reaction_mode=r_mode,
                    specific_emoji=spec_emoji,
                    last_msg_id=ch.get("last_msg_id", 0),
                    invite_link=ch.get("invite_link", "")
                )

            if len(channels) == 1:
                ch_title = channels[0].get("title", "Channel")
                ch_user = channels[0].get("username", "")
                if get_user_lang(user_id) == "bn":
                    txt = (
                        "🎉 **অটো চ্যানেল পোস্ট মনিটর সফলভাবে চালু হয়েছে!**\n\n"
                        f"📢 **চ্যানেল:** {ch_title} (@{ch_user or 'Private'})\n"
                        f"👁️ **ভিউ সংখ্যা:** প্রতি পোস্টে **{views}টি** ভিউ\n"
                        f"❤️ **রিঅ্যাকশন:** {r_display}\n"
                        f"⏱️ **অটো টাইমিং:** নতুন পোস্ট আসার **১ থেকে ৫ সেকেন্ডের** মধ্যে সম্পন্ন হবে!\n\n"
                        "💡 *এখন থেকে এই চ্যানেলে নতুন যেকোনো পোস্ট হলেই স্বয়ংক্রিয়ভাবে ভিউ ও রিঅ্যাকশন প্রদান করা হবে।*"
                    )
                else:
                    txt = (
                        "🎉 **Auto Channel Post Monitor Activated!**\n\n"
                        f"📢 **Channel:** {ch_title} (@{ch_user or 'Private'})\n"
                        f"👁️ **Views Target:** **{views}** views per post\n"
                        f"❤️ **Reactions:** {r_display}\n"
                        f"⏱️ **Timing:** Automatically delivered within **1–5 seconds** of new post!\n\n"
                        "💡 *Whenever you publish a new post in this channel, views and reactions will be applied automatically.*"
                    )
            else:
                ch_names = "\n".join([f"• **{c.get('title', 'Channel')}** (@{c.get('username') or 'Private'})" for c in channels])
                if get_user_lang(user_id) == "bn":
                    txt = (
                        f"🎉 **মোট {len(channels)}টি চ্যানেলে অটো পোস্ট মনিটর সফলভাবে চালু হয়েছে!**\n\n"
                        f"📋 **যুক্ত হওয়া চ্যানেলসমূহ:**\n{ch_names}\n\n"
                        f"👁️ **ভিউ সংখ্যা:** প্রতি চ্যানেলে নতুন পোস্টে **{views}টি** ভিউ\n"
                        f"❤️ **রিঅ্যাকশন:** {r_display}\n"
                        f"⏱️ **অটো টাইমিং:** নতুন পোস্ট আসার **১ থেকে ৫ সেকেন্ডের** মধ্যে সম্পন্ন হবে!\n\n"
                        "💡 *এখন থেকে এই চ্যানেলগুলোতে নতুন পোস্ট আসার সাথে সাথেই স্বয়ংক্রিয়ভাবে বুস্টিং শুরু হবে।*"
                    )
                else:
                    txt = (
                        f"🎉 **Auto Post Monitor Activated for {len(channels)} Channels!**\n\n"
                        f"📋 **Added Channels:**\n{ch_names}\n\n"
                        f"👁️ **Views Target:** **{views}** views per post\n"
                        f"❤️ **Reactions:** {r_display}\n"
                        f"⏱️ **Timing:** Automatically delivered within **1–5 seconds** of new post!\n\n"
                        "💡 *Whenever new posts are published in these channels, views and reactions will be applied automatically.*"
                    )
            await query.message.reply_text(txt, reply_markup=main_menu_keyboard(user_id))

        elif data == "btn_amon_pause_all":
            count = toggle_all_user_monitors(user_id, activate=False)
            if get_user_lang(user_id) == "bn":
                msg = f"⏸️ আপনার {count}টি চ্যানেলের মনিটর সাময়িক বন্ধ (Pause) করা হয়েছে!"
            else:
                msg = f"⏸️ Paused {count} channel monitor(s)!"
            await query.answer(msg, show_alert=True)
            monitors = get_user_monitors(user_id)
            txt = "📡 **আপনার মনিটর তালিকা:**" if get_user_lang(user_id) == "bn" else "📡 **Your Monitored Channels:**"
            await query.message.edit_text(txt, reply_markup=auto_monitor_menu_keyboard(user_id, monitors))

        elif data == "btn_amon_resume_all":
            count = toggle_all_user_monitors(user_id, activate=True)
            if get_user_lang(user_id) == "bn":
                msg = f"▶️ আপনার {count}টি চ্যানেলের মনিটর আবার চালু (Resume) করা হয়েছে!"
            else:
                msg = f"▶️ Resumed {count} channel monitor(s)!"
            await query.answer(msg, show_alert=True)
            monitors = get_user_monitors(user_id)
            txt = "📡 **আপনার মনিটর তালিকা:**" if get_user_lang(user_id) == "bn" else "📡 **Your Monitored Channels:**"
            await query.message.edit_text(txt, reply_markup=auto_monitor_menu_keyboard(user_id, monitors))

        elif data == "btn_amon_clear_all":
            count = delete_all_user_monitors(user_id)
            if get_user_lang(user_id) == "bn":
                msg = f"🗑️ আপনার সমস্ত ({count}টি) চ্যানেল মনিটর তালিকা মুছে ফেলা হয়েছে!"
            else:
                msg = f"🗑️ Deleted all {count} channel monitor(s)!"
            await query.answer(msg, show_alert=True)
            monitors = get_user_monitors(user_id)
            txt = "📡 **আপনার কোনো সক্রিয় চ্যানেল মনিটর নেই।**" if get_user_lang(user_id) == "bn" else "📡 **You have no active channel monitors.**"
            await query.message.edit_text(txt, reply_markup=auto_monitor_menu_keyboard(user_id, monitors))

        elif data.startswith("btn_amon_view_"):
            mon_id = data.replace("btn_amon_view_", "")
            mon = get_monitor_by_id(mon_id)
            if not mon or mon.get("user_id") != user_id:
                await query.answer("Monitor not found.", show_alert=True)
                return
            await query.answer()

            st = "🟢 সক্রিয় (Active)" if mon.get("is_active", True) else "⏸️ সাময়িক বন্ধ (Paused)"
            r_mode = mon.get("reaction_mode", "")
            if r_mode == "RANDOM_POSITIVE":
                r_lbl = "🎲 সকল পজিটিভ রিঅ্যাকশন (Positive Mix)"
            elif r_mode == "POOL_PER_POST":
                r_lbl = f"🎯 ইমোজি পুল (পোস্টে ১টি): {mon.get('specific_emoji', '🔥')}"
            elif r_mode == "SPECIFIC":
                r_lbl = f"ইমোজি: {mon.get('specific_emoji', '❤️')}"
            else:
                r_lbl = "শুধুমাত্র ভিউ (No reaction)"

            if get_user_lang(user_id) == "bn":
                txt = (
                    f"📡 **চ্যানেল মনিটর বিবরণ:**\n\n"
                    f"📢 **চ্যানেল:** {mon.get('channel_title', 'Channel')}\n"
                    f"🆔 **চ্যানেল আইডি:** `{mon.get('channel_id')}`\n"
                    f"🔗 **ইউজারনেম:** @{mon.get('channel_username') or 'Private'}\n"
                    f"📊 **স্ট্যাটাস:** {st}\n"
                    f"👁️ **ভিউ প্রতি পোস্ট:** **{mon.get('views_count', 5)}** টি\n"
                    f"❤️ **রিঅ্যাকশন মোড:** {r_lbl}\n"
                    f"🚀 **মোট বুস্টকৃত পোস্ট:** **{mon.get('total_posts_boosted', 0)}** টি\n"
                    f"📅 চালু হয়েছে: `{mon.get('created_at', 'N/A')}`"
                )
            else:
                txt = (
                    f"📡 **Channel Monitor Details:**\n\n"
                    f"📢 **Channel:** {mon.get('channel_title', 'Channel')}\n"
                    f"🆔 **Channel ID:** `{mon.get('channel_id')}`\n"
                    f"🔗 **Username:** @{mon.get('channel_username') or 'Private'}\n"
                    f"📊 **Status:** {st}\n"
                    f"👁️ **Views per post:** **{mon.get('views_count', 5)}**\n"
                    f"❤️ **Reaction Mode:** {r_lbl}\n"
                    f"🚀 **Total Posts Boosted:** **{mon.get('total_posts_boosted', 0)}**\n"
                    f"📅 Started: `{mon.get('created_at', 'N/A')}`"
                )
            await query.message.edit_text(txt, reply_markup=auto_monitor_detail_keyboard(user_id, mon_id, mon.get("is_active", True)))

        elif data.startswith("btn_amon_toggle_"):
            mon_id = data.replace("btn_amon_toggle_", "")
            new_status = toggle_monitor_status(mon_id, user_id)
            if new_status is None:
                await query.answer("Monitor not found.", show_alert=True)
                return
            await query.answer("স্ট্যাটাস পরিবর্তন করা হয়েছে!" if get_user_lang(user_id) == "bn" else "Status updated!", show_alert=False)
            mon = get_monitor_by_id(mon_id)
            st = "🟢 সক্রিয় (Active)" if new_status else "⏸️ সাময়িক বন্ধ (Paused)"
            r_mode = mon.get("reaction_mode", "")
            r_lbl = "🎲 পজিটিভ মিক্স" if r_mode == "RANDOM_POSITIVE" else (f"🎯 পুল: {mon.get('specific_emoji', '🔥')}" if r_mode == "POOL_PER_POST" else (mon.get("specific_emoji", "❤️") if r_mode == "SPECIFIC" else "ভিউ অনলি"))
            txt = (
                f"📡 **চ্যানেল মনিটর বিবরণ (আপডেটেড):**\n\n"
                f"📢 **চ্যানেল:** {mon.get('channel_title', 'Channel')}\n"
                f"📊 **স্ট্যাটাস:** {st}\n"
                f"👁️ **ভিউ:** **{mon.get('views_count', 5)}** টি | ❤️ **রিঅ্যাকশন:** {r_lbl}\n"
                f"🚀 **মোট বুস্টকৃত পোস্ট:** **{mon.get('total_posts_boosted', 0)}** টি"
            ) if get_user_lang(user_id) == "bn" else (
                f"📡 **Channel Monitor Details (Updated):**\n\n"
                f"📢 **Channel:** {mon.get('channel_title', 'Channel')}\n"
                f"📊 **Status:** {st}\n"
                f"👁️ **Views:** **{mon.get('views_count', 5)}** | ❤️ **Reaction:** {r_lbl}\n"
                f"🚀 **Total Boosted:** **{mon.get('total_posts_boosted', 0)}**"
            )
            await query.message.edit_text(txt, reply_markup=auto_monitor_detail_keyboard(user_id, mon_id, new_status))

        elif data.startswith("btn_amon_chg_react_"):
            mon_id = data.replace("btn_amon_chg_react_", "")
            mon = get_monitor_by_id(mon_id)
            if not mon or mon.get("user_id") != user_id:
                await query.answer("Monitor not found.", show_alert=True)
                return
            await query.answer()
            user_action_states[user_id] = {
                "action": "EDITING_REACTION",
                "is_editing": True,
                "monitor_id": mon_id
            }
            if get_user_lang(user_id) == "bn":
                txt = (
                    f"📢 **চ্যানেল:** {mon.get('channel_title', 'Channel')}\n\n"
                    f"❤️ **নতুন রিঅ্যাকশন নির্বাচন করুন:**\n"
                    f"• `🎲 সকল পজিটিভ রিঅ্যাকশন`: বট বিভিন্ন পজিটিভ রিঅ্যাকশন মিক্স করে দেবে।\n"
                    f"• `✍️ ম্যানুয়াল কাস্টম ইমোজি`: আপনি নিজে পছন্দমতো ইমোজি লিখে দিতে পারেন।\n"
                    f"• অথবা নিচে থেকে নির্দিষ্ট কোনো ইমোজি বেছে নিন:"
                )
            else:
                txt = (
                    f"📢 **Channel:** {mon.get('channel_title', 'Channel')}\n\n"
                    f"❤️ **Select New Reaction Preference:**\n"
                    f"• `🎲 All Positive Reactions`: Bot randomly mixes positive reactions.\n"
                    f"• `✍️ Custom Emoji`: Manually enter your preferred emojis.\n"
                    f"• Or choose an emoji below:"
                )
            await query.message.edit_text(txt, reply_markup=auto_reaction_choice_keyboard(user_id))

        elif data.startswith("btn_amon_del_"):
            mon_id = data.replace("btn_amon_del_", "")
            deleted = delete_monitor(mon_id, user_id)
            if deleted:
                await query.answer("🗑️ মনিটর ডিলিট করা হয়েছে!" if get_user_lang(user_id) == "bn" else "🗑️ Monitor deleted!", show_alert=True)
            else:
                await query.answer("Monitor not found.", show_alert=True)
            monitors = get_user_monitors(user_id)
            txt = "📡 **আপনার মনিটর তালিকা:**" if get_user_lang(user_id) == "bn" else "📡 **Your Monitored Channels:**"
            await query.message.edit_text(txt, reply_markup=auto_monitor_menu_keyboard(user_id, monitors))

        elif data == "btn_live_voice":
            user_in_call = [e for e in manager.get_user_engines(user_id).values() if e.in_call]
            if not user_in_call:
                await query.answer(tr(user_id, "no_accounts_in_call"), show_alert=True)
                return
            await query.answer()
            title = user_in_call[0].current_chat_title or "Active Live"
            await query.message.edit_text(
                tr(user_id, "live_voice_panel_title", title=title, count=len(user_in_call)),
                reply_markup=live_voice_control_keyboard(user_id)
            )

        elif data == "btn_voice_send_prompt":
            can_v, used_v, lim_v = can_use_live_voice(user_id)
            if not can_v:
                alert_text = (
                    f"❌ আজকের ফ্রি ১টি লাইভ ভয়েস ব্যবহারের কোটা শেষ!\nব্যবহৃত: {used_v}/{lim_v} টি।\n💡 আনলিমিটেড লাইভ ভয়েসের জন্য VIP মেম্বারশিপ নিন।"
                    if get_user_lang(user_id) == "bn" else
                    f"❌ Daily free live voice limit reached ({used_v}/{lim_v})!\nUpgrade to VIP for unlimited live voice streaming."
                )
                await query.answer(alert_text, show_alert=True)
                return

            user_in_call = [a for a in manager.get_user_accounts_list(user_id) if a.get("is_in_call")]
            if not user_in_call:
                await query.answer(tr(user_id, "no_accounts_in_call"), show_alert=True)
                return
            await query.answer()
            if len(user_in_call) == 1:
                user_action_states[user_id] = {
                    "action": "AWAITING_LIVE_VOICE_AUDIO",
                    "target_account": user_in_call[0]["session_name"],
                    "uploaded_audios": []
                }
                await query.message.reply_text(
                    tr(user_id, "live_voice_send_prompt"),
                    reply_markup=cancel_keyboard(user_id)
                )
            else:
                await query.message.edit_text(
                    tr(user_id, "live_voice_select_acc"),
                    reply_markup=voice_account_selector_keyboard(user_in_call, user_id)
                )

        elif data.startswith("btn_vset_"):
            can_v, used_v, lim_v = can_use_live_voice(user_id)
            if not can_v:
                alert_text = (
                    f"❌ আজকের ফ্রি ১টি লাইভ ভয়েস ব্যবহারের কোটা শেষ!\nব্যবহৃত: {used_v}/{lim_v} টি।\n💡 আনলিমিটেড লাইভ ভয়েসের জন্য VIP মেম্বারশিপ নিন।"
                    if get_user_lang(user_id) == "bn" else
                    f"❌ Daily free live voice limit reached ({used_v}/{lim_v})!\nUpgrade to VIP for unlimited live voice streaming."
                )
                await query.answer(alert_text, show_alert=True)
                return

            target_account = data.replace("btn_vset_", "")
            await query.answer()
            user_action_states[user_id] = {
                "action": "AWAITING_LIVE_VOICE_AUDIO",
                "target_account": target_account,
                "uploaded_audios": []
            }
            await query.message.reply_text(
                tr(user_id, "live_voice_send_prompt"),
                reply_markup=cancel_keyboard(user_id)
            )

        elif data == "btn_voice_raise_hand":
            user_in_call = [a for a in manager.get_user_accounts_list(user_id) if a.get("is_in_call")]
            if not user_in_call:
                await query.answer(tr(user_id, "no_accounts_in_call"), show_alert=True)
                return
            await query.answer()
            if len(user_in_call) == 1:
                status_msg = await query.message.reply_text(
                    "⏳ হাত তোলার রিকোয়েস্ট পাঠানো হচ্ছে..." if get_user_lang(user_id) == "bn" else "⏳ Sending Speak Request (Raise Hand)..."
                )
                res = await manager.raise_hand_in_live_for_user(user_id, chosen_acc=user_in_call[0]["session_name"])
                details = "\n".join(res.get("details", [])) if res.get("details") else res.get("error", "Failed")
                await status_msg.edit_text(
                    tr(user_id, "live_voice_raise_hand_done", details=details),
                    reply_markup=live_voice_control_keyboard(user_id)
                )
            else:
                prompt_text = "✋ **কোন অ্যাকাউন্টটি দিয়ে হাত তুলতে চান সিলেক্ট করুন:**" if get_user_lang(user_id) == "bn" else "✋ **Select which account should raise hand:**"
                await query.message.edit_text(
                    prompt_text,
                    reply_markup=raise_hand_account_selector_keyboard(user_in_call, user_id)
                )

        elif data.startswith("btn_rh_"):
            chosen_acc = data.replace("btn_rh_", "")
            await query.answer()
            status_msg = await query.message.reply_text(
                "⏳ হাত তোলার রিকোয়েস্ট পাঠানো হচ্ছে..." if get_user_lang(user_id) == "bn" else "⏳ Sending Speak Request (Raise Hand)..."
            )
            res = await manager.raise_hand_in_live_for_user(user_id, chosen_acc=chosen_acc)
            details = "\n".join(res.get("details", [])) if res.get("details") else res.get("error", "Failed")
            await status_msg.edit_text(
                tr(user_id, "live_voice_raise_hand_done", details=details),
                reply_markup=live_voice_control_keyboard(user_id)
            )

        elif data == "btn_voice_unmute":
            user_in_call = [e for e in manager.get_user_engines(user_id).values() if e.in_call]
            if not user_in_call:
                await query.answer(tr(user_id, "no_accounts_in_call"), show_alert=True)
                return
            await query.answer()
            res = await manager.unmute_in_live_for_user(user_id)
            details = "\n".join(res.get("details", []))
            await query.message.reply_text(
                tr(user_id, "live_voice_unmuted_done", details=details),
                reply_markup=live_voice_control_keyboard(user_id)
            )

        elif data == "btn_voice_mute":
            user_in_call = [e for e in manager.get_user_engines(user_id).values() if e.in_call]
            if not user_in_call:
                await query.answer(tr(user_id, "no_accounts_in_call"), show_alert=True)
                return
            await query.answer()
            res = await manager.mute_in_live_for_user(user_id)
            details = "\n".join(res.get("details", []))
            await query.message.reply_text(
                tr(user_id, "live_voice_muted_done", details=details),
                reply_markup=live_voice_control_keyboard(user_id)
            )

        elif data == "btn_voice_stop":
            user_in_call = [e for e in manager.get_user_engines(user_id).values() if e.in_call]
            if not user_in_call:
                await query.answer(tr(user_id, "no_accounts_in_call"), show_alert=True)
                return
            await query.answer()
            res = await manager.stop_voice_in_live_for_user(user_id)
            details = "\n".join(res.get("details", []))
            await query.message.reply_text(
                tr(user_id, "live_voice_stopped_done", details=details),
                reply_markup=live_voice_control_keyboard(user_id)
            )

        elif data == "btn_voice_done":
            user_action_states.pop(user_id, None)
            await query.answer("✅ ভয়েস সেট সম্পন্ন হয়েছে!" if get_user_lang(user_id) == "bn" else "✅ Voice setup completed!")
            user_in_call = [e for e in manager.get_user_engines(user_id).values() if e.in_call]
            title = user_in_call[0].current_chat_title if user_in_call else "Active Live"
            await query.message.reply_text(
                tr(user_id, "live_voice_panel_title", title=title, count=len(user_in_call)),
                reply_markup=live_voice_control_keyboard(user_id)
            )

        elif data == "btn_cancel_action":
            _cleanup_user_state(user_id)
            await query.answer()
            first_name = query.from_user.first_name if query.from_user else "User"
            text = get_main_menu_content(user_id, first_name)
            await query.message.edit_text(text, reply_markup=main_menu_keyboard(user_id))

        elif data == "btn_leave":
            await query.answer()
            if user_id in user_live_tasks:
                user_live_tasks[user_id].cancel()
                user_live_tasks.pop(user_id, None)
            user_live_start_times.pop(user_id, None)
            status_msg = await query.message.reply_text(tr(user_id, "leave_progress"))
            res = await manager.leave_for_user(user_id)
            await status_msg.edit_text(
                tr(user_id, "leave_completed", total=res["total"], success=res["success"]),
                reply_markup=main_menu_keyboard(user_id)
            )

        elif data == "btn_status":
            await query.answer()
            text, kb = await render_status_view(user_id)
            await query.message.edit_text(text, reply_markup=kb)

        elif data == "btn_admin_panel":
            if not is_admin(user_id):
                await query.answer("❌ শুধুমাত্র অ্যাডমিনদের জন্য প্রযোজ্য!", show_alert=True)
                return
            await query.answer()
            text = (
                "👑 **Super Admin Control Center (অ্যাডমিন কন্ট্রোল প্যানেল):**\n\n"
                "স্বাগতম অ্যাডমিন! নিচের অপশনগুলো থেকে আপনি সার্বিক সিস্টেম পরিচালনা করতে পারেন:"
            ) if get_user_lang(user_id) == "bn" else (
                "👑 **Super Admin Control Center:**\n\n"
                "Welcome Admin! Use the options below to control the entire bot system:"
            )
            await query.message.edit_text(text, reply_markup=admin_panel_keyboard(user_id))

        elif data == "admin_download_backup":
            if not is_admin(user_id):
                await query.answer("❌ শুধুমাত্র অ্যাডমিনদের জন্য!", show_alert=True)
                return
            await query.answer("📦 ব্যাকআপ তৈরি করা হচ্ছে...", show_alert=False)
            status_msg = await query.message.reply_text("📦 সার্ভার সেশন ব্যাকআপ তৈরি করা হচ্ছে...")
            import zipfile
            from datetime import datetime
            backup_zip = config.BASE_DIR / f"sessions_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
            try:
                with zipfile.ZipFile(backup_zip, 'w', compression=zipfile.ZIP_DEFLATED) as z:
                    for root, dirs, files in os.walk(config.SESSIONS_DIR):
                        for file in files:
                            full_path = Path(root) / file
                            rel_path = full_path.relative_to(config.BASE_DIR)
                            z.write(full_path, arcname=str(rel_path).replace("\\", "/"))

                await query.message.reply_document(
                    document=str(backup_zip),
                    caption=f"📁 **সার্ভার সেশন ব্যাকআপ সম্পন্ন!**\n📅 তারিখ: `{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}`\n📦 ফাইলের নাম: `{backup_zip.name}`"
                )
                await status_msg.delete()
            except Exception as e:
                await status_msg.edit_text(f"❌ ব্যাকআপ তৈরিতে সমস্যা: `{e}`")
            finally:
                try:
                    backup_zip.unlink(missing_ok=True)
                except Exception:
                    pass

        elif data == "admin_stats_view":
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer()
            stats = await manager.get_global_stats()
            vips = get_vip_list()
            admins = get_admins_list()
            text = (
                "👑 **সার্বিক সিস্টেম পরিসংখ্যান (Global Stats):**\n\n"
                f"👥 মোট রেজিস্টার্ড ইউজার: **{stats['unique_users']}** জন\n"
                f"📱 মোট হোস্টকৃত অ্যাকাউন্ট: **{stats['total_accounts']}** টি\n"
                f"🎙️ বর্তমানে লাইভে যুক্ত অ্যাকাউন্ট: **{stats['in_call']}** টি\n"
                f"🛡️ মোট অ্যাডমিন: **{len(admins)}** জন\n"
                f"💎 সক্রিয় VIP গ্রাহক: **{len(vips)}** জন"
            ) if get_user_lang(user_id) == "bn" else (
                "👑 **Global System Statistics:**\n\n"
                f"👥 Total Registered Users: **{stats['unique_users']}**\n"
                f"📱 Total Accounts Hosted: **{stats['total_accounts']}**\n"
                f"🎙️ Accounts in Active Live: **{stats['in_call']}**\n"
                f"🛡️ Total Admins: **{len(admins)}**\n"
                f"💎 Active VIP Subscribers: **{len(vips)}**"
            )
            await query.message.edit_text(text, reply_markup=admin_panel_keyboard(user_id))

        elif data == "admin_vip_list":
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer()
            text = await render_vip_list(user_id)
            await query.message.edit_text(text, reply_markup=admin_panel_keyboard(user_id))

        elif data == "admin_admins_list":
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer()
            text = await render_admins_list(user_id)
            await query.message.edit_text(text, reply_markup=admin_panel_keyboard(user_id))

        elif data == "admin_add_vip_prompt":
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer()
            user_action_states[user_id] = {"action": "AWAITING_ADD_VIP_ID"}
            prompt = "💎 **VIP গ্রাহক যুক্ত করুন:**\n\nঅনুগ্রহ করে যাকে VIP বানাতে চান তার **টেলিগ্রাম User ID বা ইউজারনেম (@username)** লিখে পাঠান:\n\nবাতিল করতে `/cancel` লিখুন।" if get_user_lang(user_id) == "bn" else "💎 **Add VIP User:**\n\nPlease send the **Telegram User ID or Username (@username)** to grant VIP:\n\nSend `/cancel` to cancel."
            await query.message.reply_text(prompt, reply_markup=cancel_keyboard(user_id))

        elif data == "admin_del_vip_prompt":
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer()
            user_action_states[user_id] = {"action": "AWAITING_DEL_VIP_ID"}
            prompt = "➖ **VIP মেম্বারশিপ বাতিল করুন:**\n\nঅনুগ্রহ করে যার VIP বাতিল করতে চান তার **টেলিগ্রাম User ID বা ইউজারনেম (@username)** লিখে পাঠান:\n\nবাতিল করতে `/cancel` লিখুন।" if get_user_lang(user_id) == "bn" else "➖ **Remove VIP User:**\n\nPlease send the **Telegram User ID or Username (@username)** to revoke VIP:\n\nSend `/cancel` to cancel."
            await query.message.reply_text(prompt, reply_markup=cancel_keyboard(user_id))

        elif data == "admin_add_admin_prompt":
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer()
            user_action_states[user_id] = {"action": "AWAITING_ADD_ADMIN_ID"}
            prompt = "🛡️ **নতুন অ্যাডমিন যোগ করুন:**\n\nযাকে অ্যাডমিন বানাতে চান তার **টেলিগ্রাম User ID বা ইউজারনেম (@username)** লিখে পাঠান:\n\nবাতিল করতে `/cancel` লিখুন।" if get_user_lang(user_id) == "bn" else "🛡️ **Add Admin:**\n\nPlease send the **Telegram User ID or Username (@username)** to make Admin:\n\nSend `/cancel` to cancel."
            await query.message.reply_text(prompt, reply_markup=cancel_keyboard(user_id))

        elif data == "admin_del_admin_prompt":
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            # Strict Owner-only protection: Added admin CANNOT remove any admin!
            if not is_super_admin(user_id):
                alert_text = "🚫 শুধুমাত্র Super Admin (মালিক) অ্যাডমিন বাতিল করতে পারবেন! যুক্ত হওয়া কোনো অ্যাডমিন অন্য কাউকে বাদ দিতে পারে না।" if get_user_lang(user_id) == "bn" else "🚫 Only Super Admin (Owner) can remove admins!"
                await query.answer(alert_text, show_alert=True)
                return
            await query.answer()
            user_action_states[user_id] = {"action": "AWAITING_DEL_ADMIN_ID"}
            prompt = "➖ **অ্যাডমিন পদ বাতিল করুন (Owner Action):**\n\nযার অ্যাডমিন পদ বাতিল করতে চান তার **টেলিগ্রাম User ID বা ইউজারনেম (@username)** লিখে পাঠান:\n\nবাতিল করতে `/cancel` লিখুন।" if get_user_lang(user_id) == "bn" else "➖ **Remove Admin (Owner Action):**\n\nPlease send the **Telegram User ID or Username (@username)** to revoke Admin:\n\nSend `/cancel` to cancel."
            await query.message.reply_text(prompt, reply_markup=cancel_keyboard(user_id))

        elif data == "admin_all_accounts":
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer()
            await manager.sync_all_engines_call_status()
            from core.session_store import load_accounts_registry
            registry = load_accounts_registry()
            if not registry:
                await query.message.edit_text("📱 কোনো অ্যাকাউন্ট হোস্ট করা নেই।" if get_user_lang(user_id) == "bn" else "📱 No hosted accounts found.", reply_markup=admin_panel_keyboard(user_id))
                return
            text = f"📱 **সিস্টেমের সকল হোস্টকৃত অ্যাকাউন্ট ({len(registry)} টি):**\n\n" if get_user_lang(user_id) == "bn" else f"📱 **All System Hosted Accounts ({len(registry)}):**\n\n"
            for idx, (sess, meta) in enumerate(list(registry.items())[:25], start=1):
                eng = manager.engines.get(sess)
                status_str = "🎙️ In Live" if eng and eng.in_call else "🟢 Idle"
                uname = f"@{meta.get('username')}" if meta.get('username') else f"ID: {meta.get('user_id', 'N/A')}"
                text += f"{idx}. **{meta.get('first_name', 'Acc')}** ({uname})\n   Owner: `{meta.get('owner_id')}` | {status_str}\n"
            if len(registry) > 25:
                text += f"\n...and {len(registry) - 25} more"
            await query.message.edit_text(text, reply_markup=admin_panel_keyboard(user_id))

        elif data == "admin_inspect_live_prompt":
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer()
            user_action_states[user_id] = {"action": "AWAITING_ADMIN_INSPECT_LINK"}
            prompt = (
                "🔍 **লাইভ মেম্বার ইন্সপেক্টর (Admin Exclusive):**\n\n"
                "যে টেলিগ্রাম চ্যানেল বা গ্রুপের লাইভ স্ট্রিম / ভয়েস চ্যাটের মেম্বারদের তালিকা ও ইউজারনেম দেখতে চান, "
                "তার লিংক বা ইউজারনেম পাঠিয়ে দিন:\n\n"
                "📌 **উদাহরণ:**\n"
                "• `@FreedomBase`\n"
                "• `https://t.me/FreedomBase`\n"
                "• অথবা প্রাইভেট ইনভাইট লিংক: `https://t.me/+AbCdEf`\n\n"
                "বাতিল করতে `/cancel` লিখুন।"
            ) if get_user_lang(user_id) == "bn" else (
                "🔍 **Live Members Inspector (Admin Exclusive):**\n\n"
                "Send the channel or group link/username whose live stream participants you want to inspect:\n\n"
                "📌 **Example:**\n"
                "• `@FreedomBase`\n"
                "• `https://t.me/FreedomBase`\n"
                "• Or invite link: `https://t.me/+AbCdEf`\n\n"
                "Type `/cancel` to cancel."
            )
            await query.message.reply_text(prompt, reply_markup=cancel_keyboard(user_id))

        elif data == "admin_live_send_dm_prompt":
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer()
            action_data = user_action_states.get(user_id)
            if not isinstance(action_data, dict) or not action_data.get("participants"):
                await query.answer("❌ লাইভ মেম্বার তথ্য পাওয়া যায়নি! অনুগ্রহ করে পুনরায় লাইভ স্ক্যান করুন।", show_alert=True)
                return

            real_humans = action_data.get("real_humans") or [p for p in action_data.get("participants", []) if p.get("is_real_human", True)]
            active_humans = action_data.get("active_humans") or [p for p in real_humans if p.get("activity_status") in ("online", "recent")]
            inactive_humans = action_data.get("inactive_humans") or [p for p in real_humans if p.get("activity_status") not in ("online", "recent")]
            with_username = action_data.get("with_username_humans") or [p for p in real_humans if p.get("username")]

            prompt = (
                "🎯 **কাদের কাছে মেসেজ পাঠাতে চান নির্বাচন করুন:**\n\n"
                f"👥 মোট আসল মানুষ (Real Humans): **{len(real_humans)}** জন\n"
                f"🟢 অনলাইন ও রিসেন্ট সক্রিয়: **{len(active_humans)}** জন\n"
                f"⚪ ইনঅ্যাক্টিভ মেম্বার: **{len(inactive_humans)}** জন\n"
                f"🔤 ইউজারনেম (@username) সহ: **{len(with_username)}** জন\n\n"
                "নিচের বাটন থেকে আপনার কাঙ্ক্ষিত অডিয়েন্স বেছে নিন:"
            ) if get_user_lang(user_id) == "bn" else (
                "🎯 **Select Your Target Audience Filter:**\n\n"
                f"👥 Real Humans: **{len(real_humans)}**\n"
                f"🟢 Online / Recent Active: **{len(active_humans)}**\n"
                f"⚪ Inactive Members: **{len(inactive_humans)}**\n"
                f"🔤 With @username Only: **{len(with_username)}**\n\n"
                "Choose target filter below:"
            )
            await query.message.reply_text(
                prompt,
                reply_markup=live_target_filter_keyboard(
                    user_id,
                    len(real_humans),
                    len(active_humans),
                    len(inactive_humans),
                    len(with_username)
                )
            )

        elif data.startswith("btn_lflt_"):
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer()
            filter_type = data.replace("btn_lflt_", "")
            action_data = user_action_states.get(user_id)
            if not isinstance(action_data, dict):
                await query.answer("❌ সেশনের মেয়াদ শেষ হয়েছে। পুনরায় লাইভ স্ক্যান করুন।", show_alert=True)
                return

            real_humans = action_data.get("real_humans", [])
            active_humans = action_data.get("active_humans", [])
            inactive_humans = action_data.get("inactive_humans", [])
            with_username = action_data.get("with_username_humans", [])

            if filter_type == "active":
                chosen_list = active_humans if active_humans else real_humans
                lbl = "🟢 অনলাইন ও রিসেন্ট সক্রিয়"
            elif filter_type == "inactive":
                chosen_list = inactive_humans if inactive_humans else real_humans
                lbl = "⚪ ইনঅ্যাক্টিভ মেম্বার"
            elif filter_type == "username":
                chosen_list = with_username if with_username else real_humans
                lbl = "🔤 @username যুক্ত"
            else:
                chosen_list = real_humans if real_humans else action_data.get("participants", [])
                lbl = "👥 সকল রিয়েল হিউম্যান"

            action_data["participants"] = chosen_list
            action_data["action"] = "AWAITING_LIVE_DM_TEXT"

            prompt = (
                f"🎯 **নির্বাচিত অডিয়েন্স:** {lbl} ({len(chosen_list)} জন)\n\n"
                "✍️ **এবার মেম্বারদের জন্য মেসেজ বা মিডিয়া সেন্ড করুন:**\n\n"
                "• 💬 **টেক্সট মেসেজ:** সাধারণ টেক্সট মেসেজ লিখে পাঠান।\n"
                "• 🖼️ **ফটো বা ভিডিও:** ক্যাপশনসহ যেকোনো ছবি বা ভিডিও সেন্ড করুন।\n"
                "• 🔄 **মাল্টি-অ্যাকাউন্ট রোটেশন:** আপনার কানেক্টেড সব একাউন্ট স্বয়ংক্রিয়ভাবে ভাগ করে নিয়ে পাঠাবে।\n\n"
                "🎲 **স্পিনট্যাক্স সাপোর্ট (Spintax):**\n"
                "প্রতিটি মেম্বারকে আলাদা টেক্সট পাঠাতে `{Hi|Hello|Hey}` ফরম্যাট ব্যবহার করতে পারেন!\n"
                "📌 যেমন: `{Hi|Hello|Hey} {name}, {লাইভটি কেমন লাগছে?|লাইভ স্ট্রিম কেমন হচ্ছে?}`\n\n"
                "💡 **পার্সোনালাইজেশন ট্যাগসমূহ:**\n"
                "• `{name}` - ইউজারের পুরো নাম\n"
                "• `{first_name}` - ইউজারের প্রথম নাম\n"
                "• `{username}` - ইউজারের @ইউজারনেম\n\n"
                "বাতিল করতে `/cancel` লিখুন।"
            ) if get_user_lang(user_id) == "bn" else (
                f"🎯 **Selected Audience:** {lbl} ({len(chosen_list)})\n\n"
                "✍️ **Now send the message text, photo, or video:**\n\n"
                "• 💬 **Text:** Plain text message.\n"
                "• 🖼️ **Photo / Video:** Send with a caption.\n"
                "• 🔄 **Multi-Account Auto Rotation:** Distributed across all connected accounts.\n\n"
                "🎲 **Spintax Supported:**\n"
                "Use `{Hi|Hello|Hey}` format for dynamic variations per attendee!\n"
                "📌 Example: `{Hi|Hello|Hey} {name}, {welcome to our stream!|glad to have you with us!}`\n\n"
                "💡 **Personalization Tags:** `{name}`, `{first_name}`, `{username}`\n\n"
                "Type `/cancel` to cancel."
            )
            await query.message.reply_text(prompt, reply_markup=cancel_keyboard(user_id))

        elif data.startswith("btn_ldm_cnt_"):
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer()
            count = int(data.replace("btn_ldm_cnt_", ""))
            action_data = user_action_states.pop(user_id, None)
            if not isinstance(action_data, dict) or not action_data.get("participants") or not action_data.get("template_text"):
                await query.message.reply_text("❌ সেশনের মেয়াদ শেষ হয়েছে। পুনরায় চেষ্টা করুন।", reply_markup=admin_panel_keyboard(user_id))
                return

            participants = action_data["participants"]
            template_text = action_data["template_text"]
            media_path = action_data.get("media_path")
            media_type = action_data.get("media_type")

            status_msg = await query.message.reply_text(
                f"🚀 **মাল্টি-অ্যাকাউন্ট দিয়ে মেম্বারদের মেসেজ পাঠানো শুরু হচ্ছে...**\nঅ্যাকাউন্টগুলো স্বয়ংক্রিয়ভাবে ভাগ করে নিয়ে নিরাপদ বিরতিতে পাঠাচ্ছে।"
                if get_user_lang(user_id) == "bn" else
                f"🚀 **Dispatching direct messages via multiple accounts in rotation...**\nSafe rate-limiting active."
            )

            res = await manager.send_message_to_live_participants(
                admin_id=user_id,
                participants=participants,
                template_text=template_text,
                media_path=media_path,
                media_type=media_type,
                limit_count=count
            )

            details_str = "\n".join(res.get("details", [])[:15])
            if len(res.get("details", [])) > 15:
                details_str += f"\n...এবং আরও {len(res['details']) - 15} টি"

            fin_text = (
                f"✉️ **মেসেজ পাঠানো সম্পন্ন!**\n\n"
                f"📊 টার্গেট মেম্বার: **{res['total']}** জন\n"
                f"✅ সফল: **{res['success']}** জন\n"
                f"⏩ স্কিপড (প্রাইভেসি): **{res.get('skipped', 0)}** জন\n"
                f"❌ ব্যর্থ: **{res['failed']}** জন\n\n"
                f"📋 **বিস্তারিত রিপোর্ট:**\n{details_str}"
            ) if get_user_lang(user_id) == "bn" else (
                f"✉️ **Direct Messaging Finished!**\n\n"
                f"📊 Target Attendees: **{res['total']}**\n"
                f"✅ Successful: **{res['success']}**\n"
                f"⏩ Skipped (Privacy): **{res.get('skipped', 0)}**\n"
                f"❌ Failed: **{res['failed']}**\n\n"
                f"📋 **Details:**\n{details_str}"
            )
            await status_msg.edit_text(fin_text, reply_markup=admin_panel_keyboard(user_id))

        elif data == "admin_live_discovery_prompt":
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer()
            cur_country = admin_country_preferences.get(user_id, "GLOBAL")
            c_badge = get_country_badge(cur_country, get_user_lang(user_id))
            country_line = f"🌍 কান্ট্রি ফিল্টার: **{c_badge}**\n\n" if cur_country != "GLOBAL" else ""
            prompt = (
                f"📡 **ক্যাটাগরি লাইভ স্ট্রিম স্ক্যানার (Admin Exclusive):**\n\n"
                f"{country_line}"
                "টেলিগ্রামের কোন বিষয়ের সক্রিয় লাইভ চ্যানেল ও গ্রুপগুলো খুঁজতে চান নিচের ক্যাটাগরি থেকে বেছে নিন অথবা কাস্টম সার্চ করুন:"
            ) if get_user_lang(user_id) == "bn" else (
                f"📡 **Category Live Stream Scanner (Admin Exclusive):**\n\n"
                f"{country_line}"
                "Select a category below or use custom keyword search to discover currently running live streams on Telegram:"
            )
            await query.message.edit_text(prompt, reply_markup=live_discovery_categories_keyboard(user_id, cur_country))

        elif data.startswith("admin_change_country_"):
            ret = data.replace("admin_change_country_", "")
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer()
            cur_country = admin_country_preferences.get(user_id, "GLOBAL")
            c_badge = get_country_badge(cur_country, get_user_lang(user_id))
            txt = (
                "🌍 **টার্গেটেড দেশ ফিল্টার নির্বাচন করুন:**\n\n"
                "আপনি কোনো নির্দিষ্ট দেশ বেছে নিলে বট শুধুমাত্র সেই দেশের চ্যানেল ও গ্রুপগুলো ফিল্টার করে আনবে। ফিল্টার বন্ধ রাখতে চাইলে 'ফিল্টার বন্ধ' বেছে নিন।\n\n"
                f"📌 বর্তমান অবস্থা: **{c_badge}**"
            ) if get_user_lang(user_id) == "bn" else (
                "🌍 **Select Target Country Filter:**\n\n"
                "Filter groups & live streams specifically for a selected country, or turn off to search globally.\n\n"
                f"📌 Current Status: **{c_badge}**"
            )
            await query.message.edit_text(txt, reply_markup=country_selector_keyboard(user_id, cur_country, return_to=ret))

        elif data.startswith("admin_set_country_"):
            parts = data.split("_")
            if len(parts) >= 5:
                code = parts[3]
                ret = parts[4]
            else:
                code = "GLOBAL"
                ret = "live"

            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return

            admin_country_preferences[user_id] = code
            badge = get_country_badge(code, get_user_lang(user_id))
            if code == "GLOBAL":
                ans_text = "🌐 ফিল্টার বন্ধ (সকল দেশ উন্মুক্ত)" if get_user_lang(user_id) == "bn" else "🌐 Filter Off (All Countries)"
            else:
                ans_text = f"✅ ফিল্টার সক্রিয়: {badge}" if get_user_lang(user_id) == "bn" else f"✅ Filter Active: {badge}"
            await query.answer(ans_text, show_alert=False)

            country_line = f"🌍 কান্ট্রি ফিল্টার: **{badge}**\n\n" if code != "GLOBAL" else ""
            if ret == "grp":
                prompt = (
                    f"🔥 **ক্যাটাগরি অ্যাক্টিভ গ্রুপ ও চ্যানেল স্ক্যানার (Admin Exclusive):**\n\n"
                    f"{country_line}"
                    "টেলিগ্রামের কোন বিষয়ের সক্রিয় গ্রুপগুলো খুঁজতে চান নিচের ক্যাটাগরি থেকে বেছে নিন অথবা কাস্টম সার্চ করুন:\n"
                    "*(বট প্রতিটি গ্রুপের মোট মেম্বার ও রিয়েল-টাইম অনলাইন মেম্বার সংখ্যা বের করে দেবে)*"
                ) if get_user_lang(user_id) == "bn" else (
                    f"🔥 **Category Active Groups & Channels Scanner (Admin Exclusive):**\n\n"
                    f"{country_line}"
                    "Select a category below to discover active groups on Telegram sorted by online member counts:"
                )
                await query.message.edit_text(prompt, reply_markup=group_discovery_categories_keyboard(user_id, code))
            else:
                prompt = (
                    f"📡 **ক্যাটাগরি লাইভ স্ট্রিম স্ক্যানার (Admin Exclusive):**\n\n"
                    f"{country_line}"
                    "টেলিগ্রামের কোন বিষয়ের সক্রিয় লাইভ চ্যানেল ও গ্রুপগুলো খুঁজতে চান নিচের ক্যাটাগরি থেকে বেছে নিন অথবা কাস্টম সার্চ করুন:"
                ) if get_user_lang(user_id) == "bn" else (
                    f"📡 **Category Live Stream Scanner (Admin Exclusive):**\n\n"
                    f"{country_line}"
                    "Select a category below or use custom keyword search to discover currently running live streams on Telegram:"
                )
                await query.message.edit_text(prompt, reply_markup=live_discovery_categories_keyboard(user_id, code))

        elif data.startswith("admin_cat_live_"):
            cat = data.replace("admin_cat_live_", "")
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            if cat == "joined_dialogs":
                await execute_dialog_live_discovery(user_id, query.message)
                return

            if cat == "custom":
                user_action_states[user_id] = {"action": "AWAITING_CUSTOM_LIVE_SEARCH"}
                msg = (
                    "🔍 **কাস্টম কীওয়ার্ড দিয়ে লাইভ খুঁজুন (একাধিক কীওয়ার্ড সাপোর্ট):**\n\n"
                    "আপনি চাইলে একসাথে একাধিক বা যেকোনো সংখ্যক কীওয়ার্ড কমা (`,`) অথবা নতুন লাইনে লিখে পাঠাতে পারেন!\n\n"
                    "📌 **উদাহরণ:**\n"
                    "`forex, crypto, trading, binance, signals, btc`\n\n"
                    "💡 বট সবগুলো কীওয়ার্ড একসাথে স্ক্যান করে চলমান সব লাইভ স্ট্রিম এনে দেবে।\n"
                    "বাতিল করতে `/cancel` লিখুন।"
                ) if get_user_lang(user_id) == "bn" else (
                    "🔍 **Enter Custom Keyword(s) (Bulk Supported):**\n\n"
                    "You can enter multiple keywords separated by commas (`,`) or newlines:\n\n"
                    "📌 **Example:**\n"
                    "`forex, crypto, binance, trading, signals`\n\n"
                    "Type `/cancel` to cancel."
                )
                await query.message.reply_text(msg, reply_markup=cancel_keyboard(user_id))
                return

            keyword_map = {
                "trading": "trading forex signals",
                "crypto": "crypto binance bitcoin",
                "gaming": "gaming esports live",
                "community": "talk chat discussion voice"
            }
            search_query = keyword_map.get(cat, cat)
            await execute_live_discovery(user_id, search_query, query.message)

        elif data == "admin_group_discovery_prompt":
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer()
            cur_country = admin_country_preferences.get(user_id, "GLOBAL")
            c_badge = get_country_badge(cur_country, get_user_lang(user_id))
            country_line = f"🌍 কান্ট্রি ফিল্টার: **{c_badge}**\n\n" if cur_country != "GLOBAL" else ""
            prompt = (
                f"🔥 **ক্যাটাগরি অ্যাক্টিভ গ্রুপ ও চ্যানেল স্ক্যানার (Admin Exclusive):**\n\n"
                f"{country_line}"
                "টেলিগ্রামের কোন বিষয়ের সক্রিয় গ্রুপগুলো খুঁজতে চান নিচের ক্যাটাগরি থেকে বেছে নিন অথবা কাস্টম সার্চ করুন:\n"
                "*(বট প্রতিটি গ্রুপের মোট মেম্বার ও রিয়েল-টাইম অনলাইন মেম্বার সংখ্যা বের করে দেবে)*"
            ) if get_user_lang(user_id) == "bn" else (
                f"🔥 **Category Active Groups & Channels Scanner (Admin Exclusive):**\n\n"
                f"{country_line}"
                "Select a category below to discover active groups on Telegram sorted by online member counts:"
            )
            await query.message.edit_text(prompt, reply_markup=group_discovery_categories_keyboard(user_id, cur_country))

        elif data.startswith("admin_cat_grp_"):
            cat = data.replace("admin_cat_grp_", "")
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer()
            if cat == "custom":
                user_action_states[user_id] = {"action": "AWAITING_CUSTOM_GROUP_SEARCH"}
                msg = (
                    "🔍 **কাস্টম কীওয়ার্ড দিয়ে গ্রুপ খুঁজুন (একাধিক কীওয়ার্ড সাপোর্ট):**\n\n"
                    "আপনি চাইলে একসাথে একাধিক বা যেকোনো সংখ্যক কীওয়ার্ড কমা (`,`) অথবা নতুন লাইনে লিখে পাঠাতে পারেন!\n\n"
                    "📌 **উদাহরণ:**\n"
                    "`forex signals, crypto trade, binance community, scalping bd`\n\n"
                    "💡 বট সবগুলো কীওয়ার্ডের সক্রিয় গ্রুপ ও চ্যানেল একসাথে স্ক্যান করে নিয়ে আসবে।\n"
                    "বাতিল করতে `/cancel` লিখুন।"
                ) if get_user_lang(user_id) == "bn" else (
                    "🔍 **Enter Custom Group Keyword(s) (Bulk Supported):**\n\n"
                    "You can enter multiple keywords separated by commas (`,`) or newlines:\n\n"
                    "📌 **Example:**\n"
                    "`forex signals, crypto trading, binance scalping`\n\n"
                    "Type `/cancel` to cancel."
                )
                await query.message.reply_text(msg, reply_markup=cancel_keyboard(user_id))
                return

            keyword_map = {
                "trading": "trading forex signals group",
                "crypto": "crypto binance discussion",
                "gaming": "gaming esports discord telegram",
                "community": "chat community discussion public"
            }
            search_query = keyword_map.get(cat, cat)
            await execute_group_discovery(user_id, search_query, query.message)

        elif data.startswith("admin_insp_grp_"):
            target_str = data.replace("admin_insp_grp_", "")
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer("⏳ গ্রুপের অ্যাক্টিভ মেম্বার স্ক্যান করা হচ্ছে...", show_alert=False)
            status_msg = await query.message.reply_text(f"⏳ **{target_str} এর অ্যাক্টিভ মেম্বার তালিকা সংগ্রহ করা হচ্ছে...**")
            res = await manager.inspect_chat_active_members(user_id, target_str)
            if not res.get("success"):
                await status_msg.edit_text(f"❌ {res.get('error', 'Error')}", reply_markup=admin_panel_keyboard(user_id))
                return

            ch_title = res.get("chat_title", "Group")
            ch_user = f" (@{res['chat_username']})" if res.get("chat_username") else ""
            tot = res.get("total_count", 0)
            real_humans = res.get("real_humans", [])
            active_humans = res.get("active_humans", [])
            inactive_humans = res.get("inactive_humans", [])
            with_username = res.get("with_username_humans", [])
            bots = res.get("bots_and_channels", [])
            export_file = res.get("export_file")

            active_txt = ""
            for idx, a in enumerate(active_humans[:20], 1):
                u_part = f"@{a['username']}" if a.get("username") else "No @user"
                active_txt += f"  {idx}. {a.get('status_label', '')} **{a['name']}** ({u_part})\n"
            if not active_txt:
                active_txt = "  *(কোনো অনলাইন মেম্বার পাওয়া যায়নি)*\n"
            elif len(active_humans) > 20:
                active_txt += f"  *...এবং আরও {len(active_humans) - 20} জন সক্রিয় মেম্বার*\n"

            report = (
                f"👥 **গ্রুপ অ্যাক্টিভ মেম্বার ইন্সপেকশন রিপোর্ট:**\n\n"
                f"📢 গ্রুপ: **{ch_title}**{ch_user}\n"
                f"👥 মোট মেম্বার: **{tot}** জন\n"
                f"👤 **আসল মানুষ (Real Humans): {len(real_humans)} জন**\n"
                f"   ├ 🟢 অনলাইন/রিসেন্ট সক্রিয়: **{len(active_humans)}** জন 🔥\n"
                f"   ├ ⚪ ইনঅ্যাক্টিভ: **{len(inactive_humans)}** জন\n"
                f"   └ 🔤 @username সহ: **{len(with_username)}** জন\n"
                f"🤖 ফিল্টার্ড (বট/ডিলিটেড): **{len(bots)}** টি\n\n"
                f"🟢 **শীর্ষ সক্রিয় মেম্বারদের তালিকা:**\n"
                f"{active_txt}\n"
                f"📁 *সম্পূর্ণ মেম্বার লিস্ট ও সকল ইউজারনেম নিচে ফাইল আকারে পাঠানো হলো:*"
            )

            user_action_states[user_id] = {
                "action": "INSPECTED_LIVE_RESULT",
                "participants": res.get("participants", []),
                "real_humans": real_humans,
                "active_humans": active_humans,
                "inactive_humans": inactive_humans,
                "with_username_humans": with_username,
                "chat_title": ch_title
            }
            await status_msg.edit_text(report, reply_markup=live_inspection_action_keyboard(user_id))

            if export_file and os.path.exists(export_file):
                try:
                    await query.message.reply_document(
                        document=export_file,
                        caption=f"📋 **{ch_title}** এর সকল গ্রুপ মেম্বার ও @username তালিকা।"
                    )
                except Exception as de:
                    logger.warning(f"Could not send export file: {de}")

        elif data.startswith("admin_insp_quick_"):
            target_str = data.replace("admin_insp_quick_", "")
            if not is_admin(user_id):
                await query.answer("Unauthorized", show_alert=True)
                return
            await query.answer("⏳ লাইভ মেম্বার স্ক্যান করা হচ্ছে...", show_alert=False)
            status_msg = await query.message.reply_text(f"⏳ **{target_str} এর লাইভ মেম্বার স্ক্যান করা হচ্ছে...**")
            res = await manager.inspect_live_stream(user_id, target_str)
            if not res.get("success"):
                await status_msg.edit_text(f"❌ {res.get('error', 'Error')}", reply_markup=admin_panel_keyboard(user_id))
                return

            ch_title = res.get("chat_title", "Live Stream")
            ch_user = f" (@{res['chat_username']})" if res.get("chat_username") else ""
            tot = res.get("total_count", 0)
            speakers = res.get("speakers", [])
            listeners = res.get("listeners", [])
            export_file = res.get("export_file")

            speakers_txt = ""
            for idx, s in enumerate(speakers[:15], 1):
                u_part = f"@{s['username']}" if s.get("username") else "No @user"
                speakers_txt += f"  {idx}. **{s['name']}** ({u_part})\n"
            if not speakers:
                speakers_txt = "  *(কোনো সক্রিয় স্পিকার নেই)*\n"
            elif len(speakers) > 15:
                speakers_txt += f"  *...এবং আরও {len(speakers) - 15} জন*\n"

            listeners_txt = ""
            for idx, l in enumerate(listeners[:20], 1):
                u_part = f"@{l['username']}" if l.get("username") else "No @user"
                listeners_txt += f"  {idx}. **{l['name']}** ({u_part})\n"
            if not listeners:
                listeners_txt = "  *(কোনো শ্রোতা পাওয়া যায়নি)*\n"
            elif len(listeners) > 20:
                listeners_txt += f"  *...এবং আরও {len(listeners) - 20} জন*\n"

            real_humans = res.get("real_humans", [])
            active_humans = res.get("active_humans", [])
            inactive_humans = res.get("inactive_humans", [])
            with_username = res.get("with_username_humans", [])
            bots = res.get("bots_and_channels", [])

            report = (
                f"🎙️ **লাইভ মেম্বার ইন্সপেকশন রিপোর্ট:**\n\n"
                f"📢 চ্যানেল/গ্রুপ: **{ch_title}**{ch_user}\n"
                f"👥 মোট লাইভ মেম্বার: **{tot}** জন\n"
                f"👤 **আসল মানুষ (Real Humans): {len(real_humans)} জন**\n"
                f"   ├ 🟢 অনলাইন/রিসেন্ট: **{len(active_humans)}** জন\n"
                f"   ├ ⚪ ইনঅ্যাক্টিভ: **{len(inactive_humans)}** জন\n"
                f"   └ 🔤 @username সহ: **{len(with_username)}** জন\n"
                f"🤖 ফিল্টার্ড (বট/চ্যানেল): **{len(bots)}** টি\n\n"
                f"🎤 **স্পিকার তালিকা ({len(speakers)} জন):**\n"
                f"{speakers_txt}\n"
                f"🎧 **শ্রোতাদের তালিকা (শীর্ষ ২০ জন):**\n"
                f"{listeners_txt}\n"
                f"📁 *সম্পূর্ণ মেম্বার লিস্ট ও সকল ইউজারনেম নিচে ফাইল আকারে পাঠানো হলো:*"
            )

            user_action_states[user_id] = {
                "action": "INSPECTED_LIVE_RESULT",
                "participants": res.get("participants", []),
                "real_humans": real_humans,
                "active_humans": active_humans,
                "inactive_humans": inactive_humans,
                "with_username_humans": with_username,
                "chat_title": ch_title
            }
            await status_msg.edit_text(report, reply_markup=live_inspection_action_keyboard(user_id))

            if export_file and os.path.exists(export_file):
                try:
                    await query.message.reply_document(
                        document=export_file,
                        caption=f"📋 **{ch_title}** এর সকল লাইভ মেম্বার ও @username তালিকা।"
                    )
                except Exception as de:
                    logger.warning(f"Could not send export file: {de}")

    @bot.on_message(filters.channel)
    async def on_channel_post_listener(_, message: Message):
        """Catches real-time channel posts if master bot is added to the channel."""
        if not message.chat:
            return
        chat_id = message.chat.id
        for mon in get_all_active_monitors():
            if mon.get("channel_id") == chat_id:
                if message.id > mon.get("last_msg_id", 0):
                    from core.auto_monitor import update_monitor_progress
                    update_monitor_progress(mon["id"], message.id, increment_posts=0)
                    asyncio.create_task(manager.process_auto_channel_post(mon, chat_id, message.id, bot))
