const usernameInput = document.querySelector('#botUsername');
const formMessage = document.querySelector('#formMessage');
const toast = document.querySelector('#toast');
const savedUsername = localStorage.getItem('livepilot-bot-username') || '';

usernameInput.value = savedUsername;
document.querySelector('#year').textContent = new Date().getFullYear();

async function loadServiceStatus() {
  try {
    const response = await fetch('/api/status', { headers: { Accept: 'application/json' } });
    if (!response.ok) throw new Error('Status unavailable');
    const status = await response.json();
    const servicePill = document.querySelector('.status-pill');
    if (status.state === 'online') {
      servicePill.innerHTML = '<i></i> Service online';
      if (!usernameInput.value && status.bot_username) usernameInput.value = status.bot_username;
    } else {
      servicePill.innerHTML = '<i></i> Service starting';
    }
  } catch (_) {
    // Static preview remains useful when the dashboard is opened outside the bot host.
  }
}

loadServiceStatus();

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  window.clearTimeout(window.toastTimer);
  window.toastTimer = window.setTimeout(() => toast.classList.remove('show'), 3200);
}

function normaliseUsername(value) {
  return value.trim().replace(/^@/, '').replace(/[^a-zA-Z0-9_]/g, '');
}

document.querySelector('#botForm').addEventListener('submit', (event) => {
  event.preventDefault();
  const username = normaliseUsername(usernameInput.value);
  usernameInput.value = username;
  if (!username) {
    localStorage.removeItem('livepilot-bot-username');
    formMessage.textContent = 'Saved link cleared from this browser.';
    showToast('Bot link cleared.');
    return;
  }
  localStorage.setItem('livepilot-bot-username', username);
  formMessage.textContent = `@${username} is ready to open from this browser.`;
  showToast(`Saved @${username}.`);
});

document.querySelectorAll('[data-open-bot]').forEach((button) => {
  button.addEventListener('click', () => {
    const username = normaliseUsername(usernameInput.value || localStorage.getItem('livepilot-bot-username') || '');
    if (!username) {
      document.querySelector('#settings').scrollIntoView({ behavior: 'smooth', block: 'center' });
      usernameInput.focus();
      showToast('Add your Telegram bot username first.');
      return;
    }
    window.open(`https://t.me/${username}`, '_blank', 'noopener,noreferrer');
  });
});

document.querySelector('#refreshButton').addEventListener('click', (event) => {
  const button = event.currentTarget;
  button.querySelector('span').style.display = 'inline-block';
  button.querySelector('span').animate([{ transform: 'rotate(0deg)' }, { transform: 'rotate(360deg)' }], { duration: 600 });
  loadServiceStatus();
  showToast('Service status refreshed.');
});

document.querySelector('#themeToggle').addEventListener('click', () => {
  document.body.classList.toggle('light');
  localStorage.setItem('livepilot-theme', document.body.classList.contains('light') ? 'light' : 'dark');
});

if (localStorage.getItem('livepilot-theme') === 'light') document.body.classList.add('light');

document.querySelectorAll('.nav-link[data-section]').forEach((link) => {
  link.addEventListener('click', () => {
    document.querySelectorAll('.nav-link[data-section]').forEach((item) => item.classList.remove('active'));
    link.classList.add('active');
    document.querySelector('#pageTitle').textContent = link.textContent.replace(/\d+/g, '').trim();
    document.querySelector('#sidebar').classList.remove('open');
    document.querySelector('#menuButton').setAttribute('aria-expanded', 'false');
  });
});

document.querySelector('#menuButton').addEventListener('click', () => {
  const sidebar = document.querySelector('#sidebar');
  sidebar.classList.toggle('open');
  document.querySelector('#menuButton').setAttribute('aria-expanded', sidebar.classList.contains('open'));
});
