# LivePilot web UI

This folder is a dependency-free, responsive dashboard designed for the existing Python bot process.

## Deploy to the hosting panel

Upload the project to the panel, then start it as usual with `python main.py`. The bot automatically serves this dashboard from the panel's assigned port. Pterodactyl-style panels usually provide that port as `SERVER_PORT`; other providers may use `PORT`.

Open the server's **Network** or **Open in Browser** address in the panel. The paths below are available:

- `/` — dashboard
- `/health` — simple health response for the panel
- `/api/status` — safe, read-only service status for the dashboard

The dashboard deliberately does not store Telegram credentials, phone numbers, OTPs, or session strings. It only saves an optional bot username in the visitor's browser so the **Open Telegram bot** button can open `t.me/<bot-username>`.

## Connecting live data

The current dashboard cards are preview content; the service-status badge and bot username are read from the running backend. Additional read-only metrics can be added to `/api/status` later without exposing sensitive session data.
