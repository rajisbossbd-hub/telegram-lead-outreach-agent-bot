import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
import config

logger = logging.getLogger("AutoMonitor")

DATA_FILE = config.SESSIONS_DIR / "auto_channel_monitors.json"

POSITIVE_REACTIONS = [
    "👍", "❤️", "🔥", "🥰", "👏", "🎉", "🤩", "⚡", "😍", "💯"
]

def _load_data() -> dict:
    if not DATA_FILE.exists():
        return {"monitors": []}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Error loading auto channel monitors: {e}")
        return {"monitors": []}

def _save_data(data: dict):
    try:
        DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        logger.error(f"Error saving auto channel monitors: {e}")

def get_user_monitors(user_id: int) -> List[dict]:
    """Returns all channel monitors created by a user."""
    data = _load_data()
    return [m for m in data.get("monitors", []) if m.get("user_id") == user_id]

def get_monitor_by_id(monitor_id: str) -> Optional[dict]:
    """Finds a monitor by its unique ID."""
    data = _load_data()
    for m in data.get("monitors", []):
        if m.get("id") == monitor_id:
            return m
    return None

def get_all_active_monitors() -> List[dict]:
    """Returns all active monitors across all users."""
    data = _load_data()
    return [m for m in data.get("monitors", []) if m.get("is_active", True)]

def add_channel_monitor(
    user_id: int,
    channel_id: int,
    channel_title: str,
    channel_username: str,
    views_count: int,
    reaction_mode: str,
    specific_emoji: Optional[str] = None,
    last_msg_id: int = 0,
    invite_link: str = ""
) -> dict:
    """Adds or updates a channel monitor for a user."""
    data = _load_data()
    monitors = data.get("monitors", [])

    # Check if this user already monitors this channel
    existing = None
    for m in monitors:
        if m.get("user_id") == user_id and m.get("channel_id") == channel_id:
            existing = m
            break

    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    if existing:
        existing["channel_title"] = channel_title
        existing["channel_username"] = channel_username
        existing["views_count"] = views_count
        existing["reaction_mode"] = reaction_mode
        existing["specific_emoji"] = specific_emoji
        existing["is_active"] = True
        if invite_link:
            existing["invite_link"] = invite_link
        if last_msg_id > existing.get("last_msg_id", 0):
            existing["last_msg_id"] = last_msg_id
        existing["updated_at"] = now_str
        _save_data(data)
        return existing
    else:
        monitor_id = f"mon_{user_id}_{abs(channel_id)}"
        new_mon = {
            "id": monitor_id,
            "user_id": user_id,
            "channel_id": channel_id,
            "channel_title": channel_title,
            "channel_username": channel_username,
            "invite_link": invite_link,
            "views_count": max(1, views_count),
            "reaction_mode": reaction_mode,  # "RANDOM_POSITIVE", "SPECIFIC", or "NONE"
            "specific_emoji": specific_emoji,
            "is_active": True,
            "last_msg_id": last_msg_id,
            "total_posts_boosted": 0,
            "created_at": now_str,
            "updated_at": now_str
        }
        monitors.append(new_mon)
        data["monitors"] = monitors
        _save_data(data)
        return new_mon

def toggle_monitor_status(monitor_id: str, user_id: int) -> Optional[bool]:
    """Toggles active/paused status of a monitor. Returns new status or None."""
    data = _load_data()
    for m in data.get("monitors", []):
        if m.get("id") == monitor_id and m.get("user_id") == user_id:
            m["is_active"] = not m.get("is_active", True)
            m["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            _save_data(data)
            return m["is_active"]
    return None

def delete_monitor(monitor_id: str, user_id: int) -> bool:
    """Deletes a monitor configuration."""
    data = _load_data()
    monitors = data.get("monitors", [])
    init_len = len(monitors)
    monitors = [m for m in monitors if not (m.get("id") == monitor_id and m.get("user_id") == user_id)]
    if len(monitors) < init_len:
        data["monitors"] = monitors
        _save_data(data)
        return True
    return False

def update_monitor_reaction(monitor_id: str, user_id: int, reaction_mode: str, specific_emoji: Optional[str] = None) -> bool:
    """Updates the reaction mode and specific emoji of an existing monitor."""
    data = _load_data()
    for m in data.get("monitors", []):
        if m.get("id") == monitor_id and m.get("user_id") == user_id:
            m["reaction_mode"] = reaction_mode
            m["specific_emoji"] = specific_emoji
            m["updated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            _save_data(data)
            return True
    return False

def update_monitor_progress(monitor_id: str, last_msg_id: int, increment_posts: int = 1):
    """Updates the last seen post ID and increments total boosted posts."""
    data = _load_data()
    for m in data.get("monitors", []):
        if m.get("id") == monitor_id:
            if last_msg_id > m.get("last_msg_id", 0):
                m["last_msg_id"] = last_msg_id
            m["total_posts_boosted"] = m.get("total_posts_boosted", 0) + increment_posts
            m["last_boosted_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            _save_data(data)
            break

def delete_all_user_monitors(user_id: int) -> int:
    """Deletes all monitors owned by a user. Returns count of deleted monitors."""
    data = _load_data()
    monitors = data.get("monitors", [])
    init_len = len(monitors)
    monitors = [m for m in monitors if m.get("user_id") != user_id]
    count = init_len - len(monitors)
    if count > 0:
        data["monitors"] = monitors
        _save_data(data)
    return count

def toggle_all_user_monitors(user_id: int, activate: bool) -> int:
    """Activates or pauses all monitors owned by a user. Returns count of updated monitors."""
    data = _load_data()
    updated = 0
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for m in data.get("monitors", []):
        if m.get("user_id") == user_id:
            m["is_active"] = activate
            m["updated_at"] = now_str
            updated += 1
    if updated > 0:
        _save_data(data)
    return updated
