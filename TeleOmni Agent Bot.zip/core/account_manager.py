import asyncio
import re
import random
import logging
from pathlib import Path
from typing import Dict, List, Optional, Union
from pyrogram import Client
from pyrogram.errors import SessionPasswordNeeded, PhoneCodeInvalid, PhoneCodeExpired, PasswordHashInvalid
import config
from core.session_store import (
    load_accounts_registry,
    save_accounts_registry,
    add_account_metadata,
    remove_account_metadata,
    get_user_accounts_registry
)
from core.call_engine import AccountCallEngine

logger = logging.getLogger(__name__)

COUNTRY_CONFIGS = {
    "BD": {
        "name": "বাংলাদেশ 🇧🇩",
        "flag": "🇧🇩",
        "keywords": ["bd", "bangladesh", "bangla", "বাংলা", "বাংলাদেশ", "dhaka", "chittagong", "bdt", "বিডি"],
        "script_regex": r"[\u0980-\u09FF]",
    },
    "IN": {
        "name": "ভারত 🇮🇳",
        "flag": "🇮🇳",
        "keywords": ["india", "indian", "hindi", "bharat", "हिन्दी", "भारत"],
        "script_regex": r"[\u0900-\u097F]",
    },
    "PK": {
        "name": "পাকিস্তান 🇵🇰",
        "flag": "🇵🇰",
        "keywords": ["pk", "pakistan", "pakistani", "urdu", "اردو", "پاکستان"],
        "script_regex": r"[\u0600-\u06FF]",
    },
    "US": {
        "name": "USA 🇺🇸",
        "flag": "🇺🇸",
        "keywords": ["usa", "us", "america", "united states", "nyc"],
        "script_regex": None,
    },
    "GLOBAL": {
        "name": "সকল দেশ 🌐",
        "flag": "🌐",
        "keywords": [],
        "script_regex": None,
    }
}

def match_chat_country(title: str, username: Optional[str] = None, country_code: str = "GLOBAL") -> bool:
    """Checks if a chat/channel matches the targeted country by inspecting title, username,
    and native language script."""
    if not country_code or country_code.upper() == "GLOBAL":
        return True

    cfg = COUNTRY_CONFIGS.get(country_code.upper())
    if not cfg:
        return True

    text_to_check = f"{title or ''} {username or ''}".lower()

    # 1. Native script detection (e.g. Bengali Unicode characters)
    script_re = cfg.get("script_regex")
    if script_re and re.search(script_re, text_to_check):
        return True

    # 2. Country keyword/location tag matching
    for kw in cfg.get("keywords", []):
        pattern = r"(?:^|[\s_#@\(\)\[\]\-\.\/])" + re.escape(kw.lower()) + r"(?:$|[\s_#@\(\)\[\]\-\.\/])"
        if re.search(pattern, text_to_check):
            return True
        if kw.lower() in (username or "").lower():
            return True

    return False

def parse_spintax(text: str) -> str:
    """Parses Spintax syntax like {Hello|Hi|Hey} {bro|friend}, supporting nested patterns
    while ignoring standard placeholders like {name} or {username}."""
    if not text or "{" not in text or "}" not in text:
        return text
    # Match innermost {option1|option2|...} containing at least one pipe '|'
    pattern = re.compile(r"\{([^{}]*\|[^{}]*)\}")
    for _ in range(10):
        match = pattern.search(text)
        if not match:
            break
        choices = match.group(1).split("|")
        chosen = random.choice(choices)
        text = text[:match.start()] + chosen + text[match.end():]
    return text

def extract_invite_hash(link_or_hash: str) -> Optional[str]:
    """Extracts the invite hash from any format: https://t.me/+hash, joinchat/hash, or +hash."""
    if not link_or_hash:
        return None
    clean = str(link_or_hash).strip()
    if clean.startswith("+"):
        return clean[1:]
    m = re.search(r"(?:joinchat/|\+)([\w-]+)", clean)
    if m:
        return m.group(1)
    return None

async def safe_join_or_get_chat(client: Client, target: Union[str, int]):
    """Joins a chat if needed, or safely resolves and retrieves the chat object if the user
    is already a member (USER_ALREADY_PARTICIPANT). Handles invite links (+hash, joinchat),
    usernames, and IDs without error."""
    from pyrogram.errors import UserAlreadyParticipant
    from pyrogram.raw import functions, types as raw_types
    from pyrogram import utils, types

    target_str = str(target).strip()
    invite_hash = extract_invite_hash(target_str)

    if invite_hash:
        full_invite = f"https://t.me/+{invite_hash}"
        try:
            return await client.join_chat(full_invite)
        except UserAlreadyParticipant:
            # User is already a participant of this chat
            try:
                check = await client.invoke(functions.messages.CheckChatInvite(hash=invite_hash))
                raw_chat = getattr(check, "chat", None)
                if raw_chat:
                    if isinstance(raw_chat, (raw_types.Channel, raw_types.ChannelForbidden)):
                        cid = utils.get_channel_id(raw_chat.id)
                    else:
                        cid = -raw_chat.id
                    try:
                        return await client.get_chat(cid)
                    except Exception:
                        if isinstance(raw_chat, raw_types.Channel):
                            return types.Chat._parse_channel_chat(client, raw_chat)
                        elif isinstance(raw_chat, raw_types.Chat):
                            return types.Chat._parse_chat_chat(client, raw_chat)
            except Exception as ie:
                logger.debug(f"CheckChatInvite fallback failed for hash {invite_hash}: {ie}")

            # Dialogs fallback: scan recent dialogs for this invite link or matching chat
            try:
                async for dialog in client.get_dialogs(limit=100):
                    d_chat = dialog.chat
                    if getattr(d_chat, "invite_link", None) == full_invite:
                        return d_chat
            except Exception:
                pass

            # Final attempt: try get_dialogs top dialogs
            async for dialog in client.get_dialogs(limit=20):
                if dialog.chat:
                    return dialog.chat

            raise UserAlreadyParticipant("Already a participant of this chat")
    else:
        try:
            return await client.join_chat(target)
        except UserAlreadyParticipant:
            return await client.get_chat(target)
        except Exception:
            return await client.get_chat(target)

class AccountManager:
    def __init__(self):
        self.engines: Dict[str, AccountCallEngine] = {}

    async def initialize(self):
        """Loads and initializes all saved accounts."""
        registry = load_accounts_registry()
        logger.info(f"Loading {len(registry)} saved accounts across all users...")

        for session_name, info in registry.items():
            try:
                owner_id = info.get("owner_id", 0)
                session_str = info.get("session_string")
                if session_str:
                    client = Client(
                        name=session_name,
                        api_id=config.API_ID,
                        api_hash=config.API_HASH,
                        session_string=session_str,
                        in_memory=True
                    )
                else:
                    client = Client(
                        name=session_name,
                        api_id=config.API_ID,
                        api_hash=config.API_HASH,
                        workdir=str(config.SESSIONS_DIR)
                    )

                engine = AccountCallEngine(client, session_name, owner_id=owner_id)
                await engine.start()
                self.engines[session_name] = engine
                logger.info(f"Account {session_name} (Owner: {owner_id}) loaded.")
            except Exception as e:
                logger.error(f"Failed to load account {session_name}: {e}")

    def get_user_engines(self, owner_id: int) -> Dict[str, AccountCallEngine]:
        """Returns engines belonging only to a specific owner."""
        return {k: v for k, v in self.engines.items() if v.owner_id == owner_id}

    async def join_for_user(self, owner_id: int, chat_target: str, count: Optional[int] = None, progress_callback=None) -> dict:
        """Joins only the accounts belonging to this specific user.
        Normal (Free) users are capped at max 5 accounts per live stream. VIP users are unlimited."""
        from core.subscription import is_vip, FREE_LIVE_ACCOUNT_LIMIT
        all_user_engines = list(self.get_user_engines(owner_id).items())

        if not is_vip(owner_id):
            max_allowed = FREE_LIVE_ACCOUNT_LIMIT
            if count and count > 0:
                user_engines = all_user_engines[:min(count, max_allowed)]
            else:
                user_engines = all_user_engines[:max_allowed]
        else:
            if count and count > 0:
                user_engines = all_user_engines[:count]
            else:
                user_engines = all_user_engines

        total = len(user_engines)
        if total == 0:
            return {"total": 0, "success": 0, "failed": 0, "details": []}

        success = 0
        failed = 0
        details = []

        user_registry = get_user_accounts_registry(owner_id)
        for idx, (session_name, engine) in enumerate(user_engines, start=1):
            meta = user_registry.get(session_name, {})
            acc_label = meta.get("first_name") or meta.get("username") or f"Account #{idx}"
            if meta.get("username"):
                acc_label = f"@{meta['username']}"
            try:
                res = await engine.join_live(chat_target)
                if res.get("success"):
                    success += 1
                    details.append(f"✅ {acc_label}: Joined")
                else:
                    failed += 1
                    details.append(f"❌ {acc_label}: {res.get('error')}")
            except Exception as e:
                failed += 1
                details.append(f"❌ {acc_label}: {str(e)}")

            if progress_callback and (idx % 2 == 0 or idx == total):
                try:
                    await progress_callback(idx, total, success, failed)
                except Exception:
                    pass

            if idx < total:
                await asyncio.sleep(config.JOIN_DELAY)

        return {
            "total": total,
            "success": success,
            "failed": failed,
            "details": details
        }

    async def leave_for_user(self, owner_id: int) -> dict:
        """Disconnects only this user's accounts from voice chats."""
        user_engines = self.get_user_engines(owner_id)
        if not user_engines:
            return {"total": 0, "success": 0}

        tasks = [engine.leave_call() for engine in user_engines.values()]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        success = sum(1 for r in results if isinstance(r, dict) and r.get("success"))

        return {
            "total": len(user_engines),
            "success": success
        }

    async def add_string_session(self, session_string: str, owner_id: int) -> dict:
        """Adds and tests a new account via Pyrogram session string for a specific owner."""
        try:
            client = Client(
                name="temp_str_acc",
                api_id=config.API_ID,
                api_hash=config.API_HASH,
                session_string=session_string,
                in_memory=True
            )
            await client.start()
            me = await client.get_me()
            session_name = f"user_{owner_id}_{me.id}"

            add_account_metadata(
                session_name=session_name,
                user_id=me.id,
                first_name=me.first_name,
                owner_id=owner_id,
                phone=me.phone_number or "",
                username=me.username or "",
                session_string=session_string
            )

            engine = AccountCallEngine(client, session_name, owner_id=owner_id)
            await engine.pytgcalls.start()
            engine.is_connected = True
            self.engines[session_name] = engine

            return {"success": True, "name": me.first_name, "id": me.id, "phone": me.phone_number}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def remove_account(self, session_name: str, owner_id: int) -> bool:
        """Stops and deletes an account if the requester is the owner."""
        user_engines = self.get_user_engines(owner_id)
        if session_name not in user_engines and owner_id not in config.ADMIN_IDS:
            return False

        if session_name in self.engines:
            engine = self.engines[session_name]
            await engine.stop()
            del self.engines[session_name]

        remove_account_metadata(session_name, owner_id=None if owner_id in config.ADMIN_IDS else owner_id)

        session_file = config.SESSIONS_DIR / f"{session_name}.session"
        if session_file.exists():
            try:
                session_file.unlink()
            except Exception:
                pass
        return True

    def get_user_accounts_list(self, owner_id: int) -> List[dict]:
        """Returns overview of accounts belonging exclusively to this owner."""
        user_registry = get_user_accounts_registry(owner_id)
        user_engines = self.get_user_engines(owner_id)
        accounts = []

        for name, engine in user_engines.items():
            meta = user_registry.get(name, {})
            username = meta.get("username", "")
            if not username and getattr(engine, "client", None) and getattr(engine.client, "me", None):
                username = getattr(engine.client.me, "username", "") or ""
            accounts.append({
                "session_name": name,
                "first_name": meta.get("first_name", "Account"),
                "username": username,
                "phone": meta.get("phone", "N/A"),
                "user_id": meta.get("user_id", "N/A"),
                "is_in_call": engine.in_call,
                "current_chat": engine.current_chat_title
            })
        return accounts

    async def sync_all_engines_call_status(self):
        """Verifies active call state across all engines with PyTgCalls to prune ghost live states."""
        for engine in list(self.engines.values()):
            if engine.in_call:
                await engine.sync_call_status()

    async def get_global_stats(self) -> dict:
        """Returns global statistics across all users (for Super Admin)."""
        await self.sync_all_engines_call_status()
        registry = load_accounts_registry()
        total_accounts = len(self.engines)
        unique_users = len(set(v.get("owner_id", 0) for v in registry.values()))
        in_call = sum(1 for e in self.engines.values() if e.in_call)
        return {
            "total_accounts": total_accounts,
            "unique_users": unique_users,
            "in_call": in_call
        }

    async def send_comments_for_user(
        self,
        owner_id: int,
        comments: List[str],
        count: Optional[int] = None,
        progress_callback=None
    ) -> dict:
        """Sends comments from user's accounts that are currently in live stream."""
        import random
        user_engines = [e for e in self.get_user_engines(owner_id).values() if e.in_call]
        if not user_engines:
            return {"total": 0, "success": 0, "failed": 0, "error": "No accounts currently in a live stream."}

        if count and count > 0:
            user_engines = user_engines[:count]

        total = len(user_engines)
        success = 0
        failed = 0
        details = []

        for idx, engine in enumerate(user_engines, start=1):
            comment = comments[(idx - 1) % len(comments)]
            res = await engine.send_comment(comment)
            if res.get("success"):
                success += 1
                details.append(f"💬 {engine.account_id}: \"{comment}\"")
            else:
                failed += 1
                details.append(f"❌ {engine.account_id}: {res.get('error')}")

            if progress_callback and (idx % 2 == 0 or idx == total):
                try:
                    await progress_callback(idx, total, success, failed)
                except Exception:
                    pass

            if idx < total:
                await asyncio.sleep(random.uniform(1.8, 3.2))

        return {
            "total": total,
            "success": success,
            "failed": failed,
            "details": details
        }

    async def send_attachment_for_user(
        self,
        owner_id: int,
        media_path: Optional[str] = None,
        caption: str = "",
        media_type: str = "text",
        count: Optional[int] = None,
        progress_callback=None
    ) -> dict:
        """Sends manual attachment/media comment from user's active live accounts."""
        import random
        user_engines = [e for e in self.get_user_engines(owner_id).values() if e.in_call]
        if not user_engines:
            return {"total": 0, "success": 0, "failed": 0, "error": "No accounts currently in a live stream."}

        if count and count > 0:
            user_engines = user_engines[:count]

        total = len(user_engines)
        success = 0
        failed = 0
        details = []

        for idx, engine in enumerate(user_engines, start=1):
            res = await engine.send_attachment_comment(
                media_path=media_path,
                caption=caption,
                media_type=media_type
            )
            if res.get("success"):
                success += 1
                details.append(f"📎 {engine.account_id}: Sent {media_type}")
            else:
                failed += 1
                details.append(f"❌ {engine.account_id}: {res.get('error')}")

            if progress_callback and (idx % 2 == 0 or idx == total):
                try:
                    await progress_callback(idx, total, success, failed)
                except Exception:
                    pass

            if idx < total:
                await asyncio.sleep(random.uniform(1.8, 3.2))

        return {
            "total": total,
            "success": success,
            "failed": failed,
            "details": details
        }

    async def send_to_inbox_for_user(
        self,
        owner_id: int,
        chosen_acc: str,
        text: Optional[str] = None,
        media_path: Optional[str] = None,
        caption: str = "",
        media_type: str = "text",
        target_inbox: Optional[Union[str, int]] = None,
        owner_username: Optional[str] = None,
        items: Optional[List[dict]] = None,
        min_delay: float = 1.0,
        max_delay: float = 5.0
    ) -> dict:
        """Sends messages or media attachments from user's account(s) to any Telegram inbox.
        Supports bulk items to distribute different images/texts across different accounts with randomized delay."""
        user_engines = self.get_user_engines(owner_id)
        if not user_engines:
            return {"total": 0, "success": 0, "failed": 0, "error": "No accounts connected."}

        target_engines = []
        if chosen_acc == "ALL":
            target_engines = list(user_engines.values())
        else:
            engine = user_engines.get(chosen_acc)
            if engine:
                target_engines = [engine]
            else:
                return {"total": 0, "success": 0, "failed": 0, "error": "Selected account not found."}

        success = 0
        failed = 0
        details = []

        if items:
            if len(items) == 1:
                # If only 1 item provided (e.g. 1 audio/photo/text), ALL accounts send it!
                engine_items = {i: [items[0]] for i in range(len(target_engines))}
            elif len(items) < len(target_engines):
                # If fewer items than accounts, cycle items so EVERY account sends an item!
                engine_items = {i: [items[i % len(items)]] for i in range(len(target_engines))}
            else:
                engine_items = {i: [] for i in range(len(target_engines))}
                for item_idx, item in enumerate(items):
                    engine_items[item_idx % len(target_engines)].append(item)
        else:
            engine_items = {i: [{"media_type": media_type, "media_path": media_path, "caption": caption or text or ""}] for i in range(len(target_engines))}

        for idx, engine in enumerate(target_engines):
            try:
                await engine.ensure_started()
                me = getattr(engine.client, "me", None)
                if not me:
                    try:
                        me = await engine.client.get_me()
                    except Exception:
                        me = None

                dest_id = None
                if target_inbox:
                    t_str = str(target_inbox).strip()
                    if t_str.lower() in ("me", "self"):
                        dest_id = "me" if (me and me.id == owner_id) else (owner_username or owner_id)
                    elif t_str.lstrip("-").isdigit():
                        dest_id = int(t_str)
                    elif t_str.startswith("@"):
                        dest_id = t_str
                    else:
                        dest_id = f"@{t_str}"
                elif me and me.id == owner_id:
                    dest_id = "me"
                elif owner_username:
                    dest_id = f"@{owner_username.lstrip('@')}"
                else:
                    dest_id = owner_id

                assigned_items = engine_items.get(idx, [])
                for itm_idx, cur_item in enumerate(assigned_items):
                    cur_media_type = cur_item.get("media_type", "text")
                    cur_media_path = cur_item.get("media_path")
                    cur_caption = cur_item.get("caption") or cur_item.get("text", "")

                    if cur_media_type == "photo" and cur_media_path:
                        await engine.client.send_photo(dest_id, cur_media_path, caption=cur_caption or None)
                    elif cur_media_type == "video" and cur_media_path:
                        await engine.client.send_video(dest_id, cur_media_path, caption=cur_caption or None)
                    elif cur_media_type == "document" and cur_media_path:
                        await engine.client.send_document(dest_id, cur_media_path, caption=cur_caption or None)
                    elif cur_media_type == "voice" and cur_media_path:
                        await engine.client.send_voice(dest_id, cur_media_path, caption=cur_caption or None)
                    elif cur_media_type == "audio" and cur_media_path:
                        await engine.client.send_audio(dest_id, cur_media_path, caption=cur_caption or None)
                    elif cur_media_type == "sticker" and cur_media_path:
                        await engine.client.send_sticker(dest_id, cur_media_path)
                    elif cur_media_type == "animation" and cur_media_path:
                        await engine.client.send_animation(dest_id, cur_media_path, caption=cur_caption or None)
                    else:
                        await engine.client.send_message(dest_id, cur_caption or "Hello!")

                    success += 1
                    preview = (cur_caption[:25] + "...") if len(cur_caption) > 25 else cur_caption
                    label = f"'{preview}'" if preview else cur_media_type
                    details.append(f"✅ {engine.account_id}: Sent {label} to {dest_id}")
                    if itm_idx < len(assigned_items) - 1:
                        sleep_time = random.uniform(min_delay, max_delay)
                        await asyncio.sleep(sleep_time)

            except Exception as e:
                failed += 1
                details.append(f"❌ {engine.account_id}: {e}")

            if idx < len(target_engines) - 1:
                sleep_time = random.uniform(min_delay, max_delay)
                await asyncio.sleep(sleep_time)

        if items:
            for item in items:
                mp = item.get("media_path")
                if mp:
                    try:
                        from pathlib import Path
                        Path(mp).unlink(missing_ok=True)
                    except Exception:
                        pass

        return {
            "total": len(target_engines),
            "success": success,
            "failed": failed,
            "details": details
        }

    async def play_voice_in_live_for_user(
        self,
        owner_id: int,
        chosen_acc: str,
        audio_path: str,
        loop: bool = False
    ) -> dict:
        """Plays or arms a voice message for chosen account(s) in active live stream."""
        user_engines = [e for e in self.get_user_engines(owner_id).values() if e.in_call]
        if not user_engines:
            return {"total": 0, "success": 0, "failed": 0, "error": "No accounts currently in live."}

        target_engines = []
        if chosen_acc == "ALL":
            target_engines = user_engines
        elif chosen_acc.startswith("COUNT_"):
            try:
                cnt = int(chosen_acc.replace("COUNT_", ""))
                target_engines = user_engines[:cnt]
            except Exception:
                target_engines = user_engines
        else:
            for e in user_engines:
                if e.account_id == chosen_acc:
                    target_engines = [e]
                    break
            if not target_engines:
                return {"total": 0, "success": 0, "failed": 0, "error": "Selected account is not in live."}

        success = 0
        failed = 0
        details = []

        for e in target_engines:
            res = await e.play_voice(audio_path, loop=loop)
            ok = res.get("success") if isinstance(res, dict) else bool(res)
            if ok:
                success += 1
                status = res.get("status", "armed") if isinstance(res, dict) else "playing"
                if status == "playing":
                    details.append(f"🎙️ {e.account_id}: Playing Voice (লাইভে বাজছে)")
                else:
                    details.append(f"⏳ {e.account_id}: Voice Armed & Ready (হোস্ট মাইক অন করলেই বাজবে ✋)")
            else:
                failed += 1
                err = res.get("error") if isinstance(res, dict) else "Failed to load voice"
                details.append(f"❌ {e.account_id}: {err}")

        return {"total": len(target_engines), "success": success, "failed": failed, "details": details}

    async def play_bulk_voices_for_user(
        self,
        owner_id: int,
        audio_paths: List[str],
        chosen_acc: str = "ALL",
        loop: bool = False
    ) -> dict:
        """Assigns multiple audio files across user's active live accounts in bulk."""
        user_engines = [e for e in self.get_user_engines(owner_id).values() if e.in_call]
        if not user_engines:
            return {"total": 0, "success": 0, "failed": 0, "error": "No accounts currently in live."}

        target_engines = []
        if chosen_acc == "ALL":
            target_engines = user_engines
        elif chosen_acc.startswith("COUNT_"):
            try:
                cnt = int(chosen_acc.replace("COUNT_", ""))
                target_engines = user_engines[:cnt]
            except Exception:
                target_engines = user_engines
        else:
            target_engines = [e for e in user_engines if e.account_id == chosen_acc] or user_engines

        success = 0
        failed = 0
        details = []

        for idx, engine in enumerate(target_engines):
            path = audio_paths[idx % len(audio_paths)]
            res = await engine.play_voice(path, loop=loop)
            ok = res.get("success") if isinstance(res, dict) else bool(res)
            if ok:
                success += 1
                status = res.get("status", "armed") if isinstance(res, dict) else "playing"
                if status == "playing":
                    details.append(f"🎙️ {engine.account_id}: Playing Voice #{idx + 1}")
                else:
                    details.append(f"⏳ {engine.account_id}: Voice #{idx + 1} Armed (হোস্ট মাইক অন করলেই বাজবে ✋)")
            else:
                failed += 1
                err = res.get("error") if isinstance(res, dict) else "Failed"
                details.append(f"❌ {engine.account_id}: {err}")

        return {"total": len(target_engines), "success": success, "failed": failed, "details": details}

    async def raise_hand_in_live_for_user(self, owner_id: int, chosen_acc: str = "ALL") -> dict:
        """Sends a request to speak (Raise Hand) in live stream for user's accounts."""
        user_engines = [e for e in self.get_user_engines(owner_id).values() if e.in_call]
        if not user_engines:
            return {"total": 0, "success": 0, "failed": 0, "error": "No accounts currently in live."}

        target_engines = user_engines if chosen_acc == "ALL" else [e for e in user_engines if e.account_id == chosen_acc]
        if not target_engines:
            return {"total": 0, "success": 0, "failed": 0, "error": f"Selected account ({chosen_acc}) is not in live."}

        success = 0
        failed = 0
        details = []

        for e in target_engines:
            res = await e.raise_hand()
            if isinstance(res, dict):
                if res.get("success"):
                    success += 1
                    details.append(f"✋ {e.account_id}: Raised Hand (হাত তোলার রিকোয়েস্ট পাঠানো হয়েছে)")
                else:
                    failed += 1
                    details.append(f"❌ {e.account_id}: {res.get('error', 'Failed')}")
            else:
                if res:
                    success += 1
                    details.append(f"✋ {e.account_id}: Raised Hand (হাত তোলা হয়েছে)")
                else:
                    failed += 1
                    details.append(f"❌ {e.account_id}: Could not raise hand")

        return {"total": len(target_engines), "success": success, "failed": failed, "details": details}

    async def unmute_in_live_for_user(self, owner_id: int, chosen_acc: str = "ALL") -> dict:
        """Unmutes mic for user's accounts in live stream."""
        user_engines = [e for e in self.get_user_engines(owner_id).values() if e.in_call]
        if not user_engines:
            return {"total": 0, "success": 0, "failed": 0, "error": "No accounts currently in live."}

        target_engines = user_engines if chosen_acc == "ALL" else [e for e in user_engines if e.account_id == chosen_acc]
        success = 0
        failed = 0
        details = []

        for e in target_engines:
            ok = await e.unmute()
            if ok:
                success += 1
                details.append(f"🔊 {e.account_id}: Unmuted")
            else:
                failed += 1
                details.append(f"❌ {e.account_id}: Could not unmute")

        return {"total": len(target_engines), "success": success, "failed": failed, "details": details}

    async def mute_in_live_for_user(self, owner_id: int, chosen_acc: str = "ALL") -> dict:
        """Mutes mic for user's accounts in live stream."""
        user_engines = [e for e in self.get_user_engines(owner_id).values() if e.in_call]
        if not user_engines:
            return {"total": 0, "success": 0, "failed": 0, "error": "No accounts currently in live."}

        target_engines = user_engines if chosen_acc == "ALL" else [e for e in user_engines if e.account_id == chosen_acc]
        success = 0
        failed = 0
        details = []

        for e in target_engines:
            ok = await e.mute()
            if ok:
                success += 1
                details.append(f"🔇 {e.account_id}: Muted")
            else:
                failed += 1
                details.append(f"❌ {e.account_id}: Could not mute")

        return {"total": len(target_engines), "success": success, "failed": failed, "details": details}

    async def stop_voice_in_live_for_user(self, owner_id: int, chosen_acc: str = "ALL") -> dict:
        """Stops playing voice for user's accounts in live stream."""
        user_engines = [e for e in self.get_user_engines(owner_id).values() if e.in_call]
        if not user_engines:
            return {"total": 0, "success": 0, "failed": 0, "error": "No accounts currently in live."}

        target_engines = user_engines if chosen_acc == "ALL" else [e for e in user_engines if e.account_id == chosen_acc]
        success = 0
        failed = 0
        details = []

        for e in target_engines:
            ok = await e.stop_voice()
            if ok:
                success += 1
                details.append(f"⏹️ {e.account_id}: Stopped Voice")
            else:
                failed += 1
                details.append(f"❌ {e.account_id}: Could not stop voice")

        return {"total": len(target_engines), "success": success, "failed": failed, "details": details}

    async def get_poll_info_for_user(self, owner_id: int, chat_id: Union[str, int], message_id: int) -> dict:
        """Fetches poll details (question, options) using one of user's active clients."""
        user_engines = self.get_user_engines(owner_id)
        if not user_engines:
            return {"error": "No active accounts."}
        engine = next(iter(user_engines.values()))
        try:
            await engine.ensure_started()
            try:
                await engine.client.join_chat(chat_id)
            except Exception:
                pass
            msg = await engine.client.get_messages(chat_id, message_id)
            if msg and msg.poll:
                return {
                    "question": msg.poll.question,
                    "options": [opt.text for opt in msg.poll.options],
                    "total_voters": msg.poll.total_voter_count,
                    "is_closed": msg.poll.is_closed
                }
            return {"error": "Message does not contain a poll."}
        except Exception as e:
            return {"error": str(e)}

    async def vote_poll_for_user(
        self,
        owner_id: int,
        chosen_acc: str,
        chat_id: Union[str, int],
        message_id: int,
        option_idx: int,
        delay: float = 1.5
    ) -> dict:
        """Votes on a poll message across user's selected accounts."""
        user_engines = self.get_user_engines(owner_id)
        if not user_engines:
            return {"total": 0, "success": 0, "failed": 0, "error": "No accounts connected."}

        if chosen_acc == "ALL":
            target_engines = list(user_engines.values())
        elif str(chosen_acc).isdigit():
            cnt = int(chosen_acc)
            target_engines = list(user_engines.values())[:cnt]
        else:
            engine = user_engines.get(chosen_acc)
            target_engines = [engine] if engine else []

        if not target_engines:
            return {"total": 0, "success": 0, "failed": 0, "error": f"Account '{chosen_acc}' not found."}

        success = 0
        failed = 0
        details = []

        for idx, engine in enumerate(target_engines):
            try:
                await engine.ensure_started()
                try:
                    await engine.client.join_chat(chat_id)
                except Exception:
                    pass
                await engine.client.vote_poll(chat_id, message_id, [option_idx])
                success += 1
                details.append(f"✅ {engine.account_id}: Voted option #{option_idx + 1}")
            except Exception as e:
                failed += 1
                details.append(f"❌ {engine.account_id}: {e}")

            if idx < len(target_engines) - 1:
                await asyncio.sleep(delay)

        return {"total": len(target_engines), "success": success, "failed": failed, "details": details}

    async def react_and_view_post_for_user(
        self,
        owner_id: int,
        chosen_acc: str,
        chat_id: Union[str, int],
        message_id: int,
        emoji: Optional[str] = None,
        do_view: bool = True,
        do_react: bool = True,
        delay: float = 1.0
    ) -> dict:
        """Boosts post view counter and/or sends reaction emoji across user's accounts."""
        user_engines = self.get_user_engines(owner_id)
        if not user_engines:
            return {"total": 0, "success": 0, "failed": 0, "error": "No accounts connected."}

        if chosen_acc == "ALL":
            target_engines = list(user_engines.values())
        elif str(chosen_acc).isdigit():
            cnt = int(chosen_acc)
            target_engines = list(user_engines.values())[:cnt]
        else:
            engine = user_engines.get(chosen_acc)
            target_engines = [engine] if engine else []

        if not target_engines:
            return {"total": 0, "success": 0, "failed": 0, "error": f"Account '{chosen_acc}' not found."}

        from pyrogram.raw import functions
        success = 0
        failed = 0
        details = []
        popular_emojis = ["👍", "❤️", "🔥", "👏", "🎉", "🤩", "⚡", "😍", "👌"]

        for idx, engine in enumerate(target_engines):
            try:
                await engine.ensure_started()
                actions_done = []
                if do_view:
                    try:
                        peer = await engine.client.resolve_peer(chat_id)
                        await engine.client.invoke(functions.messages.GetMessagesViews(peer=peer, id=[message_id], increment=True))
                        actions_done.append("Viewed 👁️")
                    except Exception as ve:
                        logger.warning(f"View error on {engine.account_id}: {ve}")

                if do_react:
                    react_emoji = emoji
                    if not react_emoji or react_emoji == "RANDOM":
                        react_emoji = random.choice(popular_emojis)
                    try:
                        await engine.client.send_reaction(chat_id, message_id, react_emoji)
                        actions_done.append(f"Reacted {react_emoji}")
                    except Exception as rx:
                        if "REACTION_INVALID" in str(rx) and react_emoji != "👍":
                            try:
                                await engine.client.send_reaction(chat_id, message_id, "👍")
                                actions_done.append("Reacted 👍 (Fallback)")
                            except Exception as rx2:
                                logger.warning(f"React fallback error on {engine.account_id}: {rx2}")
                        else:
                            logger.warning(f"React error on {engine.account_id}: {rx}")

                if actions_done:
                    success += 1
                    details.append(f"✅ {engine.account_id}: {' + '.join(actions_done)}")
                else:
                    failed += 1
                    details.append(f"❌ {engine.account_id}: Could not view or react")

            except Exception as e:
                failed += 1
                details.append(f"❌ {engine.account_id}: {e}")

            if idx < len(target_engines) - 1:
                await asyncio.sleep(delay)

        return {"total": len(target_engines), "success": success, "failed": failed, "details": details}

    async def resolve_channel_for_user(self, owner_id: int, channel_input: str) -> dict:
        """Resolves a channel link, @username, or chat ID and gets initial info & latest msg ID."""
        user_engines = self.get_user_engines(owner_id)
        if not user_engines:
            from bot.strings import get_user_lang
            return {"error": "আপনার কোনো অ্যাকাউন্ট সংযুক্ত নেই! প্রথমে /add দিয়ে অ্যাকাউন্ট যুক্ত করুন।" if get_user_lang(owner_id) == "bn" else "No connected accounts found. Connect an account first with /add."}

        client = list(user_engines.values())[0].client
        target = channel_input.strip()

        # Handle telegram channel link formats
        if "t.me/" in target:
            target = target.split("?")[0].rstrip("/")
            if "/c/" in target:
                parts = target.split("/c/")[-1].split("/")
                clean_id = parts[0]
                try:
                    target = int(f"-100{clean_id}")
                except ValueError:
                    return {"error": "সঠিক চ্যানেল আইডি বা লিংক দিন!"}
            elif "/+" in target or "joinchat" in target:
                try:
                    chat = await safe_join_or_get_chat(client, target)
                    last_id = 0
                    try:
                        async for m in client.get_chat_history(chat.id, limit=1):
                            last_id = m.id
                    except Exception:
                        pass
                    return {
                        "success": True,
                        "chat_id": chat.id,
                        "title": chat.title or "Private Channel",
                        "username": chat.username or "",
                        "invite_link": channel_input.strip(),
                        "last_msg_id": last_id
                    }
                except Exception as e:
                    return {"error": f"ইনভাইট লিংকের মাধ্যমে চ্যানেলে যুক্ত হওয়া যায়নি: {e}"}
            else:
                target = target.split("/")[-1]
                if not target.startswith("@"):
                    target = f"@{target}"

        try:
            chat = await client.get_chat(target)
            last_id = 0
            try:
                async for m in client.get_chat_history(chat.id, limit=1):
                    last_id = m.id
            except Exception:
                pass
            return {
                "success": True,
                "chat_id": chat.id,
                "title": chat.title or str(target),
                "username": chat.username or "",
                "invite_link": "",
                "last_msg_id": last_id
            }
        except Exception as e:
            return {"error": f"চ্যানেল খুঁজে পাওয়া যায়নি: {e}"}

    async def process_auto_channel_post(
        self,
        monitor: dict,
        chat_id: int,
        message_id: int,
        bot_client = None
    ):
        """Triggers auto views and reactions for a newly detected channel post after a random 1-5s delay."""
        import random
        from core.auto_monitor import update_monitor_progress, POSITIVE_REACTIONS
        from core.subscription import can_use_post_engage, record_engage_usage, is_vip

        try:
            owner_id = monitor["user_id"]
            monitor_id = monitor["id"]
            desired_views = monitor.get("views_count", 5)
            reaction_mode = monitor.get("reaction_mode", "RANDOM_POSITIVE")
            specific_emoji = monitor.get("specific_emoji", "🔥")
            channel_username = monitor.get("channel_username", "")
            invite_link = monitor.get("invite_link", "")
            ch_name = monitor.get("channel_title") or f"Channel {chat_id}"

            # 1-5 seconds random delay as requested by user
            delay = random.uniform(1.0, 5.0)
            logger.info(f"AutoMonitor: Post {message_id} detected in channel '{ch_name}' ({chat_id}). Waiting {delay:.2f}s before engaging...")
            await asyncio.sleep(delay)

            user_engines = self.get_user_engines(owner_id)
            if not user_engines:
                logger.warning(f"AutoMonitor: No active engines for user {owner_id}. Skipping post {message_id}.")
                return

            # Check free limits
            can_eng, allowed_cnt, used_e, lim_e = can_use_post_engage(owner_id, desired_views)
            if not can_eng:
                logger.warning(f"AutoMonitor: User {owner_id} daily quota exhausted ({used_e}/{lim_e}). Skipping post {message_id}.")
                if bot_client:
                    try:
                        from bot.strings import get_user_lang
                        from bot.keyboards import main_menu_keyboard
                        if get_user_lang(owner_id) == "bn":
                            txt = (
                                f"⚠️ **[অটো মনিটর নোটিশ]** আপনার চ্যানেলে নতুন পোস্ট এসেছে, কিন্তু আপনার আজকের ফ্রি ৫টি অ্যাকাউন্টের লিমিট শেষ হয়ে গেছে!\n\n"
                                f"📊 ব্যবহৃত: **{used_e}/{lim_e}** টি অ্যাকাউন্ট\n"
                                f"💡 প্রতিদিন ফ্রিতে ৫টি অ্যাকাউন্ট ব্যবহার করা যায়। ২৪/৭ আনলিমিটেড অটো পোস্ট বুস্টিংয়ের জন্য VIP মেম্বারশিপ গ্রহণ করুন।"
                            )
                        else:
                            txt = (
                                f"⚠️ **[Auto Monitor Notice]** A new post arrived, but your free daily quota of 5 accounts is reached!\n\n"
                                f"📊 Used: **{used_e}/{lim_e}** accounts\n"
                                f"💡 Upgrade to VIP for unlimited 24/7 automated post views & reactions."
                            )
                        await bot_client.send_message(owner_id, txt, reply_markup=main_menu_keyboard(owner_id))
                    except Exception as ne:
                        logger.warning(f"Quota notice send err: {ne}")
                return

            if not is_vip(owner_id):
                allowed_cnt = min(allowed_cnt, 5)

            actual_count = min(len(user_engines), allowed_cnt)
            if actual_count <= 0:
                logger.warning(f"AutoMonitor: Zero accounts available for user {owner_id}. Skipping post {message_id}.")
                return

            engines_to_use = list(user_engines.values())[:actual_count]
            logger.info(f"AutoMonitor: Engaging post {message_id} in '{ch_name}' with {len(engines_to_use)} account(s) (Target: {desired_views} views, Mode: {reaction_mode})...")

            from pyrogram.raw import functions
            success_views = 0
            success_reacts = 0
            channel_reactions_disabled = False
            channel_allowed_emojis = None

            # If POOL_PER_POST, choose ONE random emoji for this entire post across all accounts
            chosen_post_emoji = None
            if reaction_mode == "POOL_PER_POST":
                raw_spec = specific_emoji or "🔥"
                em_list = [e.strip() for e in re.split(r'[\s,]+', raw_spec) if e.strip()]
                chosen_post_emoji = random.choice(em_list) if em_list else "🔥"
                logger.info(f"AutoMonitor: Post {message_id} in '{ch_name}' selected post-level emoji '{chosen_post_emoji}' from pool {em_list}")
            elif reaction_mode == "SPECIFIC":
                raw_spec = specific_emoji or "🔥"
                em_list = [e.strip() for e in re.split(r'[\s,]+', raw_spec) if e.strip()]
                if len(em_list) <= 1:
                    chosen_post_emoji = em_list[0] if em_list else "🔥"

            for idx, eng in enumerate(engines_to_use, start=1):
                try:
                    # Light start check without blocking voice engine
                    if not eng.client.is_connected:
                        await eng.client.start()

                    resolved_peer = None
                    target_for_reaction = chat_id

                    # 1. For public channels, resolve by username first (works for all accounts)
                    if channel_username:
                        clean_user = channel_username.lstrip("@")
                        try:
                            c = await eng.client.get_chat(clean_user)
                            resolved_peer = await eng.client.resolve_peer(c.id)
                        except Exception as ue:
                            logger.debug(f"AutoMonitor [{eng.account_id}] username resolve failed: {ue}")

                    # 2. For private channels with invite link, ensure account has joined
                    if resolved_peer is None and invite_link:
                        try:
                            c = await safe_join_or_get_chat(eng.client, invite_link)
                            resolved_peer = await eng.client.resolve_peer(c.id)
                        except Exception as ie:
                            logger.debug(f"AutoMonitor [{eng.account_id}] invite join failed: {ie}")

                    # 3. Direct chat_id fallback
                    if resolved_peer is None:
                        try:
                            resolved_peer = await eng.client.resolve_peer(chat_id)
                        except Exception:
                            try:
                                c = await eng.client.get_chat(chat_id)
                                resolved_peer = await eng.client.resolve_peer(c.id)
                            except Exception as pe:
                                logger.warning(f"AutoMonitor [{eng.account_id}]: Cannot resolve channel {chat_id}: {pe}")
                                continue

                    account_viewed = False
                    account_reacted = False

                    # 1. Increment View Counter directly (without joining channel)
                    try:
                        await eng.client.invoke(functions.messages.GetMessagesViews(peer=resolved_peer, id=[message_id], increment=True))
                        success_views += 1
                        account_viewed = True
                    except Exception as ve:
                        logger.warning(f"AutoMonitor [{eng.account_id}] View error: {ve}")

                    # 2. Send Reaction Emoji
                    if reaction_mode != "NONE" and not channel_reactions_disabled:
                        if chosen_post_emoji:
                            emoji = chosen_post_emoji
                        elif reaction_mode == "RANDOM_POSITIVE":
                            emoji = random.choice(POSITIVE_REACTIONS)
                        else:
                            raw_spec = specific_emoji or "🔥"
                            em_list = [e.strip() for e in re.split(r'[\s,]+', raw_spec) if e.strip()]
                            emoji = random.choice(em_list) if em_list else raw_spec
                        try:
                            from pyrogram.raw import types
                            await eng.client.invoke(
                                functions.messages.SendReaction(
                                    peer=resolved_peer,
                                    msg_id=message_id,
                                    reaction=[types.ReactionEmoji(emoticon=emoji)]
                                )
                            )
                            success_reacts += 1
                            account_reacted = True
                        except Exception as rx:
                            if "REACTION_INVALID" in str(rx) and emoji != "👍":
                                try:
                                    from pyrogram.raw import types
                                    await eng.client.invoke(
                                        functions.messages.SendReaction(
                                            peer=resolved_peer,
                                            msg_id=message_id,
                                            reaction=[types.ReactionEmoji(emoticon="👍")]
                                        )
                                    )
                                    success_reacts += 1
                                    account_reacted = True
                                    logger.info(f"AutoMonitor [{eng.account_id}] Fallback reaction 👍 sent successfully!")
                                except Exception as rx2:
                                    if "REACTION_INVALID" in str(rx2):
                                        channel_reactions_disabled = True
                                        logger.warning(f"AutoMonitor: Channel '{ch_name}' has reactions disabled in Telegram channel settings ({rx2}). Skipping further reactions.")
                                    else:
                                        logger.warning(f"AutoMonitor [{eng.account_id}] Reaction error: {rx2}")
                            else:
                                logger.warning(f"AutoMonitor [{eng.account_id}] Reaction error ({emoji}): {rx}")

                    logger.info(f"AutoMonitor [{eng.account_id}] ({idx}/{len(engines_to_use)}): 👁️ Viewed: {'✅' if account_viewed else '❌'} | ❤️ Reacted: {'✅' if account_reacted else '❌'}")

                    if idx < len(engines_to_use):
                        await asyncio.sleep(random.uniform(0.6, 1.3))

                except Exception as e:
                    logger.warning(f"AutoMonitor account loop error on {eng.account_id}: {e}")

            logger.info(f"AutoMonitor: Finished post {message_id} in '{ch_name}'! Total views: {success_views}/{len(engines_to_use)}, reactions: {success_reacts}/{len(engines_to_use)}")

            # Update monitor progress and boosted counter
            update_monitor_progress(monitor_id, message_id, increment_posts=1)

            # Record quota
            if not is_vip(owner_id) and max(success_views, success_reacts) > 0:
                record_engage_usage(owner_id, max(success_views, success_reacts))

            # Notify owner via bot
            if bot_client:
                try:
                    ch_user = monitor.get("channel_username")
                    post_link = f"https://t.me/{ch_user}/{message_id}" if ch_user else f"Post #{message_id}"
                    from bot.strings import get_user_lang

                    react_tip = ""
                    if channel_reactions_disabled or (reaction_mode != "NONE" and success_reacts == 0):
                        if get_user_lang(owner_id) == "bn":
                            react_tip = "\n\n💡 **রিঅ্যাকশন টিপস:** আপনার টেলিগ্রাম চ্যানেলে রিঅ্যাকশন বন্ধ (Disabled) রয়েছে। অটো রিঅ্যাকশন পেতে চ্যানেলের Edit (✏️) -> **Reactions** অপশনটি অন করে নিন।"
                        else:
                            react_tip = "\n\n💡 **Reaction Tip:** Reactions are currently turned off in this channel. Enable **Reactions** in your Telegram Channel Settings to receive automated reactions."

                    if get_user_lang(owner_id) == "bn":
                        txt = (
                            f"⚡ **[অটো মনিটর] নতুন পোস্ট শনাক্ত ও বুস্ট সম্পন্ন!**\n\n"
                            f"📢 চ্যানেল: **{ch_name}**\n"
                            f"🔗 পোস্ট: `{post_link}`\n"
                            f"👁️ ভিউ প্রদান: **{success_views}** টি\n"
                            f"❤️ রিঅ্যাকশন প্রদান: **{success_reacts}** টি\n"
                            f"⏱️ বিরতি: **{delay:.1f}** সেকেন্ডে স্বয়ংক্রিয়ভাবে সম্পন্ন হয়েছে!{react_tip}"
                        )
                    else:
                        txt = (
                            f"⚡ **[Auto Monitor] New Post Detected & Boosted!**\n\n"
                            f"📢 Channel: **{ch_name}**\n"
                            f"🔗 Post: `{post_link}`\n"
                            f"👁️ Views Added: **{success_views}**\n"
                            f"❤️ Reactions Sent: **{success_reacts}**\n"
                            f"⏱️ Delay: Processed after **{delay:.1f}s**!{react_tip}"
                        )
                    await bot_client.send_message(owner_id, txt)
                    logger.info(f"AutoMonitor: Sent completion alert to owner {owner_id}")
                except Exception as ne:
                    logger.warning(f"AutoMonitor: Notification error to owner {owner_id}: {ne}")

        except Exception as fatal_e:
            logger.error(f"AutoMonitor fatal error on post {message_id} in {chat_id}: {fatal_e}", exc_info=True)

    async def run_auto_channel_monitor_loop(self, bot_client = None):
        """Periodically polls registered active channels for new posts every 3-5 seconds."""
        from core.auto_monitor import get_all_active_monitors, update_monitor_progress
        logger.info("📡 Starting Auto Channel Monitor background worker loop...")
        while True:
            try:
                monitors = get_all_active_monitors()
                for mon in monitors:
                    owner_id = mon["user_id"]
                    user_engines = self.get_user_engines(owner_id)
                    if not user_engines:
                        continue
                    client = list(user_engines.values())[0].client
                    chat_id = mon["channel_id"]
                    ch_user = mon.get("channel_username")
                    poll_target = f"@{ch_user.lstrip('@')}" if ch_user else chat_id
                    last_seen = mon.get("last_msg_id", 0)

                    try:
                        async for msg in client.get_chat_history(poll_target, limit=1):
                            if msg.id > last_seen:
                                if last_seen == 0:
                                    # Baseline initialization to not trigger old historical posts
                                    update_monitor_progress(mon["id"], msg.id, increment_posts=0)
                                    logger.info(f"AutoMonitor: Baseline post #{msg.id} set for channel '{mon.get('channel_title', chat_id)}'")
                                    continue
                                # New post published! Update last seen immediately to avoid duplicate task triggers
                                update_monitor_progress(mon["id"], msg.id, increment_posts=0)
                                asyncio.create_task(self.process_auto_channel_post(mon, chat_id, msg.id, bot_client))
                    except Exception as pe:
                        logger.debug(f"Polling check error for {poll_target}: {pe}")

            except Exception as e:
                logger.error(f"Error in auto channel monitor loop: {e}", exc_info=True)
            await asyncio.sleep(3.5)

    async def resolve_auto_live_target(self, user_id: int, target_input: str) -> dict:
        """Resolves target channel/group for auto live joiner and checks its current live status."""
        engines = self.get_user_engines(user_id)
        if not engines and self.engines:
            engines = self.engines
        if not engines:
            return {"error": "বটের সাথে কোনো টেলিগ্রাম অ্যাকাউন্ট যুক্ত নেই।"}

        engine = list(engines.values())[0]
        await engine.ensure_started()
        client = engine.client

        clean = target_input.strip()
        if clean.startswith("https://"):
            clean = clean.replace("https://", "")
        if clean.startswith("http://"):
            clean = clean.replace("http://", "")
        if clean.startswith("t.me/"):
            clean = clean.replace("t.me/", "")
        clean = clean.rstrip("/")

        is_invite = clean.startswith("+")
        chat_identifier = target_input.strip() if is_invite else (f"@{clean.lstrip('@')}" if not clean.startswith("-100") and not clean.isdigit() else int(clean))

        try:
            if is_invite:
                chat = await safe_join_or_get_chat(client, target_input.strip())
            else:
                chat = await safe_join_or_get_chat(client, chat_identifier)
        except Exception as e:
            return {"error": f"চ্যানেল বা গ্রুপ খুঁজে পাওয়া যায়নি: {e}"}

        # Check if currently live
        is_live = False
        call_id = None
        call_title = ""
        try:
            from pyrogram.raw import functions, types as raw_types
            peer = await client.resolve_peer(chat.id)
            if isinstance(peer, (raw_types.InputPeerChannel, raw_types.InputChannel)):
                full = await client.invoke(
                    functions.channels.GetFullChannel(
                        channel=raw_types.InputChannel(channel_id=peer.channel_id, access_hash=peer.access_hash)
                    )
                )
            else:
                full = await client.invoke(functions.messages.GetFullChat(chat_id=peer.chat_id))
            call = getattr(full.full_chat, "call", None)
            if call and hasattr(call, "id"):
                is_live = True
                call_id = call.id
                try:
                    input_call = raw_types.InputGroupCall(id=call.id, access_hash=call.access_hash)
                    call_info = await client.invoke(functions.phone.GetGroupCall(call=input_call, limit=0))
                    gcall = getattr(call_info, "call", None)
                    call_title = getattr(gcall, "title", "") or ""
                except Exception:
                    pass
        except Exception:
            pass

        return {
            "success": True,
            "chat_id": chat.id,
            "title": getattr(chat, "title", str(chat.id)),
            "username": getattr(chat, "username", "") or "",
            "invite_link": target_input.strip() if is_invite else "",
            "is_live": is_live,
            "call_id": call_id,
            "call_title": call_title
        }

    async def run_auto_live_monitor_loop(self, bot_client = None):
        """Periodically checks active auto live targets and joins when a live stream starts."""
        from core.auto_live_joiner import get_all_active_live_targets, update_live_target_status
        from bot.strings import get_user_lang
        from pyrogram.raw import functions, types as raw_types

        logger.info("📡 Starting Auto Live Join background worker loop...")
        while True:
            try:
                targets = get_all_active_live_targets()
                for target in targets:
                    target_id = target["id"]
                    owner_id = target["user_id"]
                    user_engines = self.get_user_engines(owner_id)
                    if not user_engines and self.engines:
                        user_engines = self.engines
                    if not user_engines:
                        continue

                    client = list(user_engines.values())[0].client
                    chat_id = target.get("chat_id")
                    username = target.get("chat_username")
                    invite_link = target.get("invite_link")
                    chat_target = invite_link or (f"@{username.lstrip('@')}" if username else chat_id)

                    try:
                        peer = await client.resolve_peer(chat_id if chat_id else chat_target)
                        if isinstance(peer, (raw_types.InputPeerChannel, raw_types.InputChannel)):
                            full = await client.invoke(
                                functions.channels.GetFullChannel(
                                    channel=raw_types.InputChannel(channel_id=peer.channel_id, access_hash=peer.access_hash)
                                )
                            )
                        else:
                            full = await client.invoke(functions.messages.GetFullChat(chat_id=peer.chat_id))

                        call = getattr(full.full_chat, "call", None)

                        if call and hasattr(call, "id"):
                            call_id = call.id
                            last_live_id = target.get("last_live_id")
                            if not target.get("is_currently_live") or last_live_id != call_id:
                                logger.info(f"🔴 [AutoLive] Live Stream DETECTED on '{target.get('chat_title')}' (Call ID: {call_id})! Auto-joining...")
                                
                                update_live_target_status(target_id, is_live=True, live_id=call_id, increment_joins=True)

                                accounts_cnt = target.get("accounts_count", 0)
                                join_cnt = accounts_cnt if accounts_cnt > 0 else None
                                
                                join_res = await self.join_for_user(owner_id, str(chat_target), count=join_cnt)
                                success_cnt = join_res.get("success", 0)
                                total_cnt = join_res.get("total", 0)

                                if bot_client:
                                    try:
                                        lang = get_user_lang(owner_id)
                                        ch_name = target.get("chat_title") or str(chat_target)
                                        if lang == "bn":
                                            alert = (
                                                f"🔴 **[অটো লাইভ জয়েন] লাইভ স্ট্রিম শনাক্ত হয়েছে!**\n\n"
                                                f"📢 টার্গেট: **{ch_name}**\n"
                                                f"👥 লাইভে জয়েন সম্পন্ন: **{success_cnt}/{total_cnt} টি অ্যাকাউন্ট**\n\n"
                                                f"✨ আপনার নির্ধারিত অ্যাকাউন্টগুলো স্বয়ংক্রিয়ভাবে লাইভে কানেক্ট হয়ে গেছে!"
                                            )
                                        else:
                                            alert = (
                                                f"🔴 **[Auto Live Join] Live Stream Detected!**\n\n"
                                                f"📢 Target: **{ch_name}**\n"
                                                f"👥 Successfully Joined: **{success_cnt}/{total_cnt} accounts**\n\n"
                                                f"✨ Your configured accounts have automatically joined the live stream!"
                                            )
                                        await bot_client.send_message(owner_id, alert)
                                    except Exception as ne:
                                        logger.warning(f"AutoLive: User notify error: {ne}")
                        else:
                            if target.get("is_currently_live"):
                                logger.info(f"⚪ [AutoLive] Live Stream ended on '{target.get('chat_title')}'. Resetting live flag.")
                                update_live_target_status(target_id, is_live=False)

                    except Exception as te:
                        logger.debug(f"AutoLive: Polling error for target {target_id}: {te}")

            except Exception as e:
                logger.error(f"Error in auto live monitor loop: {e}", exc_info=True)

            await asyncio.sleep(10.0)

    async def inspect_live_stream(self, admin_id: int, target: str) -> dict:
        """Inspects an active Telegram Live Stream / Voice Chat and extracts all participants.
        Strictly for Admins. Uses an available account to execute MTProto queries."""
        engines = self.get_user_engines(admin_id)
        if not engines and self.engines:
            engines = self.engines
        if not engines:
            return {"success": False, "error": "বটের সাথে কোনো টেলিগ্রাম অ্যাকাউন্ট যুক্ত নেই। লাইভ ইন্সপেক্ট করতে অন্তত একটি অ্যাকাউন্ট প্রয়োজন।"}

        engine = list(engines.values())[0]
        await engine.ensure_started()
        client = engine.client

        # 1. Clean and resolve target chat
        clean = target.strip()
        if clean.startswith("https://"):
            clean = clean.replace("https://", "")
        if clean.startswith("http://"):
            clean = clean.replace("http://", "")
        if clean.startswith("t.me/"):
            clean = clean.replace("t.me/", "")
        clean = clean.rstrip("/")

        is_invite = clean.startswith("+")
        chat_identifier = target.strip() if is_invite else (f"@{clean.lstrip('@')}" if not clean.startswith("-100") and not clean.isdigit() else int(clean))

        try:
            if is_invite:
                chat = await safe_join_or_get_chat(client, target.strip())
            else:
                chat = await safe_join_or_get_chat(client, chat_identifier)
        except Exception as ce:
            logger.warning(f"InspectLive: Could not resolve chat {target}: {ce}")
            return {"success": False, "error": f"চ্যানেল বা গ্রুপটি শনাক্ত করা যায়নি: {ce}"}

        # 2. MTProto call to fetch active group call
        try:
            from pyrogram.raw import functions, types as raw_types
            peer = await client.resolve_peer(chat.id)

            if isinstance(peer, (raw_types.InputPeerChannel, raw_types.InputChannel)):
                full = await client.invoke(
                    functions.channels.GetFullChannel(
                        channel=raw_types.InputChannel(channel_id=peer.channel_id, access_hash=peer.access_hash)
                    )
                )
                call = getattr(full.full_chat, "call", None)
            else:
                full = await client.invoke(functions.messages.GetFullChat(chat_id=peer.chat_id))
                call = getattr(full.full_chat, "call", None)

            if not call:
                return {
                    "success": False,
                    "chat_title": getattr(chat, "title", str(chat.id)),
                    "error": "এই চ্যানেল বা গ্রুপে বর্তমানে কোনো সক্রিয় লাইভ স্ট্রিম বা ভয়েস চ্যাট চালু নেই।"
                }

            input_call = raw_types.InputGroupCall(id=call.id, access_hash=call.access_hash)
        except Exception as pe:
            logger.warning(f"InspectLive: Call lookup error for {chat.id}: {pe}")
            return {"success": False, "error": f"লাইভ ভয়েস চ্যাট যাচাইকালে ত্রুটি হয়েছে: {pe}"}

        # 3. Fetch call details and participants
        try:
            participants = []
            offset = ""
            total_count = 0
            user_map = {}

            # Fetch up to 200 participants safely
            while len(participants) < 200:
                res = await client.invoke(
                    functions.phone.GetGroupParticipants(
                        call=input_call,
                        ids=[],
                        sources=[],
                        offset=offset,
                        limit=100
                    )
                )
                total_count = getattr(res, "count", 0)

                for u in getattr(res, "users", []):
                    user_map[u.id] = u

                for p in getattr(res, "participants", []):
                    p_peer = p.peer
                    if isinstance(p_peer, raw_types.PeerUser):
                        uid = p_peer.user_id
                        user = user_map.get(uid)
                        if not user:
                            continue
                        first = getattr(user, "first_name", "") or ""
                        last = getattr(user, "last_name", "") or ""
                        name = f"{first} {last}".strip() or f"User#{uid}"
                        username = getattr(user, "username", None)
                        is_muted = getattr(p, "muted", True)
                        is_speaking = not is_muted

                        is_bot = getattr(user, "bot", False)
                        is_deleted = getattr(user, "deleted", False)
                        status_obj = getattr(user, "status", None)

                        activity_status = "inactive"
                        status_label = "⚪ Inactive"

                        if isinstance(status_obj, raw_types.UserStatusOnline):
                            activity_status = "online"
                            status_label = "🟢 Online"
                        elif isinstance(status_obj, raw_types.UserStatusRecently):
                            activity_status = "recent"
                            status_label = "🟡 Recently Active"
                        elif isinstance(status_obj, raw_types.UserStatusLastWeek):
                            activity_status = "last_week"
                            status_label = "⚪ Last Week"
                        elif isinstance(status_obj, raw_types.UserStatusLastMonth):
                            activity_status = "last_month"
                            status_label = "⚪ Last Month"

                        is_real_human = (not is_bot) and (not is_deleted)

                        participants.append({
                            "user_id": uid,
                            "name": name,
                            "username": username,
                            "is_muted": is_muted,
                            "is_speaking": is_speaking,
                            "is_bot": is_bot,
                            "is_deleted": is_deleted,
                            "activity_status": activity_status,
                            "status_label": status_label,
                            "is_real_human": is_real_human,
                        })
                    elif isinstance(p_peer, raw_types.PeerChannel):
                        participants.append({
                            "user_id": p_peer.channel_id,
                            "name": f"Channel#{p_peer.channel_id}",
                            "username": None,
                            "is_muted": getattr(p, "muted", True),
                            "is_speaking": not getattr(p, "muted", True),
                            "is_bot": False,
                            "is_deleted": False,
                            "activity_status": "channel",
                            "status_label": "📢 Channel Profile",
                            "is_real_human": False,
                        })

                offset = getattr(res, "next_offset", "")
                if not offset or not getattr(res, "participants", []):
                    break

            speakers = [p for p in participants if p["is_speaking"]]
            listeners = [p for p in participants if not p["is_speaking"]]

            real_humans = [p for p in participants if p.get("is_real_human")]
            active_humans = [p for p in real_humans if p.get("activity_status") in ("online", "recent")]
            inactive_humans = [p for p in real_humans if p.get("activity_status") not in ("online", "recent")]
            with_username_humans = [p for p in real_humans if p.get("username")]
            bots_and_channels = [p for p in participants if not p.get("is_real_human")]

            # 4. Generate export file in exports/
            from pathlib import Path
            from datetime import datetime
            exports_dir = Path("exports")
            exports_dir.mkdir(exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = exports_dir / f"live_members_{chat.id}_{timestamp}.txt"

            with open(filename, "w", encoding="utf-8") as f:
                f.write(f"=== Telegram Live Stream Participants ===\n")
                f.write(f"Target: {getattr(chat, 'title', '')} (@{getattr(chat, 'username', 'N/A')})\n")
                f.write(f"Scanned At: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
                f.write(f"Total Participants: {total_count}\n")
                f.write(f"Real Humans: {len(real_humans)} (Online/Recent: {len(active_humans)} | Inactive: {len(inactive_humans)})\n")
                f.write(f"Filtered Out (Bots/Channels): {len(bots_and_channels)}\n\n")

                f.write(f"--- 🎤 SPEAKERS ({len(speakers)}) ---\n")
                for s in speakers:
                    u_str = f"@{s['username']}" if s['username'] else "(No Username)"
                    f.write(f"{s.get('status_label', '')} {u_str} | {s['name']} | ID: {s['user_id']}\n")

                f.write(f"\n--- 🎧 LISTENERS ({len(listeners)}) ---\n")
                for l in listeners:
                    u_str = f"@{l['username']}" if l['username'] else "(No Username)"
                    f.write(f"{l.get('status_label', '')} {u_str} | {l['name']} | ID: {l['user_id']}\n")

                f.write(f"\n--- 👥 REAL HUMANS ({len(real_humans)}) ---\n")
                for h in real_humans:
                    u_str = f"@{h['username']}" if h['username'] else "(No Username)"
                    f.write(f"{h.get('status_label', '')} {u_str} | {h['name']} | ID: {h['user_id']}\n")

                f.write(f"\n--- 📋 ALL USERNAMES ONLY ---\n")
                for p in real_humans:
                    if p['username']:
                        f.write(f"@{p['username']}\n")

            return {
                "success": True,
                "chat_title": getattr(chat, "title", "Live Stream"),
                "chat_username": getattr(chat, "username", None),
                "total_count": total_count,
                "extracted_count": len(participants),
                "speakers": speakers,
                "listeners": listeners,
                "participants": participants,
                "real_humans": real_humans,
                "active_humans": active_humans,
                "inactive_humans": inactive_humans,
                "with_username_humans": with_username_humans,
                "bots_and_channels": bots_and_channels,
                "export_file": str(filename),
            }

        except Exception as fe:
            logger.error(f"InspectLive: Error fetching participants: {fe}", exc_info=True)
            return {"success": False, "error": f"অংশগ্রহণকারীদের তথ্য আনার সময় সমস্যা হয়েছে: {fe}"}

    async def send_message_to_live_participants(
        self,
        admin_id: int,
        participants: list,
        template_text: str,
        media_path: Optional[str] = None,
        media_type: Optional[str] = None,
        limit_count: int = 10,
        min_delay: float = 2.5,
        max_delay: float = 4.5
    ) -> dict:
        """Sends direct messages (text, image, video, document) to extracted live stream participants.
        Automatically distributes sending across ALL available connected accounts in rotation."""
        admin_engines = list(self.get_user_engines(admin_id).values())
        all_engines = admin_engines if admin_engines else list(self.engines.values())
        if not all_engines:
            return {"total": 0, "success": 0, "failed": 0, "error": "বটের সাথে কোনো সক্রিয় অ্যাকাউন্ট নেই।"}

        valid_targets = [p for p in participants if p.get("username") or p.get("user_id")]
        targets_to_msg = valid_targets[:limit_count]

        if not targets_to_msg:
            return {"total": 0, "success": 0, "failed": 0, "error": "মেসেজ পাঠানোর মতো কোনো ভ্যালিড মেম্বার পাওয়া যায়নি।"}

        from pyrogram.errors import PeerFlood, FloodWait, UserPrivacyRestricted, UserIsBlocked
        from pathlib import Path
        import os

        success = 0
        failed = 0
        skipped = 0
        details = []
        num_engines = len(all_engines)

        try:
            for idx, p in enumerate(targets_to_msg, 1):
                # Multi-account round-robin rotation
                engine = all_engines[(idx - 1) % num_engines]
                try:
                    await engine.ensure_started()
                except Exception:
                    pass
                client = engine.client

                p_name = p.get("name", "Friend")
                first_name = p_name.split()[0] if p_name else "Friend"
                p_user = p.get("username")
                target = f"@{p_user}" if p_user else p.get("user_id")

                # Render personalized template
                msg_text = (
                    template_text
                    .replace("{name}", p_name)
                    .replace("{first_name}", first_name)
                    .replace("{username}", f"@{p_user}" if p_user else p_name)
                    .replace("{id}", str(p.get("user_id", "")))
                )
                # Apply dynamic Spintax resolution
                msg_text = parse_spintax(msg_text)

                try:
                    if media_path and os.path.exists(media_path):
                        if media_type == "photo":
                            await client.send_photo(target, photo=media_path, caption=msg_text)
                        elif media_type == "video":
                            await client.send_video(target, video=media_path, caption=msg_text)
                        else:
                            await client.send_document(target, document=media_path, caption=msg_text)
                    else:
                        await client.send_message(target, msg_text)

                    success += 1
                    details.append(f"✅ [{engine.account_id}] ➡️ {target} ({p_name}): Sent")
                    logger.info(f"LiveDM: Sent by [{engine.account_id}] to {target}")
                except PeerFlood:
                    failed += 1
                    details.append(f"⚠️ [{engine.account_id}] PeerFlood: টেলিগ্রাম রেস্ট্রিকশন এড়াতে মেসেজিং স্বয়ংক্রিয়ভাবে বন্ধ করা হলো।")
                    logger.warning(f"LiveDM: PeerFlood encountered on {engine.account_id}! Stopping.")
                    break
                except (UserPrivacyRestricted, UserIsBlocked):
                    skipped += 1
                    details.append(f"⏩ {target}: Skipped (Privacy settings)")
                except FloodWait as fw:
                    if fw.value <= 10:
                        await asyncio.sleep(fw.value)
                        try:
                            if media_path and os.path.exists(media_path):
                                if media_type == "photo":
                                    await client.send_photo(target, photo=media_path, caption=msg_text)
                                elif media_type == "video":
                                    await client.send_video(target, video=media_path, caption=msg_text)
                                else:
                                    await client.send_document(target, document=media_path, caption=msg_text)
                            else:
                                await client.send_message(target, msg_text)
                            success += 1
                            details.append(f"✅ [{engine.account_id}] ➡️ {target} ({p_name}): Sent (after wait)")
                        except Exception:
                            failed += 1
                    else:
                        failed += 1
                        details.append(f"⚠️ FloodWait {fw.value}s - Stopping")
                        break
                except Exception as e:
                    failed += 1
                    details.append(f"❌ [{engine.account_id}] ➡️ {target}: {e}")

                if idx < len(targets_to_msg):
                    import random
                    await asyncio.sleep(random.uniform(min_delay, max_delay))

        finally:
            if media_path:
                try:
                    Path(media_path).unlink(missing_ok=True)
                except Exception:
                    pass

        return {
            "total": len(targets_to_msg),
            "success": success,
            "failed": failed,
            "skipped": skipped,
            "details": details
        }

    async def discover_live_streams(self, admin_id: int, query: str, limit: int = 25, country: str = "GLOBAL") -> dict:
        """Searches Telegram public directory for channels/groups matching a keyword/category,
        then inspects and filters only those currently running an active Live Stream / Voice Chat.
        Optionally filters results by country (e.g. BD for Bangladesh)."""
        engines = self.get_user_engines(admin_id)
        if not engines and self.engines:
            engines = self.engines
        if not engines:
            return {"success": False, "error": "বটের সাথে কোনো সক্রিয় অ্যাকাউন্ট নেই।"}

        engine = list(engines.values())[0]
        await engine.ensure_started()
        client = engine.client

        from pyrogram.raw import functions, types as raw_types

        keywords = [k.strip() for k in re.split(r'[,;\n|]+', query) if k.strip()]
        if not keywords:
            keywords = [query.strip()] if query.strip() else []

        if not keywords:
            return {"success": True, "query": query, "total_found": 0, "total_live": 0, "live_streams": []}

        # Country query expansion (e.g. inject local terms if specific country selected)
        expanded_keywords = list(keywords)
        if country and country.upper() != "GLOBAL":
            cfg = COUNTRY_CONFIGS.get(country.upper())
            if cfg:
                for base_kw in keywords[:5]:
                    for c_kw in cfg.get("keywords", [])[:4]:
                        combo = f"{base_kw} {c_kw}".strip()
                        if combo not in expanded_keywords:
                            expanded_keywords.append(combo)

        seen_chats = {}
        for kw in expanded_keywords[:30]:
            try:
                search_res = await client.invoke(
                    functions.contacts.Search(q=kw, limit=limit)
                )
                for c in getattr(search_res, "chats", []):
                    if c.id not in seen_chats:
                        seen_chats[c.id] = c
            except Exception as se:
                logger.warning(f"DiscoverLive: Search error for '{kw}': {se}")

        raw_chats = list(seen_chats.values())
        if not raw_chats:
            return {"success": True, "query": query, "country": country, "total_found": 0, "total_live": 0, "live_streams": []}

        active_lives = []
        sem = asyncio.Semaphore(8)

        async def check_chat_live(c):
            async with sem:
                try:
                    full = None
                    if isinstance(c, raw_types.Channel):
                        full = await client.invoke(
                            functions.channels.GetFullChannel(
                                channel=raw_types.InputChannel(channel_id=c.id, access_hash=c.access_hash)
                            )
                        )
                    elif isinstance(c, raw_types.Chat):
                        full = await client.invoke(functions.messages.GetFullChat(chat_id=c.id))

                    if not full:
                        return

                    call = getattr(full.full_chat, "call", None)
                    if call and hasattr(call, "id"):
                        input_call = raw_types.InputGroupCall(id=call.id, access_hash=call.access_hash)
                        call_info = await client.invoke(functions.phone.GetGroupCall(call=input_call, limit=0))
                        gcall = getattr(call_info, "call", None)

                        p_count = getattr(gcall, "participants_count", 0) if gcall else 0
                        call_title = getattr(gcall, "title", None) or "Live Stream"

                        members_cnt = getattr(full.full_chat, "participants_count", 0) or 0
                        online_cnt = getattr(full.full_chat, "online_count", 0) or 0
                        is_group = getattr(c, "megagroup", False) or isinstance(c, raw_types.Chat)

                        c_title = getattr(c, "title", "Group")
                        c_username = getattr(c, "username", None)
                        matches_country = match_chat_country(c_title, c_username, country)

                        active_lives.append({
                            "chat_id": c.id,
                            "title": c_title,
                            "username": c_username,
                            "call_id": call.id,
                            "call_title": call_title,
                            "live_participants": p_count,
                            "total_members": members_cnt,
                            "online_members": online_cnt,
                            "is_group": is_group,
                            "matches_country": matches_country,
                            "country_flag": COUNTRY_CONFIGS.get(country.upper(), {}).get("flag", "🌐") if matches_country else "🌐"
                        })
                except Exception as e:
                    logger.debug(f"DiscoverLive: Check failed for {getattr(c, 'title', c.id)}: {e}")

        tasks = [check_chat_live(c) for c in raw_chats[:80]]
        await asyncio.gather(*tasks, return_exceptions=True)

        if country and country.upper() != "GLOBAL":
            active_lives = [l for l in active_lives if l.get("matches_country")]

        active_lives.sort(key=lambda x: (
            1 if x.get("matches_country") else 0,
            x["live_participants"],
            x["total_members"]
        ), reverse=True)

        return {
            "success": True,
            "query": query,
            "country": country,
            "total_searched": len(raw_chats),
            "total_live": len(active_lives),
            "live_streams": active_lives
        }

    async def discover_dialog_live_streams(self, admin_id: int, limit_dialogs: int = 100) -> dict:
        """Scans joined channels and supergroups across connected account(s) to locate
        all active Live Streams and Voice Chats in groups the admin's accounts are already members of."""
        engines = self.get_user_engines(admin_id)
        if not engines and self.engines:
            engines = self.engines
        if not engines:
            return {"success": False, "error": "বটের সাথে কোনো সক্রিয় অ্যাকাউন্ট নেই।"}

        engine = list(engines.values())[0]
        await engine.ensure_started()
        client = engine.client

        from pyrogram.raw import functions, types as raw_types

        try:
            dialogs_res = await client.invoke(
                functions.messages.GetDialogs(
                    offset_date=0,
                    offset_id=0,
                    offset_peer=raw_types.InputPeerEmpty(),
                    limit=limit_dialogs,
                    hash=0
                )
            )
            raw_chats = getattr(dialogs_res, "chats", [])
        except Exception as de:
            logger.warning(f"DiscoverDialogLive: GetDialogs error: {de}")
            return {"success": False, "error": f"গ্রুপ ও চ্যানেল লিস্ট লোড করতে সমস্যা হয়েছে: {de}"}

        if not raw_chats:
            return {"success": True, "total_scanned": 0, "total_live": 0, "live_streams": []}

        active_lives = []
        sem = asyncio.Semaphore(4)
        seen_ids = set()

        async def check_dialog_live(c):
            async with sem:
                if c.id in seen_ids:
                    return
                seen_ids.add(c.id)
                try:
                    full = None
                    if isinstance(c, raw_types.Channel):
                        full = await client.invoke(
                            functions.channels.GetFullChannel(
                                channel=raw_types.InputChannel(channel_id=c.id, access_hash=c.access_hash)
                            )
                        )
                    elif isinstance(c, raw_types.Chat):
                        full = await client.invoke(functions.messages.GetFullChat(chat_id=c.id))

                    if not full:
                        return

                    call = getattr(full.full_chat, "call", None)
                    if call and hasattr(call, "id"):
                        input_call = raw_types.InputGroupCall(id=call.id, access_hash=call.access_hash)
                        call_info = await client.invoke(functions.phone.GetGroupCall(call=input_call, limit=0))
                        gcall = getattr(call_info, "call", None)

                        p_count = getattr(gcall, "participants_count", 0) if gcall else 0
                        call_title = getattr(gcall, "title", None) or "Live Stream"
                        members_cnt = getattr(full.full_chat, "participants_count", 0)
                        online_cnt = getattr(full.full_chat, "online_count", 0) or 0
                        is_group = getattr(c, "megagroup", False) or isinstance(c, raw_types.Chat)

                        active_lives.append({
                            "chat_id": c.id,
                            "title": getattr(c, "title", "Group"),
                            "username": getattr(c, "username", None),
                            "call_id": call.id,
                            "call_title": call_title,
                            "live_participants": p_count,
                            "total_members": members_cnt,
                            "online_members": online_cnt,
                            "is_group": is_group
                        })
                except Exception as e:
                    logger.debug(f"DiscoverDialogLive: Check failed for {getattr(c, 'title', c.id)}: {e}")

        valid_chats = [c for c in raw_chats if isinstance(c, (raw_types.Channel, raw_types.Chat))]
        tasks = [check_dialog_live(c) for c in valid_chats]
        await asyncio.gather(*tasks, return_exceptions=True)

        active_lives.sort(key=lambda x: x["live_participants"], reverse=True)

        return {
            "success": True,
            "total_scanned": len(valid_chats),
            "total_live": len(active_lives),
            "live_streams": active_lives
        }

    async def discover_category_groups(self, admin_id: int, query: str, limit: int = 25, country: str = "GLOBAL") -> dict:
        """Searches Telegram public directory for channels & groups matching a category/keyword,
        retrieving total members, real-time online members count, and live stream status.
        Supports country-specific filtering (e.g. BD for Bangladesh)."""
        engines = self.get_user_engines(admin_id)
        if not engines and self.engines:
            engines = self.engines
        if not engines:
            return {"success": False, "error": "বটের সাথে কোনো সক্রিয় অ্যাকাউন্ট নেই।"}

        engine = list(engines.values())[0]
        await engine.ensure_started()
        client = engine.client

        from pyrogram.raw import functions, types as raw_types

        keywords = [k.strip() for k in re.split(r'[,;\n|]+', query) if k.strip()]
        if not keywords:
            keywords = [query.strip()] if query.strip() else []

        if not keywords:
            return {"success": True, "query": query, "country": country, "total_found": 0, "groups": []}

        # Country query expansion (e.g. inject local terms if specific country selected)
        expanded_keywords = list(keywords)
        if country and country.upper() != "GLOBAL":
            cfg = COUNTRY_CONFIGS.get(country.upper())
            if cfg:
                for base_kw in keywords[:5]:
                    for c_kw in cfg.get("keywords", [])[:4]:
                        combo = f"{base_kw} {c_kw}".strip()
                        if combo not in expanded_keywords:
                            expanded_keywords.append(combo)

        seen_chats = {}
        for kw in expanded_keywords[:30]:
            try:
                search_res = await client.invoke(
                    functions.contacts.Search(q=kw, limit=limit)
                )
                for c in getattr(search_res, "chats", []):
                    if c.id not in seen_chats:
                        seen_chats[c.id] = c
            except Exception as se:
                logger.warning(f"DiscoverGroups: Search error for '{kw}': {se}")

        raw_chats = list(seen_chats.values())
        if not raw_chats:
            return {"success": True, "query": query, "country": country, "total_found": 0, "groups": []}

        found_groups = []
        sem = asyncio.Semaphore(8)

        async def inspect_chat_info(c):
            async with sem:
                try:
                    full = None
                    if isinstance(c, raw_types.Channel):
                        full = await client.invoke(
                            functions.channels.GetFullChannel(
                                channel=raw_types.InputChannel(channel_id=c.id, access_hash=c.access_hash)
                            )
                        )
                    elif isinstance(c, raw_types.Chat):
                        full = await client.invoke(functions.messages.GetFullChat(chat_id=c.id))

                    if not full:
                        return

                    members_cnt = getattr(full.full_chat, "participants_count", 0) or 0
                    online_cnt = getattr(full.full_chat, "online_count", 0) or 0
                    call = getattr(full.full_chat, "call", None)
                    has_live = bool(call and hasattr(call, "id"))

                    is_group = getattr(c, "megagroup", False) or isinstance(c, raw_types.Chat)
                    c_title = getattr(c, "title", "Group")
                    c_username = getattr(c, "username", None)
                    matches_country = match_chat_country(c_title, c_username, country)

                    found_groups.append({
                        "chat_id": c.id,
                        "title": c_title,
                        "username": c_username,
                        "is_group": is_group,
                        "total_members": members_cnt,
                        "online_members": online_cnt,
                        "has_live": has_live,
                        "chat_type": "Supergroup" if is_group else "Channel",
                        "matches_country": matches_country,
                        "country_flag": COUNTRY_CONFIGS.get(country.upper(), {}).get("flag", "🌐") if matches_country else "🌐"
                    })
                except Exception as e:
                    logger.debug(f"DiscoverGroups: Check failed for {getattr(c, 'title', c.id)}: {e}")

        tasks = [inspect_chat_info(c) for c in raw_chats[:80]]
        await asyncio.gather(*tasks, return_exceptions=True)

        if country and country.upper() != "GLOBAL":
            found_groups = [g for g in found_groups if g.get("matches_country")]

        # Prioritize matching country, then Supergroups, then online members, then total members
        found_groups.sort(key=lambda x: (
            1 if x.get("matches_country") else 0,
            1 if x["is_group"] else 0,
            x["online_members"],
            x["total_members"]
        ), reverse=True)

        return {
            "success": True,
            "query": query,
            "country": country,
            "total_searched": len(raw_chats),
            "groups": found_groups
        }

    async def inspect_chat_active_members(self, admin_id: int, target: str, limit: int = 200) -> dict:
        """Extracts active and online members from a public/private Telegram supergroup or discussion group.
        Strictly for Admins. Categorizes users by status (Online, Recent, Inactive) and exports list."""
        engines = self.get_user_engines(admin_id)
        if not engines and self.engines:
            engines = self.engines
        if not engines:
            return {"success": False, "error": "বটের সাথে কোনো সক্রিয় টেলিগ্রাম অ্যাকাউন্ট যুক্ত নেই।"}

        engine = list(engines.values())[0]
        await engine.ensure_started()
        client = engine.client

        from pyrogram.enums import ChatType, UserStatus

        clean = target.strip()
        if clean.startswith("https://"):
            clean = clean.replace("https://", "")
        if clean.startswith("http://"):
            clean = clean.replace("http://", "")
        if clean.startswith("t.me/"):
            clean = clean.replace("t.me/", "")
        clean = clean.rstrip("/")

        is_invite = clean.startswith("+")
        chat_identifier = target.strip() if is_invite else (f"@{clean.lstrip('@')}" if not clean.startswith("-100") and not clean.isdigit() else int(clean))

        try:
            if is_invite:
                chat = await safe_join_or_get_chat(client, target.strip())
            else:
                chat = await safe_join_or_get_chat(client, chat_identifier)
        except Exception as ce:
            logger.warning(f"InspectGroup: Could not resolve chat {target}: {ce}")
            return {"success": False, "error": f"গ্রুপ বা চ্যানেলটি শনাক্ত করা যায়নি: {ce}"}

        target_chat = chat
        # If it's a broadcast channel, check if it has a linked discussion group!
        if getattr(chat, "type", None) == ChatType.CHANNEL:
            if getattr(chat, "linked_chat", None):
                target_chat = chat.linked_chat
            else:
                return {
                    "success": False,
                    "chat_title": getattr(chat, "title", str(chat.id)),
                    "error": (
                        "এটি একটি ব্রডকাস্ট চ্যানেল (গ্রুপ নয়) এবং এর কোনো পাবলিক ডিসকাশন গ্রুপ নেই।\n"
                        "💡 টেলিগ্রাম পলিসি অনুযায়ী চ্যানেলের মেম্বার লিস্ট শুধুমাত্র চ্যানেল অ্যাডমিন দেখতে পারেন। "
                        "তবে এই চ্যানেলে লাইভ স্ট্রিম চালু থাকলে `/inspectlive` দিয়ে সকল লাইভ মেম্বারদের দেখা ও মেসেজ পাঠানো যাবে!"
                    )
                }

        participants = []
        try:
            async for member in client.get_chat_members(target_chat.id, limit=limit):
                user = member.user
                if not user:
                    continue

                uid = user.id
                first = user.first_name or ""
                last = user.last_name or ""
                name = f"{first} {last}".strip() or f"User#{uid}"
                username = user.username
                is_bot = bool(user.is_bot)
                is_deleted = bool(user.is_deleted)

                activity_status = "inactive"
                status_label = "⚪ Inactive"

                u_status = user.status
                if u_status == UserStatus.ONLINE:
                    activity_status = "online"
                    status_label = "🟢 Online"
                elif u_status == UserStatus.RECENTLY:
                    activity_status = "recent"
                    status_label = "🟡 Recently Active"
                elif u_status == UserStatus.LAST_WEEK:
                    activity_status = "last_week"
                    status_label = "⚪ Last Week"
                elif u_status == UserStatus.LAST_MONTH:
                    activity_status = "last_month"
                    status_label = "⚪ Last Month"

                is_real_human = (not is_bot) and (not is_deleted)

                participants.append({
                    "user_id": uid,
                    "name": name,
                    "username": username,
                    "is_muted": True,
                    "is_speaking": False,
                    "is_bot": is_bot,
                    "is_deleted": is_deleted,
                    "activity_status": activity_status,
                    "status_label": status_label,
                    "is_real_human": is_real_human,
                })
        except Exception as me:
            logger.warning(f"InspectGroup: Error fetching members for {target_chat.id}: {me}")
            return {"success": False, "error": f"গ্রুপের মেম্বার লিস্ট সংগ্রহ করতে সমস্যা হয়েছে: {me}"}

        if not participants:
            return {"success": False, "error": "এই গ্রুপের কোনো মেম্বার পাওয়া যায়নি বা মেম্বার লিস্ট হাইড করা।"}

        real_humans = [p for p in participants if p.get("is_real_human")]
        active_humans = [p for p in real_humans if p.get("activity_status") in ("online", "recent")]
        inactive_humans = [p for p in real_humans if p.get("activity_status") not in ("online", "recent")]
        with_username_humans = [p for p in real_humans if p.get("username")]
        bots_and_channels = [p for p in participants if not p.get("is_real_human")]

        from pathlib import Path
        from datetime import datetime
        exports_dir = Path("exports")
        exports_dir.mkdir(exist_ok=True)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = exports_dir / f"group_members_{target_chat.id}_{timestamp}.txt"

        with open(filename, "w", encoding="utf-8") as f:
            f.write(f"=== Telegram Group Active Members ===\n")
            f.write(f"Target: {getattr(target_chat, 'title', '')} (@{getattr(target_chat, 'username', 'N/A')})\n")
            f.write(f"Scanned At: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write(f"Total Extracted: {len(participants)}\n")
            f.write(f"Real Humans: {len(real_humans)} (🟢 Online/Recent: {len(active_humans)} | ⚪ Inactive: {len(inactive_humans)})\n")
            f.write(f"Filtered (Bots/Deleted): {len(bots_and_channels)}\n\n")

            f.write(f"--- 🟢 ONLINE & RECENT ACTIVE ({len(active_humans)}) ---\n")
            for a in active_humans:
                u_str = f"@{a['username']}" if a['username'] else "(No Username)"
                f.write(f"{a.get('status_label', '')} {u_str} | {a['name']} | ID: {a['user_id']}\n")

            f.write(f"\n--- 👥 ALL REAL HUMANS ({len(real_humans)}) ---\n")
            for h in real_humans:
                u_str = f"@{h['username']}" if h['username'] else "(No Username)"
                f.write(f"{h.get('status_label', '')} {u_str} | {h['name']} | ID: {h['user_id']}\n")

            f.write(f"\n--- 📋 ALL USERNAMES ONLY ---\n")
            for p in real_humans:
                if p['username']:
                    f.write(f"@{p['username']}\n")

        return {
            "success": True,
            "chat_title": getattr(target_chat, "title", "Group"),
            "chat_username": getattr(target_chat, "username", None),
            "total_count": getattr(target_chat, "members_count", len(participants)),
            "extracted_count": len(participants),
            "speakers": [],
            "listeners": participants,
            "participants": participants,
            "real_humans": real_humans,
            "active_humans": active_humans,
            "inactive_humans": inactive_humans,
            "with_username_humans": with_username_humans,
            "bots_and_channels": bots_and_channels,
            "export_file": str(filename),
        }



