import logging
import aiohttp
import config
from typing import List

logger = logging.getLogger(__name__)

async def generate_ai_comments(user_topic_prompt: str, count: int = 5) -> List[str]:
    """
    Calls Google Gemini API to generate humanized live stream comments
    tailored to the user's live stream description.
    """
    api_key = config.GEMINI_API_KEY.strip()
    if not api_key:
        logger.warning("GEMINI_API_KEY not set in .env! Using smart fallback generator.")
        return _fallback_generator(user_topic_prompt, count)

    prompt = (
        f"You are generating realistic, natural, human live chat comments for a Telegram live stream.\n"
        f"Live Topic / User Instruction: \"{user_topic_prompt}\"\n\n"
        f"Rules:\n"
        f"1. Generate exactly {count} distinct, human-like live chat comments.\n"
        f"2. Keep each comment short (1-8 words, like real viewers in a stream).\n"
        f"3. Include natural emojis occasionally.\n"
        f"4. If the topic is in Bengali or Banglish, generate in Bengali / Banglish. If English, generate in English.\n"
        f"5. Output only the comments, one per line. No numbers, no bullet points, no quotation marks."
    )

    url = f"https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent?key={api_key}"
    payload = {
        "contents": [{
            "parts": [{"text": prompt}]
        }],
        "generationConfig": {
            "temperature": 0.9,
            "maxOutputTokens": 600
        }
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=payload, timeout=aiohttp.ClientTimeout(total=15)) as resp:
                if resp.status == 200:
                    data = await resp.json()
                    candidates = data.get("candidates", [])
                    if candidates:
                        content_parts = candidates[0].get("content", {}).get("parts", [])
                        if content_parts:
                            text = content_parts[0].get("text", "").strip()
                            comments = [line.strip().strip('"\'•-*0123456789. ') for line in text.split("\n") if line.strip()]
                            if comments:
                                return comments[:count]
                else:
                    err_text = await resp.text()
                    logger.error(f"Gemini API returned status {resp.status}: {err_text}")
    except Exception as e:
        logger.error(f"Error calling Gemini API: {e}")

    # If API call fails or returns empty, use smart fallback
    return _fallback_generator(user_topic_prompt, count)

def _fallback_generator(user_topic: str, count: int) -> List[str]:
    """Smart fallback if Gemini API Key is missing or unreachable."""
    base_comments = [
        f"{user_topic} niye khub valo bolchen! 🔥",
        f"Very good points on {user_topic} 👍",
        "Listening carefully bro ❤️",
        "Aro details bolun ei bishoye",
        f"Super helpful session about {user_topic} 👏",
        "Clear explanation bro!",
        "Agreed with this point 💯",
        "Keep going brother! 🙌",
        "Awesome live stream today 🔥",
        "Sundor vabe bujhiye bollen 👍"
    ]
    import random
    random.shuffle(base_comments)
    return base_comments[:count]
