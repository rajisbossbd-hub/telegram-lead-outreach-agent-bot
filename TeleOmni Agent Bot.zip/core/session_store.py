import json
from pathlib import Path
from typing import Dict, List, Optional
import config

REGISTRY_FILE = config.SESSIONS_DIR / "accounts.json"

def load_accounts_registry() -> Dict[str, dict]:
    """Loads accounts metadata from accounts.json"""
    if not REGISTRY_FILE.exists():
        return {}
    try:
        with open(REGISTRY_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}

def save_accounts_registry(data: Dict[str, dict]):
    """Saves accounts metadata to accounts.json"""
    with open(REGISTRY_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)

def add_account_metadata(
    session_name: str,
    user_id: int,
    first_name: str,
    owner_id: int,
    phone: str = "",
    username: str = "",
    session_string: str = ""
):
    registry = load_accounts_registry()
    registry[session_name] = {
        "session_name": session_name,
        "user_id": user_id,
        "first_name": first_name,
        "owner_id": owner_id,
        "phone": phone,
        "username": username,
        "session_string": session_string
    }
    save_accounts_registry(registry)

def remove_account_metadata(session_name: str, owner_id: Optional[int] = None) -> bool:
    registry = load_accounts_registry()
    if session_name in registry:
        # If owner_id is passed, ensure the user owns this account
        if owner_id is not None and registry[session_name].get("owner_id") != owner_id:
            return False
        del registry[session_name]
        save_accounts_registry(registry)
        return True
    return False

def get_user_accounts_registry(owner_id: int) -> Dict[str, dict]:
    """Returns only the accounts belonging to a specific owner."""
    registry = load_accounts_registry()
    return {k: v for k, v in registry.items() if v.get("owner_id") == owner_id}
