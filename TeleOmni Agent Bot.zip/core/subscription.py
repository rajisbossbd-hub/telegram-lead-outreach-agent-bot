import os
import json
from datetime import datetime
from pathlib import Path
from typing import Tuple, List
import config

DATA_FILE = config.SESSIONS_DIR / "subscriptions.json"
FREE_DAILY_AI_LIMIT = 10
FREE_DAILY_MANUAL_LIMIT = 5
FREE_DAILY_LIVE_VOICE_LIMIT = 1
FREE_DAILY_POLL_ACCOUNT_LIMIT = 5
FREE_DAILY_ENGAGE_ACCOUNT_LIMIT = 5
FREE_LIVE_ACCOUNT_LIMIT = 5

def _get_today_str() -> str:
    return datetime.now().strftime("%Y-%m-%d")

def _load_data() -> dict:
    if not DATA_FILE.exists():
        return {"vip_users": [], "daily_usage": {}, "daily_manual_usage": {}}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"vip_users": [], "daily_usage": {}, "daily_manual_usage": {}}

def _save_data(data: dict):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)

def get_super_admin_id() -> int:
    """Returns the primary Super Admin (Owner) ID."""
    return config.ADMIN_IDS[0] if config.ADMIN_IDS else 7029098905

def is_super_admin(user_id: int) -> bool:
    """Returns True ONLY for the single Super Admin (Owner)."""
    return user_id == get_super_admin_id()

def is_admin(user_id: int) -> bool:
    """Super Admin and added Admins have admin panel access."""
    if is_super_admin(user_id):
        return True
    data = _load_data()
    return user_id in data.get("admins", []) or user_id in config.ADMIN_IDS

def is_vip(user_id: int) -> bool:
    """Admins and VIP subscribers have unlimited comment access."""
    if is_admin(user_id):
        return True
    data = _load_data()
    return user_id in data.get("vip_users", [])

def get_daily_usage(user_id: int) -> int:
    data = _load_data()
    today = _get_today_str()
    return data.get("daily_usage", {}).get(today, {}).get(str(user_id), 0)

def can_use_ai(user_id: int) -> Tuple[bool, int, int]:
    """
    Checks whether user can generate an AI comment today.
    Returns: (can_use, current_used_count, total_limit)
    """
    if is_vip(user_id):
        used = get_daily_usage(user_id)
        return True, used, 999999

    used = get_daily_usage(user_id)
    if used < FREE_DAILY_AI_LIMIT:
        return True, used, FREE_DAILY_AI_LIMIT
    return False, used, FREE_DAILY_AI_LIMIT

def get_remaining_ai_balance(user_id: int) -> int:
    """Returns how many AI messages/comments remaining for this user today."""
    if is_vip(user_id):
        return 999999
    used = get_daily_usage(user_id)
    return max(0, FREE_DAILY_AI_LIMIT - used)

def record_ai_usage(user_id: int, count: int = 1) -> int:
    """Increments and returns new AI usage count for today based on messages sent."""
    data = _load_data()
    today = _get_today_str()
    
    if "daily_usage" not in data:
        data["daily_usage"] = {}
    if today not in data["daily_usage"]:
        # Prune older dates to keep file small (keep last 7 days)
        keys = sorted(list(data["daily_usage"].keys()))
        if len(keys) > 7:
            for old_key in keys[:-7]:
                data["daily_usage"].pop(old_key, None)
        data["daily_usage"][today] = {}

    user_key = str(user_id)
    current = data["daily_usage"][today].get(user_key, 0)
    data["daily_usage"][today][user_key] = current + count
    _save_data(data)
    return current + count

def get_daily_manual_usage(user_id: int) -> int:
    data = _load_data()
    today = _get_today_str()
    return data.get("daily_manual_usage", {}).get(today, {}).get(str(user_id), 0)

def can_use_manual(user_id: int) -> Tuple[bool, int, int]:
    """
    Checks whether user can send a manual comment today.
    Returns: (can_use, current_used_count, total_limit)
    """
    if is_vip(user_id):
        used = get_daily_manual_usage(user_id)
        return True, used, 999999

    used = get_daily_manual_usage(user_id)
    if used < FREE_DAILY_MANUAL_LIMIT:
        return True, used, FREE_DAILY_MANUAL_LIMIT
    return False, used, FREE_DAILY_MANUAL_LIMIT

def get_remaining_manual_balance(user_id: int) -> int:
    """Returns how many manual comments/messages remaining for this user today."""
    if is_vip(user_id):
        return 999999
    used = get_daily_manual_usage(user_id)
    return max(0, FREE_DAILY_MANUAL_LIMIT - used)

def record_manual_usage(user_id: int, count: int = 1) -> int:
    """Increments and returns new manual comment usage count for today based on messages sent."""
    data = _load_data()
    today = _get_today_str()

    if "daily_manual_usage" not in data:
        data["daily_manual_usage"] = {}
    if today not in data["daily_manual_usage"]:
        # Prune older dates to keep file small (keep last 7 days)
        keys = sorted(list(data["daily_manual_usage"].keys()))
        if len(keys) > 7:
            for old_key in keys[:-7]:
                data["daily_manual_usage"].pop(old_key, None)
        data["daily_manual_usage"][today] = {}

    user_key = str(user_id)
    current = data["daily_manual_usage"][today].get(user_key, 0)
    data["daily_manual_usage"][today][user_key] = current + count
    _save_data(data)
    return current + count

# ----------------- LIVE VOICE LIMITS (Free: 1 voice/day) -----------------

def get_daily_live_voice_usage(user_id: int) -> int:
    data = _load_data()
    today = _get_today_str()
    return data.get("daily_live_voice_usage", {}).get(today, {}).get(str(user_id), 0)

def can_use_live_voice(user_id: int) -> Tuple[bool, int, int]:
    """
    Checks whether user can play/send a live voice today.
    Returns: (can_use, current_used_count, total_limit)
    """
    if is_vip(user_id):
        used = get_daily_live_voice_usage(user_id)
        return True, used, 999999

    used = get_daily_live_voice_usage(user_id)
    if used < FREE_DAILY_LIVE_VOICE_LIMIT:
        return True, used, FREE_DAILY_LIVE_VOICE_LIMIT
    return False, used, FREE_DAILY_LIVE_VOICE_LIMIT

def get_remaining_live_voice_balance(user_id: int) -> int:
    if is_vip(user_id):
        return 999999
    used = get_daily_live_voice_usage(user_id)
    return max(0, FREE_DAILY_LIVE_VOICE_LIMIT - used)

def record_live_voice_usage(user_id: int, count: int = 1) -> int:
    data = _load_data()
    today = _get_today_str()
    if "daily_live_voice_usage" not in data:
        data["daily_live_voice_usage"] = {}
    if today not in data["daily_live_voice_usage"]:
        keys = sorted(list(data["daily_live_voice_usage"].keys()))
        if len(keys) > 7:
            for old_key in keys[:-7]:
                data["daily_live_voice_usage"].pop(old_key, None)
        data["daily_live_voice_usage"][today] = {}

    user_key = str(user_id)
    current = data["daily_live_voice_usage"][today].get(user_key, 0)
    data["daily_live_voice_usage"][today][user_key] = current + count
    _save_data(data)
    return current + count

# ----------------- POLL VOTE LIMITS (Free: 5 accounts/day) -----------------

def get_daily_poll_usage(user_id: int) -> int:
    data = _load_data()
    today = _get_today_str()
    return data.get("daily_poll_usage", {}).get(today, {}).get(str(user_id), 0)

def can_use_poll_vote(user_id: int, requested_accounts: int = 1) -> Tuple[bool, int, int, int]:
    """
    Checks whether user can vote in a poll today.
    Returns: (can_use, allowed_count, used_count, total_limit)
    """
    if is_vip(user_id):
        used = get_daily_poll_usage(user_id)
        return True, requested_accounts, used, 999999

    used = get_daily_poll_usage(user_id)
    remaining = max(0, FREE_DAILY_POLL_ACCOUNT_LIMIT - used)
    if remaining <= 0:
        return False, 0, used, FREE_DAILY_POLL_ACCOUNT_LIMIT
    allowed = min(requested_accounts, remaining)
    return True, allowed, used, FREE_DAILY_POLL_ACCOUNT_LIMIT

def get_remaining_poll_balance(user_id: int) -> int:
    if is_vip(user_id):
        return 999999
    used = get_daily_poll_usage(user_id)
    return max(0, FREE_DAILY_POLL_ACCOUNT_LIMIT - used)

def record_poll_usage(user_id: int, count: int = 1) -> int:
    data = _load_data()
    today = _get_today_str()
    if "daily_poll_usage" not in data:
        data["daily_poll_usage"] = {}
    if today not in data["daily_poll_usage"]:
        keys = sorted(list(data["daily_poll_usage"].keys()))
        if len(keys) > 7:
            for old_key in keys[:-7]:
                data["daily_poll_usage"].pop(old_key, None)
        data["daily_poll_usage"][today] = {}

    user_key = str(user_id)
    current = data["daily_poll_usage"][today].get(user_key, 0)
    data["daily_poll_usage"][today][user_key] = current + count
    _save_data(data)
    return current + count

# ----------------- POST VIEWS & REACTIONS LIMITS (Free: 5 accounts/day) -----------------

def get_daily_engage_usage(user_id: int) -> int:
    data = _load_data()
    today = _get_today_str()
    return data.get("daily_engage_usage", {}).get(today, {}).get(str(user_id), 0)

def can_use_post_engage(user_id: int, requested_accounts: int = 1) -> Tuple[bool, int, int, int]:
    """
    Checks whether user can view/react to posts today.
    Returns: (can_use, allowed_count, used_count, total_limit)
    """
    if is_vip(user_id):
        used = get_daily_engage_usage(user_id)
        return True, requested_accounts, used, 999999

    used = get_daily_engage_usage(user_id)
    remaining = max(0, FREE_DAILY_ENGAGE_ACCOUNT_LIMIT - used)
    if remaining <= 0:
        return False, 0, used, FREE_DAILY_ENGAGE_ACCOUNT_LIMIT
    allowed = min(requested_accounts, remaining)
    return True, allowed, used, FREE_DAILY_ENGAGE_ACCOUNT_LIMIT

def get_remaining_engage_balance(user_id: int) -> int:
    if is_vip(user_id):
        return 999999
    used = get_daily_engage_usage(user_id)
    return max(0, FREE_DAILY_ENGAGE_ACCOUNT_LIMIT - used)

def record_engage_usage(user_id: int, count: int = 1) -> int:
    data = _load_data()
    today = _get_today_str()
    if "daily_engage_usage" not in data:
        data["daily_engage_usage"] = {}
    if today not in data["daily_engage_usage"]:
        keys = sorted(list(data["daily_engage_usage"].keys()))
        if len(keys) > 7:
            for old_key in keys[:-7]:
                data["daily_engage_usage"].pop(old_key, None)
        data["daily_engage_usage"][today] = {}

    user_key = str(user_id)
    current = data["daily_engage_usage"][today].get(user_key, 0)
    data["daily_engage_usage"][today][user_key] = current + count
    _save_data(data)
    return current + count

def get_admins_list() -> List[int]:
    """Returns all admin IDs (Super Admin + added Admins)."""
    data = _load_data()
    super_admin = get_super_admin_id()
    admin_set = set([super_admin])
    for aid in config.ADMIN_IDS:
        admin_set.add(aid)
    for aid in data.get("admins", []):
        admin_set.add(aid)
    return list(admin_set)

def add_admin_user(user_id: int) -> bool:
    """Any admin or Super Admin can add a new Admin."""
    data = _load_data()
    admins = set(data.get("admins", []))
    admins.add(user_id)
    data["admins"] = list(admins)
    _save_data(data)
    return True

def remove_admin_user(user_id: int, requester_id: int) -> Tuple[bool, str]:
    """
    Only the single Super Admin (Owner) can remove an added admin.
    Super Admin can never be removed.
    Added admins cannot remove any admin.
    """
    if not is_super_admin(requester_id):
        return False, "ONLY_SUPER_ADMIN"
    if is_super_admin(user_id):
        return False, "CANNOT_REMOVE_SUPER_ADMIN"

    data = _load_data()
    admins = set(data.get("admins", []))
    if user_id in admins:
        admins.discard(user_id)
        data["admins"] = list(admins)
        _save_data(data)
        return True, "SUCCESS"
    return False, "NOT_AN_ADMIN"

def get_vip_list() -> List[int]:
    """Returns pure VIP subscribers (excluding Admins)."""
    data = _load_data()
    return data.get("vip_users", [])

def add_vip_user(user_id: int) -> bool:
    """Adds a customer to VIP subscription (unlimited comments, NO admin panel)."""
    data = _load_data()
    vips = set(data.get("vip_users", []))
    vips.add(user_id)
    data["vip_users"] = list(vips)
    _save_data(data)
    clear_live_cooldown(user_id)
    return True

def remove_vip_user(user_id: int) -> bool:
    """Removes a customer from VIP subscription."""
    data = _load_data()
    vips = set(data.get("vip_users", []))
    vips.discard(user_id)
    data["vip_users"] = list(vips)
    _save_data(data)
    return True

def get_user_badge_info(user_id: int) -> dict:
    """
    Returns role, symbolic representation, and badges for a user.
    VIP members have a proud symbolic diamond/vip status.
    Free users have a free badge symbol.
    """
    if is_super_admin(user_id):
        return {
            "role": "super_admin",
            "symbol": "👑",
            "badge_bn": "👑 [SUPER ADMIN - OWNER]",
            "badge_en": "👑 [SUPER ADMIN - OWNER]",
            "title_bn": "সুপার অ্যাডমিন (মালিক)",
            "title_en": "Super Admin (Owner)",
            "is_vip": True
        }
    elif is_admin(user_id):
        return {
            "role": "admin",
            "symbol": "🛡️",
            "badge_bn": "🛡️ [SYSTEM ADMIN]",
            "badge_en": "🛡️ [SYSTEM ADMIN]",
            "title_bn": "সিস্টেম অ্যাডমিন",
            "title_en": "System Admin",
            "is_vip": True
        }
    elif is_vip(user_id):
        return {
            "role": "vip",
            "symbol": "💎",
            "badge_bn": "💎 [VIP ELITE MEMBER]",
            "badge_en": "💎 [VIP ELITE MEMBER]",
            "title_bn": "ভিআইপি মেম্বার (আনলিমিটেড)",
            "title_en": "VIP Elite Member (Unlimited)",
            "is_vip": True
        }
    else:
        return {
            "role": "normal",
            "symbol": "👤",
            "badge_bn": "👤 [NORMAL USER]",
            "badge_en": "👤 [NORMAL USER]",
            "title_bn": "সাধারণ ইউজার (Normal User)",
            "title_en": "Normal User (Standard)",
            "is_vip": False
        }

NORMAL_USER_LIVE_LIMIT_SECONDS = int(os.getenv("NORMAL_USER_LIVE_LIMIT_SECONDS", str(30 * 60)))      # 30 minutes continuous limit
NORMAL_USER_LIVE_COOLDOWN_SECONDS = int(os.getenv("NORMAL_USER_LIVE_COOLDOWN_SECONDS", str(10 * 60)))   # 10 minutes cooldown break

def can_join_live(user_id: int) -> Tuple[bool, int]:
    """
    Checks if a user can join a live stream.
    VIPs and Admins can always join (unlimited duration, zero cooldown).
    Normal users must wait out any active 10-minute cooldown.
    Returns: (can_join: bool, remaining_cooldown_seconds: int)
    """
    if is_vip(user_id):
        return True, 0

    import time
    data = _load_data()
    cooldowns = data.get("live_cooldowns", {})
    cooldown_until = cooldowns.get(str(user_id), 0)
    now = time.time()
    if now < cooldown_until:
        return False, int(cooldown_until - now)
    return True, 0

def set_live_cooldown(user_id: int, duration_seconds: int = NORMAL_USER_LIVE_COOLDOWN_SECONDS):
    """Sets a cooldown timestamp for a user after continuous live session expires."""
    import time
    data = _load_data()
    if "live_cooldowns" not in data:
        data["live_cooldowns"] = {}
    data["live_cooldowns"][str(user_id)] = time.time() + duration_seconds
    _save_data(data)

def clear_live_cooldown(user_id: int):
    """Clears cooldown for a user (e.g. when upgraded to VIP)."""
    data = _load_data()
    if "live_cooldowns" in data and str(user_id) in data["live_cooldowns"]:
        data["live_cooldowns"].pop(str(user_id), None)
        _save_data(data)
