import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional
import config

logger = logging.getLogger("AutoLiveJoiner")

DATA_FILE = config.SESSIONS_DIR / "auto_live_targets.json"

def _load_data() -> dict:
    if not DATA_FILE.exists():
        return {"targets": []}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Error loading auto live targets: {e}")
        return {"targets": []}

def _save_data(data: dict):
    try:
        DATA_FILE.parent.mkdir(parents=True, exist_ok=True)
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    except Exception as e:
        logger.error(f"Error saving auto live targets: {e}")

def get_user_live_targets(user_id: int) -> List[dict]:
    """Returns all auto live targets created by a user."""
    data = _load_data()
    return [t for t in data.get("targets", []) if t.get("user_id") == user_id]

def get_live_target_by_id(target_id: str) -> Optional[dict]:
    """Finds a target by its unique ID."""
    data = _load_data()
    for t in data.get("targets", []):
        if t.get("id") == target_id:
            return t
    return None

def get_all_active_live_targets() -> List[dict]:
    """Returns all active auto live targets across all users."""
    data = _load_data()
    return [t for t in data.get("targets", []) if t.get("is_active", True)]

def add_live_target(
    user_id: int,
    target_input: str,
    chat_id: int,
    title: str,
    username: str = "",
    invite_link: str = "",
    accounts_count: int = 0
) -> dict:
    """Adds or updates an auto live join target for a user.
    accounts_count = 0 means ALL user accounts.
    """
    data = _load_data()
    targets = data.get("targets", [])

    existing = None
    for t in targets:
        if t.get("user_id") == user_id and (t.get("chat_id") == chat_id or t.get("target_input") == target_input):
            existing = t
            break

    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    if existing:
        existing["target_input"] = target_input
        existing["chat_title"] = title
        existing["chat_username"] = username
        existing["invite_link"] = invite_link
        existing["accounts_count"] = accounts_count
        existing["is_active"] = True
        existing["updated_at"] = now_str
        _save_data(data)
        return existing
    else:
        target_id = f"live_{user_id}_{abs(chat_id) if chat_id else abs(hash(target_input)) % 10000000}"
        new_target = {
            "id": target_id,
            "user_id": user_id,
            "target_input": target_input,
            "chat_id": chat_id,
            "chat_title": title or target_input,
            "chat_username": username,
            "invite_link": invite_link,
            "accounts_count": accounts_count,
            "is_active": True,
            "is_currently_live": False,
            "last_live_id": None,
            "total_auto_joins": 0,
            "last_joined_at": None,
            "created_at": now_str
        }
        targets.append(new_target)
        data["targets"] = targets
        _save_data(data)
        return new_target

def toggle_live_target(target_id: str) -> bool:
    """Toggles active status of a target."""
    data = _load_data()
    for t in data.get("targets", []):
        if t.get("id") == target_id:
            t["is_active"] = not t.get("is_active", True)
            _save_data(data)
            return t["is_active"]
    return False

def update_live_target_count(target_id: str, count: int) -> bool:
    """Updates accounts count for a target."""
    data = _load_data()
    for t in data.get("targets", []):
        if t.get("id") == target_id:
            t["accounts_count"] = max(0, count)
            _save_data(data)
            return True
    return False

def update_live_target_status(
    target_id: str,
    is_live: bool,
    live_id: Optional[int] = None,
    increment_joins: bool = False
):
    """Updates runtime live status and join counters."""
    data = _load_data()
    for t in data.get("targets", []):
        if t.get("id") == target_id:
            t["is_currently_live"] = is_live
            if live_id is not None:
                t["last_live_id"] = live_id
            if increment_joins:
                t["total_auto_joins"] = t.get("total_auto_joins", 0) + 1
                t["last_joined_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            _save_data(data)
            break

def delete_live_target(target_id: str) -> bool:
    """Deletes a live target."""
    data = _load_data()
    targets = data.get("targets", [])
    before_len = len(targets)
    targets = [t for t in targets if t.get("id") != target_id]
    if len(targets) < before_len:
        data["targets"] = targets
        _save_data(data)
        return True
    return False
