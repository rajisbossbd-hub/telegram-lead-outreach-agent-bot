import logging
import asyncio
import re
from typing import Optional, Union
from pyrogram import Client
from pyrogram.errors import UserAlreadyParticipant, InviteHashExpired, UserBannedInChannel
import pyrogram.raw.types
if not hasattr(pyrogram.raw.types, "PhoneCallDiscardReasonMigrateConferenceCall"):
    class PhoneCallDiscardReasonMigrateConferenceCall:
        pass
    pyrogram.raw.types.PhoneCallDiscardReasonMigrateConferenceCall = PhoneCallDiscardReasonMigrateConferenceCall
if not hasattr(pyrogram.raw.types, "InputGroupCallSlug"):
    class InputGroupCallSlug:
        def __init__(self, slug=""):
            self.slug = slug
    pyrogram.raw.types.InputGroupCallSlug = InputGroupCallSlug

import pyrogram.raw.functions.phone
if hasattr(pyrogram.raw.functions.phone, "JoinGroupCall"):
    _orig_join_group_call_init = pyrogram.raw.functions.phone.JoinGroupCall.__init__
    def _patched_join_group_call_init(self, *args, **kwargs):
        kwargs.pop("public_key", None)
        kwargs.pop("block", None)
        return _orig_join_group_call_init(self, *args, **kwargs)
    pyrogram.raw.functions.phone.JoinGroupCall.__init__ = _patched_join_group_call_init

import pyrogram.utils
pyrogram.utils.MIN_CHANNEL_ID = -10099999999999

from pytgcalls import PyTgCalls
from pytgcalls.types import GroupCallConfig
try:
    from pytgcalls.exceptions import NoActiveGroupCall
except ImportError:
    class NoActiveGroupCall(Exception):
        pass

logger = logging.getLogger(__name__)

def parse_target(target: Union[str, int]) -> Union[str, int]:
    if isinstance(target, int):
        return target
    target_str = str(target).strip()
    if target_str.lstrip("-").isdigit():
        return int(target_str)
    if "+" in target_str or "joinchat" in target_str:
        return target_str
    cleaned = re.sub(r"^(?:https?://)?(?:www\.)?(?:t\.me|telegram\.me)/", "", target_str)
    return cleaned.strip("/@")


class AccountCallEngine:
    def __init__(self, client: Client, account_id: str, owner_id: int):
        self.client = client
        self.account_id = account_id
        self.owner_id = owner_id
        self.pytgcalls = PyTgCalls(self.client)
        self.current_chat_id: Optional[int] = None
        self.current_chat_title: Optional[str] = None
        self.is_connected = False
        self.in_call = False
        self.current_audio_file: Optional[str] = None
        self.is_looping = False
        self.is_playing = False
        self.muted_by_admin = True
        self._register_call_events()

    async def start(self):
        """Starts both MTProto client and WebRTC voice engine."""
        if not self.client.is_connected:
            await self.client.start()
        try:
            await self.pytgcalls.start()
            self.is_connected = True
        except Exception as e:
            logger.error(f"[{self.account_id}] PyTgCalls start failed: {e}")

    async def stop(self):
        """Stops voice engine and MTProto client."""
        try:
            if self.in_call and self.current_chat_id:
                await self.leave_call()
        except Exception:
            pass
        try:
            await self.pytgcalls.stop()
        except Exception:
            pass
        self.is_connected = False

    async def ensure_started(self):
        """Ensures both MTProto client and WebRTC voice engine are connected and ready."""
        if not self.client.is_connected:
            try:
                await self.client.start()
            except Exception as e:
                logger.error(f"[{self.account_id}] Client auto-start failed: {e}")
                raise e
        if not self.is_connected:
            try:
                await self.pytgcalls.start()
                self.is_connected = True
            except Exception as e:
                logger.warning(f"[{self.account_id}] PyTgCalls auto-start failed: {e}")

    async def join_chat_if_needed(self, chat_target: Union[str, int]) -> tuple:
        """Ensures the user account is a member of the group/channel."""
        await self.ensure_started()
        parsed = parse_target(chat_target)
        from core.account_manager import safe_join_or_get_chat
        try:
            chat = await safe_join_or_get_chat(self.client, parsed)
        except Exception as e:
            logger.error(f"[{self.account_id}] Error joining/getting chat {parsed}: {e}")
            raise e

        return chat.id, getattr(chat, "title", str(chat_target))

    async def join_live(self, chat_target: Union[str, int]) -> dict:
        """Joins the active voice chat / live stream."""
        chat_id, chat_title = await self.join_chat_if_needed(chat_target)

        active_calls = await self.pytgcalls.calls
        if chat_id in active_calls:
            self.in_call = True
            self.current_chat_id = chat_id
            self.current_chat_title = chat_title
            return {"success": True, "message": "Already in call", "chat_id": chat_id, "title": chat_title}

        try:
            await self.pytgcalls.play(
                chat_id=chat_id,
                stream=None,
                config=GroupCallConfig(auto_start=False)
            )
            try:
                await self.pytgcalls.mute(chat_id)
            except Exception:
                pass

            self.in_call = True
            self.current_chat_id = chat_id
            self.current_chat_title = chat_title
            self.muted_by_admin = True
            self.is_playing = False
            self.current_audio_file = None
            logger.info(f"[{self.account_id}] Successfully joined live in {chat_title} ({chat_id})")
            return {"success": True, "message": "Joined successfully", "chat_id": chat_id, "title": chat_title}

        except NoActiveGroupCall:
            logger.warning(f"[{self.account_id}] No active voice chat/live found in {chat_title}")
            return {"success": False, "error": "No active Live/Voice Chat in this group or channel."}
        except Exception as e:
            logger.error(f"[{self.account_id}] Error joining live: {e}")
            return {"success": False, "error": str(e)}

    async def leave_call(self, chat_id: Optional[int] = None) -> dict:
        """Leaves the current or specified voice chat/live stream."""
        target_id = chat_id or self.current_chat_id
        if not target_id:
            return {"success": True, "message": "Not in any call"}

        try:
            await self.pytgcalls.leave_call(target_id)
            self.in_call = False
            self.current_chat_id = None
            self.current_chat_title = None
            self.muted_by_admin = True
            self.is_playing = False
            self.current_audio_file = None
            return {"success": True, "message": "Left call successfully"}
        except Exception as e:
            logger.warning(f"[{self.account_id}] Error leaving call: {e}")
            self.in_call = False
            self.current_chat_id = None
            self.muted_by_admin = True
            self.is_playing = False
            self.current_audio_file = None
            return {"success": False, "error": str(e)}

    async def sync_call_status(self) -> bool:
        """Verifies with PyTgCalls whether the account is still in an active call."""
        if not self.in_call or not self.current_chat_id:
            self.in_call = False
            return False
        if not self.is_connected:
            self.in_call = False
            self.current_chat_id = None
            return False
        try:
            active_calls = await self.pytgcalls.calls
            if self.current_chat_id not in active_calls:
                logger.info(f"[{self.account_id}] Live call {self.current_chat_id} is no longer active in PyTgCalls. Syncing state to Idle.")
                self.in_call = False
                self.current_chat_id = None
                self.current_chat_title = None
                self.muted_by_admin = True
                self.is_playing = False
                self.current_audio_file = None
                return False
        except Exception as e:
            logger.debug(f"[{self.account_id}] sync_call_status check error: {e}")
        return self.in_call

    def _register_call_events(self):
        """Registers PyTgCalls event handlers to auto-unmute and play when host enables mic."""
        try:
            from pytgcalls.types import UpdatedGroupCallParticipant, StreamEnded, ChatUpdate

            @self.pytgcalls.on_update()
            async def _handle_call_update(client, update):
                if isinstance(update, ChatUpdate):
                    try:
                        if update.status in [
                            ChatUpdate.Status.CLOSED_VOICE_CHAT,
                            ChatUpdate.Status.DISCARDED_CALL,
                            ChatUpdate.Status.KICKED,
                            ChatUpdate.Status.LEFT_GROUP,
                        ]:
                            logger.info(f"[{self.account_id}] Live/Voice stream ended or closed ({update.status}). Auto-resetting state to Idle.")
                            self.in_call = False
                            self.current_chat_id = None
                            self.current_chat_title = None
                            self.muted_by_admin = True
                            self.is_playing = False
                            self.current_audio_file = None
                    except Exception as ce:
                        logger.debug(f"ChatUpdate handling error: {ce}")

                elif isinstance(update, UpdatedGroupCallParticipant):
                    try:
                        me = getattr(self.client, "me", None)
                        if not me:
                            me = await self.client.get_me()
                        if me and update.participant.user_id == me.id:
                            # If host unmuted our mic in live
                            if not update.participant.muted_by_admin:
                                try:
                                    await self.pytgcalls.unmute(update.chat_id)
                                except Exception:
                                    pass
                                # ONLY start playing if audio was loaded and NOT already playing
                                if self.current_audio_file and self.in_call and not self.is_playing:
                                    logger.info(f"[{self.account_id}] Live host unmuted mic, starting audio playback in {update.chat_id}")
                                    self.is_playing = True
                                    try:
                                        from pytgcalls.types import MediaStream, AudioQuality
                                        stream = MediaStream(
                                            media_path=self.current_audio_file,
                                            audio_parameters=AudioQuality.HIGH,
                                            video_flags=MediaStream.Flags.IGNORE
                                        )
                                        await self.pytgcalls.play(update.chat_id, stream=stream)
                                    except Exception as err:
                                        self.is_playing = False
                                        logger.debug(f"Auto-play voice on host unmute: {err}")
                    except Exception as ex:
                        logger.debug(f"Participant update processing error: {ex}")

                elif isinstance(update, StreamEnded):
                    if self.is_looping and self.current_audio_file and self.in_call and self.current_chat_id:
                        try:
                            from pytgcalls.types import MediaStream, AudioQuality
                            stream = MediaStream(
                                media_path=self.current_audio_file,
                                audio_parameters=AudioQuality.HIGH,
                                video_flags=MediaStream.Flags.IGNORE
                            )
                            await self.pytgcalls.play(self.current_chat_id, stream=stream)
                        except Exception as ex:
                            logger.debug(f"Stream loop restart error: {ex}")
                    else:
                        self.is_playing = False
                        self.current_audio_file = None
                        try:
                            await self.mute()
                        except Exception:
                            pass
                        logger.info(f"[{self.account_id}] Voice playback finished (Played once). Mic muted.")
        except Exception as e:
            logger.debug(f"Could not register call events: {e}")

    async def get_input_group_call(self) -> Optional[pyrogram.raw.types.InputGroupCall]:
        """Resolves active raw InputGroupCall for the active chat directly via Telegram MTProto."""
        if not self.current_chat_id:
            return None
        try:
            peer = await self.client.resolve_peer(self.current_chat_id)
            if isinstance(peer, (pyrogram.raw.types.InputPeerChannel, pyrogram.raw.types.InputChannel)):
                full = await self.client.invoke(
                    pyrogram.raw.functions.channels.GetFullChannel(
                        channel=pyrogram.raw.types.InputChannel(
                            channel_id=peer.channel_id,
                            access_hash=peer.access_hash,
                        )
                    )
                )
                call = getattr(full.full_chat, "call", None)
                if call:
                    if isinstance(call, pyrogram.raw.types.InputGroupCall):
                        return call
                    elif hasattr(call, "id") and hasattr(call, "access_hash"):
                        return pyrogram.raw.types.InputGroupCall(id=call.id, access_hash=call.access_hash)
            elif isinstance(peer, (pyrogram.raw.types.InputPeerChat, pyrogram.raw.types.InputChat)):
                full = await self.client.invoke(
                    pyrogram.raw.functions.messages.GetFullChat(chat_id=peer.chat_id)
                )
                call = getattr(full.full_chat, "call", None)
                if call:
                    if isinstance(call, pyrogram.raw.types.InputGroupCall):
                        return call
                    elif hasattr(call, "id") and hasattr(call, "access_hash"):
                        return pyrogram.raw.types.InputGroupCall(id=call.id, access_hash=call.access_hash)
        except Exception as e:
            logger.warning(f"[{self.account_id}] MTProto GetFullChannel call error: {e}")

        # Fallback to PyTgCalls internal cache
        try:
            call = await self.pytgcalls._app.get_input_call(self.current_chat_id)
            if call:
                return call
        except Exception:
            pass
        return None

    async def raise_hand(self) -> dict:
        """Sends a request to speak (Raise Hand) in the active live stream voice chat."""
        if not self.in_call or not self.current_chat_id:
            return {"success": False, "error": "Not currently in a live stream."}
        input_call = await self.get_input_group_call()
        if not input_call:
            return {"success": False, "error": "Could not find active live voice call on Telegram."}

        # Attempt 1: InputPeerSelf() with muted=True, raise_hand=True (Standard Telegram protocol)
        try:
            await self.client.invoke(
                pyrogram.raw.functions.phone.EditGroupCallParticipant(
                    call=input_call,
                    participant=pyrogram.raw.types.InputPeerSelf(),
                    muted=True,
                    raise_hand=True
                )
            )
            logger.info(f"[{self.account_id}] Successfully raised hand in {self.current_chat_id} (InputPeerSelf, muted=True)")
            return {"success": True, "message": "Raised Hand successfully"}
        except Exception as e1:
            logger.debug(f"[{self.account_id}] Raise hand attempt 1 failed: {e1}")

        # Attempt 2: InputPeerSelf() without muted flag
        try:
            await self.client.invoke(
                pyrogram.raw.functions.phone.EditGroupCallParticipant(
                    call=input_call,
                    participant=pyrogram.raw.types.InputPeerSelf(),
                    raise_hand=True
                )
            )
            logger.info(f"[{self.account_id}] Successfully raised hand in {self.current_chat_id} (InputPeerSelf, raise_hand=True)")
            return {"success": True, "message": "Raised Hand successfully"}
        except Exception as e2:
            logger.debug(f"[{self.account_id}] Raise hand attempt 2 failed: {e2}")

        # Attempt 3: Resolved peer (InputPeerUser)
        try:
            me = getattr(self.client, "me", None) or await self.client.get_me()
            peer = await self.client.resolve_peer(me.id)
            await self.client.invoke(
                pyrogram.raw.functions.phone.EditGroupCallParticipant(
                    call=input_call,
                    participant=peer,
                    muted=True,
                    raise_hand=True
                )
            )
            logger.info(f"[{self.account_id}] Successfully raised hand in {self.current_chat_id} (resolved peer)")
            return {"success": True, "message": "Raised Hand successfully"}
        except Exception as e3:
            logger.error(f"[{self.account_id}] All raise hand attempts failed: {e3}")
            return {"success": False, "error": str(e3)}

    async def unmute(self) -> dict:
        """Unmutes WebRTC audio stream and requests unmuting in group call."""
        if not self.in_call or not self.current_chat_id:
            return {"success": False, "error": "Not in active live."}
        try:
            await self.pytgcalls.unmute(self.current_chat_id)
        except Exception as e:
            logger.warning(f"[{self.account_id}] WebRTC unmute notice: {e}")
        try:
            input_call = await self.get_input_group_call()
            if input_call:
                await self.client.invoke(
                    pyrogram.raw.functions.phone.EditGroupCallParticipant(
                        call=input_call,
                        participant=pyrogram.raw.types.InputPeerSelf(),
                        muted=False,
                        raise_hand=False
                    )
                )
        except Exception as e:
            logger.debug(f"[{self.account_id}] MTProto unmute notice: {e}")
        return {"success": True}

    async def mute(self) -> dict:
        """Mutes WebRTC audio stream and notifies group call."""
        if not self.in_call or not self.current_chat_id:
            return {"success": False, "error": "Not in active live."}
        try:
            await self.pytgcalls.mute(self.current_chat_id)
        except Exception as e:
            logger.warning(f"[{self.account_id}] WebRTC mute notice: {e}")
        try:
            input_call = await self.get_input_group_call()
            if input_call:
                await self.client.invoke(
                    pyrogram.raw.functions.phone.EditGroupCallParticipant(
                        call=input_call,
                        participant=pyrogram.raw.types.InputPeerSelf(),
                        muted=True
                    )
                )
        except Exception as e:
            logger.debug(f"[{self.account_id}] MTProto mute notice: {e}")
        return {"success": True}

    async def play_voice(self, audio_path: str, loop: bool = False, force_now: bool = False) -> dict:
        """Arms or plays a voice message for active live stream.
        If host has unmuted mic, starts playing immediately.
        Otherwise, stays armed and starts playing the exact instant host unmutes mic."""
        if not self.in_call or not self.current_chat_id:
            return {"success": False, "error": "Account is not in active live."}
        
        self.current_audio_file = audio_path
        self.is_looping = loop

        # If host has ALREADY unmuted our mic, start playing right now!
        if not self.muted_by_admin or force_now:
            from pytgcalls.types import MediaStream, AudioQuality
            try:
                stream = MediaStream(
                    media_path=audio_path,
                    audio_parameters=AudioQuality.HIGH,
                    video_flags=MediaStream.Flags.IGNORE
                )
                await self.pytgcalls.play(self.current_chat_id, stream=stream)
                self.is_playing = True
                await self.pytgcalls.unmute(self.current_chat_id)
                logger.info(f"[{self.account_id}] Host already unmuted, voice playing now in {self.current_chat_id}")
                return {"success": True, "status": "playing", "message": "Voice streaming active"}
            except Exception as e:
                self.is_playing = False
                logger.error(f"[{self.account_id}] Error playing voice in live: {e}")
                return {"success": False, "error": str(e)}
        else:
            # Currently muted by host. Arm the voice so it starts the instant host unmutes!
            self.is_playing = False
            logger.info(f"[{self.account_id}] Voice armed! Waiting for live host to unmute mic in {self.current_chat_id}")
            try:
                await self.raise_hand()
            except Exception:
                pass
            return {"success": True, "status": "armed", "message": "Voice armed, waiting for host unmute"}

    async def stop_voice(self) -> dict:
        """Stops broadcasting audio in live stream and mutes mic."""
        if not self.in_call or not self.current_chat_id:
            return {"success": False, "error": "Not in live stream."}
        try:
            self.is_looping = False
            self.is_playing = False
            self.current_audio_file = None
            try:
                await self.pytgcalls.play(self.current_chat_id, stream=None)
            except Exception:
                pass
            await self.mute()
            logger.info(f"[{self.account_id}] Stopped voice broadcast in live {self.current_chat_id}")
            return {"success": True, "message": "Stopped voice broadcast"}
        except Exception as e:
            logger.error(f"[{self.account_id}] Error stopping voice: {e}")
            return {"success": False, "error": str(e)}

    async def get_discussion_target(self) -> int:
        """Finds the comment target: linked discussion group for channels, or the group itself."""
        if not self.current_chat_id:
            return 0
        try:
            peer = await self.client.resolve_peer(self.current_chat_id)
            if isinstance(peer, (pyrogram.raw.types.InputPeerChannel, pyrogram.raw.types.InputChannel)):
                full = await self.client.invoke(
                    pyrogram.raw.functions.channels.GetFullChannel(channel=peer)
                )
                linked_id = getattr(full.full_chat, "linked_chat_id", None)
                if linked_id:
                    discussion_id = pyrogram.utils.get_channel_id(linked_id)
                    try:
                        await self.client.join_chat(discussion_id)
                    except Exception:
                        pass
                    return discussion_id
                else:
                    # Check if broadcast channel (not megagroup/supergroup)
                    chats = getattr(full, "chats", [])
                    for c in chats:
                        if getattr(c, "id", None) == getattr(peer, "channel_id", None):
                            if not getattr(c, "megagroup", False):
                                return -1  # Channel with no comments enabled
        except Exception as e:
            logger.warning(f"[{self.account_id}] Error resolving discussion target: {e}")
        return self.current_chat_id

    async def send_comment(self, text: str) -> dict:
        """Sends a comment/message to the active live stream chat or linked discussion."""
        if not self.current_chat_id:
            return {"success": False, "error": "Not currently in any live stream."}

        await self.ensure_started()
        dest_id = await self.get_discussion_target()
        if dest_id == -1:
            return {
                "success": False,
                "error": "This channel has no linked discussion group (Comments are disabled by channel owner)."
            }

        try:
            await self.client.send_message(dest_id, text)
            return {"success": True, "chat_id": dest_id, "text": text}
        except Exception as e:
            logger.error(f"[{self.account_id}] Error sending comment: {e}")
            return {"success": False, "error": str(e)}

    async def send_attachment_comment(
        self,
        media_path: Optional[str] = None,
        caption: str = "",
        media_type: str = "text"
    ) -> dict:
        """Sends a manual comment with an attachment (photo, video, document, voice, audio, sticker) or plain text."""
        if not self.current_chat_id:
            return {"success": False, "error": "Not currently in any live stream."}

        await self.ensure_started()
        dest_id = await self.get_discussion_target()
        if dest_id == -1:
            return {
                "success": False,
                "error": "This channel has no linked discussion group (Comments are disabled by channel owner)."
            }

        try:
            if media_type == "photo" and media_path:
                await self.client.send_photo(dest_id, media_path, caption=caption or None)
            elif media_type == "video" and media_path:
                await self.client.send_video(dest_id, media_path, caption=caption or None)
            elif media_type == "document" and media_path:
                await self.client.send_document(dest_id, media_path, caption=caption or None)
            elif media_type == "voice" and media_path:
                await self.client.send_voice(dest_id, media_path, caption=caption or None)
            elif media_type == "audio" and media_path:
                await self.client.send_audio(dest_id, media_path, caption=caption or None)
            elif media_type == "sticker" and media_path:
                await self.client.send_sticker(dest_id, media_path)
            elif media_type == "animation" and media_path:
                await self.client.send_animation(dest_id, media_path, caption=caption or None)
            else:
                await self.client.send_message(dest_id, caption or "👍")

            return {"success": True, "chat_id": dest_id, "media_type": media_type}
        except Exception as e:
            logger.error(f"[{self.account_id}] Error sending attachment comment: {e}")
            return {"success": False, "error": str(e)}

