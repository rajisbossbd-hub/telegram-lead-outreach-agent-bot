import os
import sys
import zipfile
import shutil

# Self-healing on Pterodactyl server: auto-extract deploy.zip or /deploy subfolder if present
_base_dir = os.path.dirname(os.path.abspath(__file__))
if os.path.exists("/home/container") or os.environ.get("PTERODACTYL"):
    _zip_path = os.path.join(_base_dir, "deploy.zip")
    if os.path.isfile(_zip_path):
        try:
            with zipfile.ZipFile(_zip_path, "r") as _z:
                for _member in _z.namelist():
                    if _member.startswith("sessions") or ".env" in _member:
                        continue
                    _z.extract(_member, _base_dir)
            try:
                os.remove(_zip_path)
            except Exception:
                pass
            print("[AUTO-EXTRACT] Successfully auto-extracted deploy.zip into server root!")
        except Exception as _e:
            print(f"Notice: deploy.zip auto-extract: {_e}")

    _deploy_sub = os.path.join(_base_dir, "deploy")
    if os.path.isdir(_deploy_sub):
        try:
            for _item in os.listdir(_deploy_sub):
                if _item in ("sessions", ".env"):
                    continue
                _src = os.path.join(_deploy_sub, _item)
                _dst = os.path.join(_base_dir, _item)
                if os.path.isdir(_src):
                    shutil.copytree(_src, _dst, dirs_exist_ok=True)
                else:
                    shutil.copy2(_src, _dst)
            shutil.rmtree(_deploy_sub, ignore_errors=True)
            print("[AUTO-MOVE] Successfully auto-moved files from /deploy subfolder to root!")
        except Exception as _e:
            print(f"Notice: /deploy subfolder move: {_e}")

import asyncio
try:
    loop = asyncio.get_running_loop()
except RuntimeError:
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

import logging
import sys
import pyrogram.errors
if not hasattr(pyrogram.errors, "GroupcallForbidden"):
    pyrogram.errors.GroupcallForbidden = getattr(pyrogram.errors, "GroupCallForbidden", pyrogram.errors.BadRequest)
if not hasattr(pyrogram.errors, "GroupcallInvalid"):
    pyrogram.errors.GroupcallInvalid = getattr(pyrogram.errors, "GroupCallInvalid", pyrogram.errors.BadRequest)

import pyrogram.raw.types
if not hasattr(pyrogram.raw.types, "InputGroupCallSlug"):
    class InputGroupCallSlug:
        def __init__(self, slug=""):
            self.slug = slug
    pyrogram.raw.types.InputGroupCallSlug = InputGroupCallSlug

if not hasattr(pyrogram.raw.types, "PhoneCallDiscardReasonMigrateConferenceCall"):
    class PhoneCallDiscardReasonMigrateConferenceCall:
        pass
    pyrogram.raw.types.PhoneCallDiscardReasonMigrateConferenceCall = PhoneCallDiscardReasonMigrateConferenceCall

import pyrogram.raw.functions.phone
if hasattr(pyrogram.raw.functions.phone, "JoinGroupCall"):
    _orig_join_group_call_init = pyrogram.raw.functions.phone.JoinGroupCall.__init__
    def _patched_join_group_call_init(self, *args, **kwargs):
        kwargs.pop("public_key", None)
        kwargs.pop("block", None)
        return _orig_join_group_call_init(self, *args, **kwargs)
    pyrogram.raw.functions.phone.JoinGroupCall.__init__ = _patched_join_group_call_init

import pyrogram.utils
pyrogram.utils.MIN_CHANNEL_ID = -10099999999999

from pyrogram import Client, idle
import config
from core.account_manager import AccountManager
from bot.handlers import register_handlers

# Logging configuration
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - [%(levelname)s] - %(name)s - %(message)s"
)
logger = logging.getLogger("MultiLiveBot")

import os
from aiohttp import web

# The public dashboard intentionally exposes only operational health metadata.
# Telegram credentials, phone numbers, OTPs, and session strings remain server-side.
BOT_STATUS = {
    "state": "starting",
    "bot_username": None,
    "connected_accounts": 0,
}

async def start_web_server():
    """Serve the hosting-panel dashboard and lightweight health endpoints."""
    try:
        app = web.Application()

        base_dir = os.path.dirname(os.path.abspath(__file__))
        dashboard_dir = os.path.join(base_dir, "web")

        async def index(request):
            return web.FileResponse(os.path.join(dashboard_dir, "index.html"))

        async def health(request):
            return web.json_response({"status": "healthy", "service": "telegram-multi-live-bot"})

        async def status(request):
            return web.json_response({"service": "telegram-multi-live-bot", **BOT_STATUS})

        app.router.add_get("/", index)
        app.router.add_get("/health", health)
        app.router.add_get("/api/status", status)
        app.router.add_static("/static/", dashboard_dir, show_index=False)

        runner = web.AppRunner(app)
        await runner.setup()
        # Pterodactyl-style panels commonly inject SERVER_PORT; other hosts use PORT.
        port = int(os.environ.get("PORT") or os.environ.get("SERVER_PORT") or 7860)
        site = web.TCPSite(runner, "0.0.0.0", port)
        await site.start()
        logger.info(f"🌐 Dashboard listening on 0.0.0.0:{port}")
    except Exception as e:
        logger.warning(f"Could not start web health server: {e}")

async def main(is_gradio: bool = False):
    logger.info("================================================================")
    logger.info(" Starting Telegram Multi-Account Live Bot [v3.0 - Live Voice & Inbox] ")
    logger.info(f" Config Check - API_ID: {config.API_ID}, API_HASH: {'SET' if config.API_HASH else 'NOT SET'}, BOT_TOKEN: {'SET' if config.BOT_TOKEN else 'NOT SET'}")
    logger.info("================================================================")

    # Auto-extract deploy.zip or deploy/ subfolder if present on Pterodactyl
    try:
        import zipfile
        import shutil
        base_dir = os.path.dirname(os.path.abspath(__file__))
        deploy_sub = os.path.join(base_dir, "deploy")
        if os.path.isdir(deploy_sub):
            logger.info("📦 Found /deploy subfolder! Auto-moving files to root...")
            for item in os.listdir(deploy_sub):
                if item in ("sessions", ".env"):
                    continue
                s = os.path.join(deploy_sub, item)
                d = os.path.join(base_dir, item)
                if os.path.isdir(s):
                    shutil.copytree(s, d, dirs_exist_ok=True)
                else:
                    shutil.copy2(s, d)
            shutil.rmtree(deploy_sub, ignore_errors=True)
            logger.info("✅ Auto-synced from /deploy subfolder!")
    except Exception as e:
        logger.warning(f"Auto-sync check: {e}")

    # The dashboard is served by the bot process on game-panel hosting.
    if not is_gradio and os.environ.get("ENABLE_WEB_SERVER", "1") == "1":
        await start_web_server()

    # Validate essential environment variables
    if not config.API_ID or not config.API_HASH:
        logger.error("❌ API_ID or API_HASH is missing! Please set them in Space Secrets.")
        if is_gradio:
            return
        sys.exit(1)

    if not config.BOT_TOKEN:
        logger.error("❌ BOT_TOKEN is missing! Please set BOT_TOKEN in Space Secrets.")
        if is_gradio:
            return
        sys.exit(1)

    # Initialize Master Bot Client
    bot = Client(
        name="master_bot",
        api_id=config.API_ID,
        api_hash=config.API_HASH,
        bot_token=config.BOT_TOKEN,
        workdir=str(config.SESSIONS_DIR)
    )

    # Initialize Multi-Account Manager
    manager = AccountManager()

    # Register Bot Commands and Handlers
    register_handlers(bot, manager)

    # Start Master Bot
    try:
        logger.info("Starting Master Telegram Bot...")
        await bot.start()
        bot_me = await bot.get_me()
        BOT_STATUS.update({
            "state": "online",
            "bot_username": bot_me.username,
        })
        logger.info(f"✅ Master Bot online: @{bot_me.username} ({bot_me.id})")
    except Exception as e:
        BOT_STATUS["state"] = "degraded"
        logger.error(f"❌ Failed to start Master Bot: {e}", exc_info=True)
        if is_gradio:
            return
        sys.exit(1)

    # Start User Account Sessions
    try:
        logger.info("Initializing connected user accounts...")
        await manager.initialize()
        BOT_STATUS["connected_accounts"] = len(manager.engines)
        logger.info(f"✅ Loaded {len(manager.engines)} active user account(s).")
    except Exception as e:
        logger.error(f"❌ Failed to initialize user accounts: {e}", exc_info=True)

    # Start Auto Channel Monitor & Auto Live Join Background Workers
    monitor_task = asyncio.create_task(manager.run_auto_channel_monitor_loop(bot_client=bot))
    auto_live_task = asyncio.create_task(manager.run_auto_live_monitor_loop(bot_client=bot))

    print("\n------------------------------------------------------------")
    print(f"🎉 System is running! Open Telegram and message @{bot_me.username}")
    print("Commands: /start, /accounts, /add, /join <link>, /leave, /status")
    print("Press Ctrl+C in terminal to stop.")
    print("------------------------------------------------------------\n")

    # Idle loop
    if is_gradio:
        while True:
            await asyncio.sleep(3600)
    else:
        await idle()

    # Cleanup on exit
    logger.info("Shutting down accounts and bot...")
    monitor_task.cancel()
    auto_live_task.cancel()
    for session_name, engine in manager.engines.items():
        try:
            await engine.stop()
        except Exception:
            pass
    await bot.stop()
    logger.info("Shutdown complete.")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot stopped by user.")
