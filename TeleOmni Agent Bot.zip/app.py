import threading
import asyncio
import gradio as gr
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("HF-Gradio-App")

def run_telegram_bot():
    """Runs the Telegram bot in a dedicated asyncio loop on a background thread."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        import main
        logger.info("Starting Telegram Multi-Live Bot in background thread...")
        loop.run_until_complete(main.main(is_gradio=True))
    except Exception as e:
        logger.error(f"Error running Telegram bot: {e}", exc_info=True)

import time

# Start Telegram Bot in background thread
bot_thread = threading.Thread(target=run_telegram_bot, daemon=False)
bot_thread.start()

# Build Gradio UI for Hugging Face Space
with gr.Blocks(title="Telegram Multi-Account Live Bot") as demo:
    gr.Markdown("# 🎙️ Telegram Multi-Account Live Bot")
    gr.Markdown(
        """
        ### 🟢 System Status: **Active & Running 24/7**
        
        This space hosts the backend engine for the Telegram Multi-Account Live Joiner Bot.
        
        - **Pyrogram Multi-Client Engine:** Connected
        - **PyTgCalls Stream Engine:** Ready
        - **WebRTC Audio/Video Support:** Enabled
        
        Open your Telegram app and interact with your bot via `/start`!
        """
    )

demo.launch(server_name="0.0.0.0", server_port=7860, prevent_thread_lock=True)

# Keep the main process alive forever so the container never shuts down
while True:
    time.sleep(60)
