@echo off
title Telegram Multi-Account Live Joiner
cd /d "%~dp0"

echo ============================================================
echo      Starting Telegram Multi-Account Live Joiner Bot
echo ============================================================
echo.

if not exist ".env" (
    echo [!] .env file not found!
    pause
    exit /b
)

echo Starting Bot...
".\venv\Scripts\python.exe" main.py

pause
